========================================================================
  ALL 6 SOLIDWORKS VBA MACROS (WITH MOVING KINEMATIC MATES)
  Works on SOLIDWORKS 2016 - 2025
========================================================================

INCLUDED FOLDERS & LATEST MOVING MACRO FILES:

1. UniversalCoupling/
   - UniversalCoupling_Macro_V2.bas  (and .txt)
   - UniversalCoupling_Exam_Notes.txt
   * How to move: Drag either shaft or fork with the mouse -> both shafts
     and the centre block rotate together! (Suppress 'Keep_Shafts_Aligned'
     in the Mates folder to tilt/bend the joint at an angle.)

2. KnuckleJoint/
   - KnuckleJoint_Macro_V4.bas  (and .txt)  [Shaped profile + Hinge Mates]
   - KnuckleJoint_Exam_Notes.txt
   * How to move: Drag the Eye Rod left/right with the mouse -> it pivots
     smoothly around the vertical Knuckle Pin between the fork jaws!

3. OldhamCoupling/
   - OldhamCoupling_Macro_V3.bas  (and .txt)
   - Oldham_Exam_Notes.txt
   * How to move: Drag either shaft/hub or the centre disc -> the whole
     coupling rotates together! (Suppress 'Keep_Horiz_Centered' and
     'Keep_Vert_Centered' in the Mates folder to slide the tongues in the slots.)

4. FlangeCoupling/
   - FlangeCoupling_Macro_V9.bas  (and .txt)  [Threaded Bolts/Nuts + Bearing Mates]
   * How to move: Drag any flange, shaft, key, bolt, or nut -> the entire
     bolted coupling rotates 360 degrees around the shaft axis!

5. SingleToolPost/
   - SingleToolPost_Macro_V3.bas  (and .txt)
   - SingleToolPost_Exam_Notes.txt
   * How to move: Drag the Tool Bit or Pillar Body -> the turret swivels
     360 degrees on the stationary Square Base Block!

6. SocketSpigotJoint/
   - SocketSpigot_Macro_V3.bas  (and .txt)
   - SocketSpigot_Exam_Notes.txt
   * How to move: Drag the Cotter up/down -> it slides smoothly in and out
     of the slot! (Suppress 'Spigot_Locked_By_Cotter' in the Mates folder
     to slide the Spigot Rod axially in and out of the Socket Rod.)

------------------------------------------------------------------------
HOW TO RUN ANY MACRO IN SOLIDWORKS:
1. Open SOLIDWORKS (close any previously generated parts/assemblies first).
2. Click Tools -> Macro -> New... and save a new .swp macro file.
3. In the VBA Editor window:
   - Delete any default lines in Module1.
   - Either click File -> Import File... and choose the .bas file, OR
     open the .txt/.bas file in Notepad, Ctrl+A, Ctrl+C, and paste (Ctrl+V).
4. Press F5 (Run). Confirm the pop-up dimensions and choose a save folder.
========================================================================
