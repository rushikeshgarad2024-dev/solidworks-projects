'=====================================================================================
'  KNUCKLE JOINT MACRO  -  VERSION 4 (SHAPED + MOVING HINGE MATES) (shaped like textbook model)
'  Knuckle (Pin) Joint - Full Assembly (exam model)
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'  V3: shaped profiles - tapered eye/fork straps, long fork arms with an
'  open U-gap, stepped fork root, and hexagonal shanks between the round
'  rods and the flat lugs (as in the standard textbook 3D model).
'  (V2 had plain rectangular neck/yoke blocks.)
'  Standard proportions in terms of rod diameter d:
'    pin diameter d1 = d, eye outside diameter d2 = 2d,
'    pin head / collar diameter d3 = 1.5d, single eye thickness t = 1.25d,
'    fork thickness t1 = 0.75d (each leg), pin head thickness t2 = 0.5d.
'    (Default rod diameter = 40 mm.)
'-------------------------------------------------------------------------------------
'  EXAM POINT: A knuckle joint connects two rods under axial TENSILE load
'  where a small angular movement between the rods is required. One rod
'  end is a single EYE, the other is a FORK (double eye). A knuckle PIN
'  passes through both; the pin is secured by a COLLAR and SPLIT PIN.
'  The pin acts as a hinge/fulcrum and is in DOUBLE SHEAR.
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old KnuckleJoint files if open.
'     2) Tools > Macro > New  -> save as  KnuckleJoint.swp
'     3) Select ALL old code (Ctrl+A), Delete, paste THIS FULL CODE.
'     4) Press F5. Answer the pop-ups (standard values pre-filled).
'     5) The macro creates automatically:
'            Eye_Rod.SLDPRT      (rod with single eye)
'            Fork_Rod.SLDPRT     (rod with fork / double eye)
'            Knuckle_Pin.SLDPRT  (pin with head)
'            Collar.SLDPRT       (collar for the pin)
'            Split_Pin.SLDPRT    (small locking pin, simplified straight)
'            KnuckleJoint.SLDASM (full assembly)
'        Saved in the first pop-up folder (default Documents\KnuckleJoint).
'
'  NOTES:
'    - Tapered flat straps + hexagonal rod shanks, like forged rod ends.
'    - Rod axis is Z, knuckle pin is vertical (Y): head on top,
'      collar + split pin below. Eye is sandwiched between fork legs
'      with 1 mm side clearance; pin holes have 1 mm diametral clearance.
'    - Parts are placed exactly by position (no mates). Do not drag parts.
'    - In the real joint the rods can swivel slightly about the pin.
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String
Private gEyePinAxisName As String
Private gEyeMidPlaneName As String
Private gAssyPinAxisName As String            ' name of current step - shown in error message (for easy fixing)

' User dimensions (mm)
Private rodD As Double             ' d  - diameter of both rods
Private pinD As Double             ' d1 - knuckle pin diameter
Private eyeOD As Double            ' d2 - outside diameter of eye (single & fork)
Private headD As Double            ' d3 - pin head and collar diameter
Private eyeT As Double             ' t  - thickness of single eye (along pin)
Private forkT As Double            ' t1 - thickness of each fork leg
Private headT As Double            ' t2 - pin head / collar thickness
Private splitD As Double           ' split (locking) pin diameter
Private rodLen As Double           ' plain rod length on each side

' Calculated dimensions (mm)
Private neckW As Double            ' width of eye/fork neck plates
Private eyeNeckLen As Double       ' pin centre to plain rod start (eye rod)
Private pinCtrEye As Double        ' pin centre Z in Eye_Rod local coords
Private hexLen As Double           ' hexagonal shank length = 1.1d
Private hexAF As Double            ' hexagonal shank across-flats = 1.08d
Private forkRootStart As Double    ' fork root (web) start Z = 2.5d from pin centre
Private forkLegEnd As Double       ' fork leg strap end Z
Private forkRootEnd As Double      ' fork root end Z / hex shank start
Private stackHalf As Double        ' half of eye+fork stack thickness
Private pinEndExtra As Double      ' pin projection below collar = 0.25d
Private pinShaftLen As Double      ' pin shaft length (tip to head underside)
Private splitLen As Double         ' split pin length

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.5          ' clearance (mm) for recess & bolt holes (+1 on dia = 2x0.5)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Knuckle Joint - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Knuckle Joint"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Knuckle Joint", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function



'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Knuckle Joint"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

' Open a sketch on a named reference plane ("Top Plane" / "Right Plane").
Private Function OpenNamedSketch(ByVal oDoc As Object, ByVal sPlaneName As String) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2(sPlaneName, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select plane: " & sPlaneName & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Knuckle Joint"
        OpenNamedSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True
    OpenNamedSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub


' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Knuckle Joint"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Knuckle Joint"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function


Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Knuckle Joint"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

' Profiles on an OPEN Top Plane sketch use global Z ranges.
' Top Plane sketch local Y = -global Z (SOLIDWORKS default).
Private Sub DrawTopTrapZ(ByVal oDoc As Object, ByVal zStart As Double, ByVal wStart As Double, _
                         ByVal zEnd As Double, ByVal wEnd As Double)
    ' Trapezoid plate outline on an OPEN Top Plane sketch (tapered strap).
    Call oDoc.SketchManager.CreateLine(Mm(-wStart / 2), Mm(-zStart), 0, Mm(wStart / 2), Mm(-zStart), 0)
    Call oDoc.SketchManager.CreateLine(Mm(wStart / 2), Mm(-zStart), 0, Mm(wEnd / 2), Mm(-zEnd), 0)
    Call oDoc.SketchManager.CreateLine(Mm(wEnd / 2), Mm(-zEnd), 0, Mm(-wEnd / 2), Mm(-zEnd), 0)
    Call oDoc.SketchManager.CreateLine(Mm(-wEnd / 2), Mm(-zEnd), 0, Mm(-wStart / 2), Mm(-zStart), 0)
End Sub

' Regular hexagon on an OPEN Front Plane sketch, centre at (0, cyMm).
' Vertex radius R = across-flats / sqrt(3). Flat faces top and bottom.
Private Sub DrawHexAt(ByVal oDoc As Object, ByVal cyMm As Double, ByVal acrossFlatsMm As Double)
    Dim R As Double
    Dim vPoly As Variant
    R = acrossFlatsMm / 1.73205080756888
    vPoly = oDoc.SketchManager.CreatePolygon(0, Mm(cyMm), 0, Mm(R), Mm(cyMm), 0, 6, True)
End Sub

' Knuckle pin hole (axis Y) at a given global Z centre - cut through all.
Private Function AddPinHoleY(ByVal oDoc As Object, ByVal centerZ As Double, _
                             ByVal featName As String) As Boolean
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -centerZ, pinD + 1
    AddPinHoleY = CutThroughAllFromOpenSketch(oDoc, featName)
End Function

' Split-pin lock hole (axis Z) at a given Y height - cut through all.
Private Function AddLockHoleZ(ByVal oDoc As Object, ByVal centerY As Double, _
                              ByVal featName As String) As Boolean
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, centerY, splitD + 1
    AddLockHoleZ = CutThroughAllFromOpenSketch(oDoc, featName)
End Function

'------------------------- PART 1: Eye rod (single eye) -------------------------
' Local origin = outer rod end, bottom face of eye. Rod axis +Z, at local
' Y = t/2. Pin centre at local Z = pinCtrEye.
Private Function MakeEyeRod(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    ' Round rod
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, eyeT / 2, rodD
    If Not BossFromOpenSketch(oDoc, rodLen, False, 0, "Rod") Then Exit Function
    ' Hexagonal shank (forged transition, overlaps rod by 5 mm)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawHexAt oDoc, eyeT / 2, hexAF
    If Not BossFromOpenSketch(oDoc, hexLen, False, rodLen - 5, "Hex_Shank") Then Exit Function
    ' Tapered neck strap: rod width at shank widening to neckW at the eye
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopTrapZ oDoc, pinCtrEye - eyeNeckLen - 15, 0.95 * rodD, pinCtrEye, neckW
    If Not BossFromOpenSketch(oDoc, eyeT, False, 0, "Eye_Neck") Then Exit Function
    ' Eye disc (overlaps the neck)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -pinCtrEye, eyeOD
    If Not BossFromOpenSketch(oDoc, eyeT, False, 0, "Eye_Disc") Then Exit Function
    ' Pin hole
    If Not AddPinHoleY(oDoc, pinCtrEye, "Pin_Hole_Eye") Then Exit Function

    ' Reference planes & axis for assembly hinge mate (so Eye_Rod swings around Knuckle_Pin)
    Dim oRefP1 As Object, oRefP2 As Object, oFeat As Object, sP1Name As String
    gEyePinAxisName = "Axis_EyePin"
    gEyeMidPlaneName = "Plane_EyeMid"
    sP1Name = "Plane1"
    oDoc.ClearSelection2 True
    If oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        Set oRefP1 = oDoc.FeatureManager.InsertRefPlane(8, Mm(pinCtrEye), 0, 0, 0, 0)
        oDoc.ClearSelection2 True
        On Error Resume Next
        Set oFeat = oDoc.FeatureByPositionReverse(0)
        If Not oFeat Is Nothing Then
            sP1Name = oFeat.Name
            oFeat.Name = "Plane_EyePin"
            sP1Name = oFeat.Name
        End If
        On Error GoTo 0
        If oDoc.Extension.SelectByID2(sP1Name, "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
            If oDoc.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
                If oDoc.InsertAxis2(True) Then
                    oDoc.ClearSelection2 True
                    On Error Resume Next
                    Set oFeat = oDoc.FeatureByPositionReverse(0)
                    If Not oFeat Is Nothing Then
                        gEyePinAxisName = oFeat.Name
                        oFeat.Name = "Axis_EyePin"
                        gEyePinAxisName = oFeat.Name
                    End If
                    On Error GoTo 0
                End If
            End If
        End If
    End If
    oDoc.ClearSelection2 True
    If oDoc.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        Set oRefP2 = oDoc.FeatureManager.InsertRefPlane(8, Mm(eyeT / 2), 0, 0, 0, 0)
        oDoc.ClearSelection2 True
        On Error Resume Next
        Set oFeat = oDoc.FeatureByPositionReverse(0)
        If Not oFeat Is Nothing Then
            gEyeMidPlaneName = oFeat.Name
            oFeat.Name = "Plane_EyeMid"
            gEyeMidPlaneName = oFeat.Name
        End If
        On Error GoTo 0
    End If
    MakeEyeRod = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 2: Fork rod (double eye) -------------------------
' Local origin = pin centre (Z), bottom outer face of fork stack (Y).
' Rod axis +Z at local Y = stackHalf. Fork legs are bottom and top plates.
Private Function MakeForkRod(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim topLegY As Double, legWEnd As Double
    Dim rootMid As Double, rootBH As Double, rootBY As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    topLegY = forkT + eyeT + 2
    legWEnd = (neckW + rodD) / 2
    rootMid = forkRootStart + 0.6 * rodD
    rootBH = 0.68 * (2 * stackHalf)
    rootBY = (2 * stackHalf - rootBH) / 2
    ' Feature order keeps every boss touching the existing body.
    ' Bottom fork leg: tapered strap, then disc
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopTrapZ oDoc, 0, neckW, forkLegEnd, legWEnd
    If Not BossFromOpenSketch(oDoc, forkT, False, 0, "Fork_Neck_Bot") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, eyeOD
    If Not BossFromOpenSketch(oDoc, forkT, False, 0, "Fork_Disc_Bot") Then Exit Function
    ' Fork root web, full stack height (far from the pin - long open fork arms)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopTrapZ oDoc, forkRootStart, legWEnd, rootMid, rodD + 6
    If Not BossFromOpenSketch(oDoc, 2 * stackHalf, False, 0, "Fork_Root") Then Exit Function
    ' Stepped-down root transition towards the hex shank
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopTrapZ oDoc, rootMid - 5, rodD + 6, forkRootEnd, rodD + 2
    If Not BossFromOpenSketch(oDoc, rootBH, False, rootBY, "Fork_Root_Step") Then Exit Function
    ' Top fork leg: strap first (overlaps root), then disc
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopTrapZ oDoc, 0, neckW, forkLegEnd, legWEnd
    If Not BossFromOpenSketch(oDoc, forkT, False, topLegY, "Fork_Neck_Top") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, eyeOD
    If Not BossFromOpenSketch(oDoc, forkT, False, topLegY, "Fork_Disc_Top") Then Exit Function
    ' Hexagonal shank (overlaps root step by 5 mm)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawHexAt oDoc, stackHalf, hexAF
    If Not BossFromOpenSketch(oDoc, hexLen, False, forkRootEnd - 5, "Hex_Shank") Then Exit Function
    ' Round rod (overlaps hex by 5 mm)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, stackHalf, rodD
    If Not BossFromOpenSketch(oDoc, rodLen, False, forkRootEnd + hexLen - 10, "Rod") Then Exit Function
    ' Pin hole through both legs
    If Not AddPinHoleY(oDoc, 0, "Pin_Hole_Fork") Then Exit Function
    MakeForkRod = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 3: Knuckle pin -------------------------
' Local origin = pin tip (bottom). Axis along +Y. Head on top.
Private Function MakeKnucklePin(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' Shaft
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pinD
    If Not BossFromOpenSketch(oDoc, pinShaftLen, False, 0, "Pin_Shaft") Then Exit Function
    ' Head
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, headD
    If Not BossFromOpenSketch(oDoc, headT, False, pinShaftLen, "Pin_Head") Then Exit Function
    ' Split-pin hole (at collar centre height)
    If Not AddLockHoleZ(oDoc, pinEndExtra + headT / 2, "Split_Hole_Pin") Then Exit Function
    MakeKnucklePin = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 4: Collar -------------------------
' Local origin = collar bottom face. Axis along +Y.
Private Function MakeCollar(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, headD
    DrawCircle oDoc, 0, 0, pinD + 1
    If Not BossFromOpenSketch(oDoc, headT, False, 0, "Collar") Then Exit Function
    If Not AddLockHoleZ(oDoc, headT / 2, "Split_Hole_Collar") Then Exit Function
    MakeCollar = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 5: Split pin (simplified) -------------------------
' Local origin = one end. Axis along +Z.
Private Function MakeSplitPin(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, splitD
    If Not BossFromOpenSketch(oDoc, splitLen, False, 0, "Split_Pin") Then Exit Function
    MakeSplitPin = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly -------------------------
' AddComponent5 inserts a PRE-LOADED part, so first load the part
' file into memory (silent). 1 = swDocPART, 1 = swOpenDocOptions_Silent.
Private Function LoadPartForAssembly(ByVal sPath As String) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading part for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, 1, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this part file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Knuckle Joint"
        LoadPartForAssembly = False
        Exit Function
    End If
    LoadPartForAssembly = True
End Function


' V5: check the actual position of a component by reading its transform back.
' Transform ArrayData: elements 9, 10, 11 = translation X, Y, Z (metres).
Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

' Insert one component and put its ORIGIN exactly at (xMm,yMm,zMm), no rotation.
' V5 FIX: move the component the recorded-macro way -
'   1) copy the 16-number transform array into a VARIANT variable,
'   2) CreateTransform((variant))  [double brackets are intentional],
'   3) SetTransformAndSolve2(...) to actually move+solve the component,
'   4) read the position back and verify it really moved.
Private Function PlaceComponentRef(ByVal oAsm As Object, ByVal sPath As String, _
                                   ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double, _
                                   ByRef oOutComp As Object) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Knuckle Joint"
        PlaceComponentRef = False
        Exit Function
    End If
    Set oOutComp = oComp
    aData(0) = 1: aData(1) = 0: aData(2) = 0: aData(3) = 0
    aData(4) = 1: aData(5) = 0: aData(6) = 0: aData(7) = 0
    aData(8) = 1: aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        On Error Resume Next
        oComp.Transform2 = oXf
        On Error GoTo 0
    End If
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        MsgBox "Component was inserted but could NOT be moved to its correct position:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Knuckle Joint"
        PlaceComponentRef = False
        Exit Function
    End If
    PlaceComponentRef = True
End Function

Private Function SelectForKnuckleMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                      ByVal sFeatName As String, ByVal sAltName As String, _
                                      ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then Set oFeat = oComp.FeatureByName(sAltName)
        If Not oFeat Is Nothing Then bOk = oFeat.Select2(bAppend, 1)
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectForKnuckleMate = bOk
End Function

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oAsm As Object, oFeat As Object, oMate As Object
    Dim oCompFork As Object, oCompEye As Object, oCompPin As Object
    Dim oCompCollar As Object, oCompSplit As Object, oEyeXf As Object
    Dim pEye As String, pFork As String, pPin As String, pCollar As String, pSplit As String
    Dim sAsmTitle As String
    Dim lErr As Long, lMateErr As Long
    pEye = sFolder & "\Eye_Rod.SLDPRT"
    pFork = sFolder & "\Fork_Rod.SLDPRT"
    pPin = sFolder & "\Knuckle_Pin.SLDPRT"
    pCollar = sFolder & "\Collar.SLDPRT"
    pSplit = sFolder & "\Split_Pin.SLDPRT"

    gStep = "Creating new Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create new Assembly (check default Assembly template).", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle

    ' Create vertical pin axis (Axis_Assy_Y) at intersection of Front Plane and Right Plane
    gAssyPinAxisName = "Axis1"
    oAsm.ClearSelection2 True
    If oAsm.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oAsm.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oAsm.InsertAxis2(True) Then
                oAsm.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oAsm.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gAssyPinAxisName = oFeat.Name
                    oFeat.Name = "Axis_Assy_Y"
                    gAssyPinAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oAsm.ClearSelection2 True

    ' Load all parts into memory FIRST
    If Not LoadPartForAssembly(pEye) Then Exit Function
    If Not LoadPartForAssembly(pFork) Then Exit Function
    If Not LoadPartForAssembly(pPin) Then Exit Function
    If Not LoadPartForAssembly(pCollar) Then Exit Function
    If Not LoadPartForAssembly(pSplit) Then Exit Function
    gStep = "Activating assembly window"
    swApp.ActivateDoc2 sAsmTitle, False, lErr

    If Not PlaceComponentRef(oAsm, pFork, 0, -stackHalf, 0, oCompFork) Then Exit Function
    If Not PlaceComponentRef(oAsm, pEye, 0, -eyeT / 2, -pinCtrEye, oCompEye) Then Exit Function
    If Not PlaceComponentRef(oAsm, pPin, 0, -(stackHalf + headT + pinEndExtra), 0, oCompPin) Then Exit Function
    If Not PlaceComponentRef(oAsm, pCollar, 0, -(stackHalf + headT), 0, oCompCollar) Then Exit Function
    If Not PlaceComponentRef(oAsm, pSplit, 0, -(stackHalf + headT / 2), -splitLen / 2, oCompSplit) Then Exit Function

    ' Fix Fork_Rod, Knuckle_Pin, Collar, Split_Pin; leave Eye_Rod floating with hinge mates
    On Error Resume Next
    Set oEyeXf = oCompEye.Transform2
    oAsm.ClearSelection2 True: If oCompFork.Select4(False, Nothing, False) Then oAsm.FixComponent
    oAsm.ClearSelection2 True: If oCompPin.Select4(False, Nothing, False) Then oAsm.FixComponent
    oAsm.ClearSelection2 True: If oCompCollar.Select4(False, Nothing, False) Then oAsm.FixComponent
    oAsm.ClearSelection2 True: If oCompSplit.Select4(False, Nothing, False) Then oAsm.FixComponent
    oAsm.ClearSelection2 True: If oCompEye.Select4(False, Nothing, False) Then oAsm.UnfixComponent
    oAsm.ClearSelection2 True

    ' Hinge Mate 1: Eye_Rod pin axis coincident with Assembly vertical pin axis
    If SelectForKnuckleMate(oAsm, oCompEye, gEyePinAxisName, "Axis1", "AXIS", False) Then
        If SelectForKnuckleMate(oAsm, Nothing, gAssyPinAxisName, "Axis1", "AXIS", True) Then
            Set oMate = oAsm.AddMate5(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
            If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
            If Not oMate Is Nothing Then oMate.Name = "Pin_Hinge_Axis_Mate"
        End If
    End If
    oAsm.ClearSelection2 True

    ' Hinge Mate 2: Eye_Rod midplane coincident with Assembly Top Plane (keeps Eye_Rod between fork jaws)
    If SelectForKnuckleMate(oAsm, oCompEye, gEyeMidPlaneName, "Plane2", "PLANE", False) Then
        If SelectForKnuckleMate(oAsm, Nothing, "Top Plane", "", "PLANE", True) Then
            Set oMate = oAsm.AddMate5(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
            If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
            If Not oMate Is Nothing Then oMate.Name = "Eye_Vertical_Lock_Mate"
        End If
    End If
    oAsm.ClearSelection2 True
    Call oAsm.ForceRebuild3(False)
    If Not CompAtPosition(oCompEye, 0, -eyeT / 2, -pinCtrEye) Then
        oCompEye.Transform2 = oEyeXf
        Call oCompEye.SetTransformAndSolve2(oEyeXf)
    End If
    oAsm.SetUserPreferenceToggle 4, False
    oAsm.SetUserPreferenceToggle 5, False
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\KnuckleJoint.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Eye_Rod.SLDPRT"
    swApp.CloseDoc "Fork_Rod.SLDPRT"
    swApp.CloseDoc "Knuckle_Pin.SLDPRT"
    swApp.CloseDoc "Collar.SLDPRT"
    swApp.CloseDoc "Split_Pin.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    ValidateDims = False
    If rodD < 20 Then MsgBox "Rod diameter is too small (minimum 20 mm).", vbCritical: Exit Function
    If pinD < 10 Then MsgBox "Pin diameter is too small (minimum 10 mm).", vbCritical: Exit Function
    If eyeOD < pinD + 16 Then MsgBox "Eye outside diameter is too small - less than 8 mm of material around the pin hole.", vbCritical: Exit Function
    If eyeOD < rodD + 20 Then MsgBox "Eye outside diameter should be at least rod diameter + 20 mm.", vbCritical: Exit Function
    If headD <= pinD + 8 Then MsgBox "Pin head / collar diameter must be more than pin diameter + 8 mm.", vbCritical: Exit Function
    If headD > eyeOD Then MsgBox "Pin head / collar diameter should not be bigger than the eye outside diameter.", vbCritical: Exit Function
    If eyeT < 10 Then MsgBox "Single eye thickness is too small (minimum 10 mm).", vbCritical: Exit Function
    If forkT < 8 Then MsgBox "Fork leg thickness is too small (minimum 8 mm).", vbCritical: Exit Function
    If headT < 6 Then MsgBox "Pin head / collar thickness is too small (minimum 6 mm).", vbCritical: Exit Function
    If splitD < 3 Then MsgBox "Split pin diameter is too small (minimum 3 mm).", vbCritical: Exit Function
    If splitD + 1 >= 0.4 * pinD Then MsgBox "Split pin is too big - its hole would weaken the knuckle pin. Reduce split pin diameter.", vbCritical: Exit Function
    If neckW <= pinD + 5 Then MsgBox "Eye outside diameter is too small - the neck would be too narrow around the pin hole. Increase eye OD.", vbCritical: Exit Function
    If splitD + 4 > headT Then MsgBox "Split pin hole will not fit inside the collar thickness. Reduce split pin diameter or increase collar thickness (t2).", vbCritical: Exit Function
    If 2.5 * rodD < eyeOD / 2 + 5 Then MsgBox "Eye outside diameter is too large to clear the fork root. Reduce eye OD or increase rod diameter.", vbCritical: Exit Function
    If rodLen < rodD Then MsgBox "Plain rod length should be at least equal to the rod diameter.", vbCritical: Exit Function
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "KNUCKLE JOINT MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Standard textbook proportions are already filled - press OK" & vbCrLf & _
           "to accept, or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old KnuckleJoint files that are open.", _
           vbInformation, "Knuckle Joint"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\KnuckleJoint"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\KnuckleJoint"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = standard proportions of rod diameter) ----
    gCancelled = False
    rodD = AskNum("1) Rod diameter  d  (mm)" & vbCrLf & "All other default values are calculated from this.", 40)
    If gCancelled Then Exit Sub
    pinD = AskNum("2) Knuckle pin diameter  d1 = d  (mm)", rodD)
    If gCancelled Then Exit Sub
    eyeOD = AskNum("3) Eye outside diameter  d2 = 2d  (mm)", Round(2 * rodD))
    If gCancelled Then Exit Sub
    headD = AskNum("4) Pin head & collar diameter  d3 = 1.5d  (mm)", Round(1.5 * rodD))
    If gCancelled Then Exit Sub
    eyeT = AskNum("5) Single eye thickness  t = 1.25d  (mm)", Round(1.25 * rodD))
    If gCancelled Then Exit Sub
    forkT = AskNum("6) Fork leg thickness (each)  t1 = 0.75d  (mm)", Round(0.75 * rodD))
    If gCancelled Then Exit Sub
    headT = AskNum("7) Pin head & collar thickness  t2 = 0.5d  (mm)", Round(0.5 * rodD))
    If gCancelled Then Exit Sub
    splitD = AskNum("8) Split pin diameter (mm)", Round(0.2 * rodD))
    If gCancelled Then Exit Sub
    rodLen = AskNum("9) Round rod length on each side (mm)" & vbCrLf & "Hex shank and tapered neck are added automatically.", Round(2 * rodD))
    If gCancelled Then Exit Sub

    ' ---- Calculated values (set BEFORE validation) ----
    neckW = 0.82 * eyeOD
    hexLen = 1.1 * rodD
    hexAF = 1.08 * rodD
    eyeNeckLen = 0.95 * eyeOD
    pinCtrEye = rodLen - 5 + hexLen + eyeNeckLen
    forkRootStart = 2.5 * rodD
    forkLegEnd = forkRootStart + 0.25 * rodD
    forkRootEnd = forkRootStart + 1.1 * rodD
    stackHalf = forkT + (eyeT + 2) / 2
    pinEndExtra = 0.25 * rodD
    pinShaftLen = 2 * stackHalf + headT + pinEndExtra
    splitLen = headD + 20

    If Not ValidateDims() Then Exit Sub

    ' ---- Summary + confirmation ----
    sSummary = "Model will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Rod diameter d            = " & rodD & vbCrLf & _
        "Knuckle pin dia d1        = " & pinD & "  (holes " & (pinD + 1) & ")" & vbCrLf & _
        "Eye outside dia d2        = " & eyeOD & vbCrLf & _
        "Pin head/collar dia d3    = " & headD & vbCrLf & _
        "Single eye thickness t    = " & eyeT & vbCrLf & _
        "Fork leg thickness t1     = " & forkT & " each (gap " & (eyeT + 2) & ")" & vbCrLf & _
        "Pin head/collar thk t2    = " & headT & vbCrLf & _
        "Split pin dia x length    = " & splitD & " x " & splitLen & vbCrLf & _
        "Round rod length (each)   = " & rodLen & "  + hex shank " & hexLen & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Knuckle Joint - Confirm") = vbCancel Then Exit Sub

    ' ---- Build all parts ----
    gStep = "Making Eye Rod"
    If Not MakeEyeRod(sFolder & "\Eye_Rod.SLDPRT") Then Exit Sub
    gStep = "Making Fork Rod"
    If Not MakeForkRod(sFolder & "\Fork_Rod.SLDPRT") Then Exit Sub
    gStep = "Making Knuckle Pin"
    If Not MakeKnucklePin(sFolder & "\Knuckle_Pin.SLDPRT") Then Exit Sub
    gStep = "Making Collar"
    If Not MakeCollar(sFolder & "\Collar.SLDPRT") Then Exit Sub
    gStep = "Making Split Pin"
    If Not MakeSplitPin(sFolder & "\Split_Pin.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 5 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Knuckle Joint"
        Exit Sub
    End If

    MsgBox "DONE!  Knuckle Joint model is ready." & vbCrLf & vbCrLf & _
           "Assembly open now:  KnuckleJoint.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           "Parts: Eye Rod, Fork Rod, Knuckle Pin, Collar, Split Pin." & vbCrLf & vbCrLf & _
           "EXAM POINT: it connects two rods in TENSION and allows" & vbCrLf & _
           "small angular movement. The pin is in DOUBLE SHEAR." & vbCrLf & vbCrLf & _
           "Use mouse to rotate. Press Ctrl+7 for isometric view if needed." & vbCrLf & _
           "HOW TO MOVE IT: Drag the Eye Rod left/right with the mouse - it pivots smoothly around the Knuckle Pin!", _
           vbInformation, "Knuckle Joint"
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Knuckle Joint Version 3)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Knuckle Joint - Error"
End Sub
