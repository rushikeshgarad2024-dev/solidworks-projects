'=====================================================================================
'  SINGLE TOOL POST MACRO  -  VERSION 3 (MOVING SWIVEL MATES)
'  Lathe Single Tool Post (pillar type) - Full Assembly (exam model)
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'  V2: full error re-check - collar thickness is now set before validation,
'  and the square block is built from boss layers (no blind cut needed).
'  Design/dimensions based on the standard textbook single tool post
'  (Pillar dia 50 x 150 high, slot 22 wide, Block 76 square, Ring dia 100,
'   Wedge 120 long, Clamp screw M22 - all these are the default pop-up values).
'-------------------------------------------------------------------------------------
'  EXAM POINT: A single tool post holds ONE lathe cutting tool at a time.
'  It is fitted on the compound rest. The tool rests on the WEDGE, the wedge
'  rests on the spherical face of the RING, and the CLAMP SCREW presses the
'  tool from the top. Sliding/tilting the wedge on the ring adjusts the
'  tool-tip height. The pillar can swivel about its vertical axis.
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old SingleToolPost files if open.
'     2) Tools > Macro > New  -> save as  SingleToolPost.swp  (anywhere)
'     3) The macro editor opens. Select ALL old code (Ctrl+A), Delete,
'        then paste THIS FULL CODE.
'     4) Press F5  (or click the green Run / Play button).
'     5) Pop-up boxes ask dimensions (mm). Textbook values are already
'        filled - just press OK/Enter to accept, or type your own.
'     6) Wait. The macro automatically creates:
'            Square_Block.SLDPRT  (base block, sits in compound-rest T-slot)
'            Pillar_Body.SLDPRT   (round pillar with collar, slot and top hole)
'            Ring.SLDPRT          (ring with dished/spherical top seat)
'            Wedge.SLDPRT         (rocker wedge, convex bottom)
'            Tool_Bit.SLDPRT      (square cutting tool bit)
'            Clamp_Screw.SLDPRT   (M22 screw with square head)
'            SingleToolPost.SLDASM (full assembly)
'        Files are saved in the folder from the first pop-up
'        (default: Documents\SingleToolPost).
'
'  NOTES (simplifications, normal for student models):
'    - Pillar top taper is made in 4 small steps (looks tapered).
'    - Ring spherical seat and wedge spherical bottom are approximated
'      (stepped seat / faceted arc). Serrations on wedge top are not made.
'    - Screw thread is simplified (visible ridges in the slot portion);
'      pillar top hole is a plain M22-size hole.
'    - Parts are placed exactly by position (no mates). Do not drag parts.
'    - Axis of the tool post is vertical (Y). All API sizes are metres
'      internally - you only type MM.
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String
Private gTurretAxisName As String
Private gAssyAxisName As String            ' name of current step - shown in error message (for easy fixing)

' User dimensions (mm)
Private pillarD As Double          ' Pillar (body) diameter
Private pillarH As Double          ' Pillar total height
Private collarD As Double          ' Pillar bottom collar diameter
Private slotW As Double            ' Width of vertical slot in pillar
Private slotTop As Double          ' Slot top height from pillar bottom
Private blockSize As Double        ' Square block size (square side)
Private blockT As Double           ' Square block thickness
Private ringOD As Double           ' Ring outside diameter
Private ringT As Double            ' Ring thickness
Private wedgeL As Double           ' Wedge length
Private wedgeW As Double           ' Wedge width
Private wedgeT As Double           ' Wedge maximum thickness
Private toolSize As Double         ' Tool bit square size (height = width)
Private toolLen As Double          ' Tool bit length
Private screwD As Double           ' Clamp screw nominal diameter (e.g. 22 for M22)

' Calculated dimensions (mm)
Private collarT As Double          ' Collar thickness (fixed 10)
Private headTopD As Double         ' Pillar top diameter (after taper)
Private taperStart As Double       ' Height where pillar taper starts
Private slotBottom As Double       ' Slot bottom height (= block + ring top level)
Private toolTopY As Double         ' Top face height of the tool bit in assembly

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.5          ' clearance (mm) for recess & bolt holes (+1 on dia = 2x0.5)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Single Tool Post - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Single Tool Post"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Single Tool Post", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function



'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Single Tool Post"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

' Open a sketch on a named reference plane ("Top Plane" / "Right Plane").
Private Function OpenNamedSketch(ByVal oDoc As Object, ByVal sPlaneName As String) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2(sPlaneName, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select plane: " & sPlaneName & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Single Tool Post"
        OpenNamedSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True
    OpenNamedSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub


' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Single Tool Post"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Single Tool Post"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function


Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Single Tool Post"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

'------------------------- Hub keyway -------------------------

'------------------------- PART 1: Square block -------------------------
' Local origin = centre of bottom face. Thickness along +Y (up).
' Central hole for the pillar + counterbore underneath for the pillar collar.
Private Function MakeSquareBlock(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    ' Bottom rim: square frame with round recess for the pillar collar (boss only, no cut)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-blockSize / 2), Mm(-blockSize / 2), 0, Mm(blockSize / 2), Mm(blockSize / 2), 0)
    DrawCircle oDoc, 0, 0, collarD + 1
    If Not BossFromOpenSketch(oDoc, collarT, False, 0, "Block_Rim") Then Exit Function
    ' Top web: square plate with central hole for the pillar body
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-blockSize / 2), Mm(-blockSize / 2), 0, Mm(blockSize / 2), Mm(blockSize / 2), 0)
    DrawCircle oDoc, 0, 0, pillarD + 1
    If Not BossFromOpenSketch(oDoc, blockT - collarT, False, collarT, "Block_Web") Then Exit Function
    MakeSquareBlock = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 2: Pillar (body) -------------------------
' Local origin = centre of bottom face. Axis along +Y (up).
' Collar at bottom, round body, vertical through-slot, tapered head with
' a plain top hole for the clamp screw.
Private Function MakePillar(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim i As Long, segH As Double, segOD As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' Bottom collar
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, collarD
    If Not BossFromOpenSketch(oDoc, collarT, False, 0, "Collar") Then Exit Function
    ' Main body up to the slot top (solid)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pillarD
    If Not BossFromOpenSketch(oDoc, slotTop, False, 0, "Body") Then Exit Function
    ' Head, straight part (annulus - screw hole inside)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pillarD
    DrawCircle oDoc, 0, 0, screwD
    If Not BossFromOpenSketch(oDoc, taperStart - slotTop, False, slotTop, "Head") Then Exit Function
    ' Tapered top in 4 small steps (annulus each)
    segH = (pillarH - taperStart) / 4
    For i = 0 To 3
        segOD = pillarD - (pillarD - headTopD) * (i + 1) / 4
        If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
        DrawCircle oDoc, 0, 0, segOD
        DrawCircle oDoc, 0, 0, screwD
        If Not BossFromOpenSketch(oDoc, segH, False, taperStart + i * segH, "Taper_" & (i + 1)) Then Exit Function
    Next i
    ' Vertical slot through the body (sketch on Right Plane, cut along X)
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-slotW / 2), Mm(slotBottom), 0, Mm(slotW / 2), Mm(slotTop), 0)
    If Not CutThroughAllFromOpenSketch(oDoc, "Tool_Slot") Then Exit Function
    MakePillar = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 3: Ring -------------------------
' Local origin = centre of bottom face. Stepped dished (spherical) top seat.
Private Function MakeRing(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim id1 As Double, id2 As Double, id3 As Double, t1 As Double, t2 As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    id1 = pillarD + 1
    id2 = id1 + (ringOD - id1) * 0.35
    id3 = id1 + (ringOD - id1) * 0.7
    t1 = ringT * 0.5
    t2 = ringT * 0.25
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, ringOD
    DrawCircle oDoc, 0, 0, id1
    If Not BossFromOpenSketch(oDoc, t1, False, 0, "Ring_Base") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, ringOD
    DrawCircle oDoc, 0, 0, id2
    If Not BossFromOpenSketch(oDoc, t2, False, t1, "Ring_Mid") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, ringOD
    DrawCircle oDoc, 0, 0, id3
    If Not BossFromOpenSketch(oDoc, ringT - t1 - t2, False, t1 + t2, "Ring_Top") Then Exit Function
    MakeRing = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 4: Wedge (rocker) -------------------------
' Profile on Front Plane: X = length, Y = height. Extruded in Z by its width.
' Local origin = bottom-centre point of the wedge (front face).
Private Function MakeWedge(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim i As Long, nSeg As Long
    Dim sag As Double, rad As Double
    Dim x1 As Double, y1 As Double, x2 As Double, y2 As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    sag = wedgeT * 0.8
    rad = ((wedgeL / 2) * (wedgeL / 2) + sag * sag) / (2 * sag)
    nSeg = 12
    If Not OpenFrontSketch(oDoc) Then Exit Function
    ' top edge
    Call oDoc.SketchManager.CreateLine(Mm(-wedgeL / 2), Mm(wedgeT), 0, Mm(wedgeL / 2), Mm(wedgeT), 0)
    ' right side down to arc end
    Call oDoc.SketchManager.CreateLine(Mm(wedgeL / 2), Mm(wedgeT), 0, Mm(wedgeL / 2), Mm(sag), 0)
    ' convex bottom arc (straight segments), right to left
    For i = 0 To nSeg - 1
        x1 = wedgeL / 2 - i * wedgeL / nSeg
        x2 = wedgeL / 2 - (i + 1) * wedgeL / nSeg
        y1 = rad - Sqr(rad * rad - x1 * x1)
        y2 = rad - Sqr(rad * rad - x2 * x2)
        Call oDoc.SketchManager.CreateLine(Mm(x1), Mm(y1), 0, Mm(x2), Mm(y2), 0)
    Next i
    ' left side up
    Call oDoc.SketchManager.CreateLine(Mm(-wedgeL / 2), Mm(sag), 0, Mm(-wedgeL / 2), Mm(wedgeT), 0)
    If Not BossFromOpenSketch(oDoc, wedgeW, False, 0, "Wedge") Then Exit Function
    MakeWedge = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 5: Tool bit -------------------------
' Profile on Front Plane: X = length, Y = height. Extruded in Z (square section).
' Local origin = bottom-centre of the tool (front face). Tip is at +X end.
Private Function MakeToolBit(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim hL As Double, tipX As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    hL = toolLen / 2
    tipX = hL - toolSize
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateLine(Mm(-hL), 0, 0, Mm(tipX), 0, 0)
    Call oDoc.SketchManager.CreateLine(Mm(tipX), 0, 0, Mm(hL), Mm(toolSize * 0.35), 0)
    Call oDoc.SketchManager.CreateLine(Mm(hL), Mm(toolSize * 0.35), 0, Mm(hL), Mm(toolSize), 0)
    Call oDoc.SketchManager.CreateLine(Mm(hL), Mm(toolSize), 0, Mm(-hL), Mm(toolSize), 0)
    Call oDoc.SketchManager.CreateLine(Mm(-hL), Mm(toolSize), 0, Mm(-hL), 0, 0)
    If Not BossFromOpenSketch(oDoc, toolSize, False, 0, "Tool_Bit") Then Exit Function
    MakeToolBit = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 6: Clamp screw -------------------------
' Local origin = centre of the screw TIP (bottom). Axis along +Y.
' Pilot tip, threaded-look shank (ridges in the visible slot portion),
' collar and square head on top.
Private Function MakeClampScrew(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim pilotD As Double, coreD As Double, pilotH As Double
    Dim shankTop As Double, visLen As Double, pitch As Double
    Dim i As Long, z As Double, ridgeLen As Double
    Dim headSq As Double, headH As Double, colD As Double, colT As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    pilotD = screwD - 4
    If pilotD < 4 Then pilotD = screwD * 0.8
    coreD = screwD - 2.75
    If coreD < 4 Then coreD = screwD * 0.85
    pilotH = 8
    shankTop = pillarH - toolTopY              ' tip to pillar top face
    visLen = slotTop - toolTopY                ' shank length visible inside the slot
    pitch = screwD * 0.11
    If pitch < 1 Then pitch = 1
    headSq = screwD * 0.68
    headH = screwD * 0.68
    colD = screwD + 6
    colT = 6
    ' Pilot tip
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pilotD
    If Not BossFromOpenSketch(oDoc, pilotH, False, 0, "Pilot") Then Exit Function
    ' Shank core (minor diameter) up to the pillar top
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, coreD
    If Not BossFromOpenSketch(oDoc, shankTop - pilotH, False, pilotH, "Shank_Core") Then Exit Function
    ' Thread ridges (simplified) on the portion visible in the slot
    i = 0
    Do While (pilotH + i * pitch) < (visLen - 0.05)
        z = pilotH + i * pitch
        ridgeLen = 0.45 * pitch
        If z + ridgeLen > visLen Then ridgeLen = visLen - z
        If ridgeLen > 0.15 Then
            If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
            DrawCircle oDoc, 0, 0, screwD
            If Not BossFromOpenSketch(oDoc, ridgeLen, False, z, "Thread_" & (i + 1)) Then Exit Function
        End If
        i = i + 1
    Loop
    ' Collar above the pillar top
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, colD
    If Not BossFromOpenSketch(oDoc, colT, False, shankTop, "Collar") Then Exit Function
    ' Square head
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-headSq / 2), Mm(-headSq / 2), 0, Mm(headSq / 2), Mm(headSq / 2), 0)
    If Not BossFromOpenSketch(oDoc, headH, False, shankTop + colT, "Square_Head") Then Exit Function
    MakeClampScrew = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly -------------------------
' V4 FIX: AddComponent5 inserts a PRE-LOADED part, so first load the part
' file into memory (silent). 1 = swDocPART, 1 = swOpenDocOptions_Silent.
Private Function LoadPartForAssembly(ByVal sPath As String) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading part for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, 1, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this part file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Single Tool Post"
        LoadPartForAssembly = False
        Exit Function
    End If
    LoadPartForAssembly = True
End Function


' V5: check the actual position of a component by reading its transform back.
' Transform ArrayData: elements 9, 10, 11 = translation X, Y, Z (metres).
Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

' Insert one component and put its ORIGIN exactly at (xMm,yMm,zMm), no rotation.
' V5 FIX: move the component the recorded-macro way -
'   1) copy the 16-number transform array into a VARIANT variable,
'   2) CreateTransform((variant))  [double brackets are intentional],
'   3) SetTransformAndSolve2(...) to actually move+solve the component,
'   4) read the position back and verify it really moved.
Private Function PlaceComponent(ByVal oAsm As Object, ByVal sPath As String, _
                                ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Single Tool Post"
        PlaceComponent = False
        Exit Function
    End If
    ' Identity rotation + translation to (xMm, yMm, zMm)
    aData(0) = 1: aData(1) = 0: aData(2) = 0: aData(3) = 0
    aData(4) = 1: aData(5) = 0: aData(6) = 0: aData(7) = 0
    aData(8) = 1: aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    ' If still not at the required position, try the direct Transform2 method also.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        On Error Resume Next
        oComp.Transform2 = oXf
        On Error GoTo 0
    End If
    ' Final verification - do not silently save a wrong assembly.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        MsgBox "Component was inserted but could NOT be moved to its correct position:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Single Tool Post"
        PlaceComponent = False
        Exit Function
    End If
    PlaceComponent = True
End Function

Private Sub FixAllComponents(ByVal oAsm As Object)
    Dim vComps As Variant
    Dim j As Long
    Dim oComp As Object
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If Not IsArray(vComps) Then Exit Sub
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        If Not oComp Is Nothing Then
            On Error Resume Next
            oAsm.ClearSelection2 True
            If oComp.Select4(False, Nothing, False) Then oAsm.FixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

Private Function SelectForSTPMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                  ByVal sFeatName As String, ByVal sAltName As String, _
                                  ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then Set oFeat = oComp.FeatureByName(sAltName)
        If Not oFeat Is Nothing Then bOk = oFeat.Select2(bAppend, 1)
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectForSTPMate = bOk
End Function

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oTurret As Object, oAsm As Object, oFeat As Object, oMate As Object
    Dim oCompBlock As Object, oCompTurret As Object
    Dim vComps As Variant
    Dim pBlock As String, pPillar As String, pRing As String
    Dim pWedge As String, pTool As String, pScrew As String, pTurret As String
    Dim sTurretTitle As String, sAsmTitle As String
    Dim lErr As Long, lWarn As Long, lMateErr As Long
    pBlock = sFolder & "\Square_Block.SLDPRT"
    pPillar = sFolder & "\Pillar_Body.SLDPRT"
    pRing = sFolder & "\Ring.SLDPRT"
    pWedge = sFolder & "\Wedge.SLDPRT"
    pTool = sFolder & "\Tool_Bit.SLDPRT"
    pScrew = sFolder & "\Clamp_Screw.SLDPRT"
    pTurret = sFolder & "\Turret_Unit.SLDASM"

    ' 1) Build Turret_Unit.SLDASM (Pillar + Ring + Wedge + Tool_Bit + Clamp_Screw)
    gStep = "Creating Turret_Unit subassembly"
    Set oTurret = NewAssemblyDoc()
    If oTurret Is Nothing Then MsgBox "Could not create new Assembly.", vbCritical: Exit Function
    sTurretTitle = oTurret.GetTitle

    gTurretAxisName = "Axis1"
    oTurret.ClearSelection2 True
    If oTurret.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oTurret.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oTurret.InsertAxis2(True) Then
                oTurret.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oTurret.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gTurretAxisName = oFeat.Name
                    oFeat.Name = "Axis_Turret_Y"
                    gTurretAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oTurret.ClearSelection2 True

    If Not LoadPartForAssembly(pPillar) Then Exit Function
    If Not LoadPartForAssembly(pRing) Then Exit Function
    If Not LoadPartForAssembly(pWedge) Then Exit Function
    If Not LoadPartForAssembly(pTool) Then Exit Function
    If Not LoadPartForAssembly(pScrew) Then Exit Function
    swApp.ActivateDoc2 sTurretTitle, False, lErr

    If Not PlaceComponent(oTurret, pPillar, 0, 0, 0) Then Exit Function
    If Not PlaceComponent(oTurret, pRing, 0, blockT, 0) Then Exit Function
    If Not PlaceComponent(oTurret, pWedge, 0, slotBottom, -wedgeW / 2) Then Exit Function
    If Not PlaceComponent(oTurret, pTool, 10, slotBottom + wedgeT, -toolSize / 2) Then Exit Function
    If Not PlaceComponent(oTurret, pScrew, 0, toolTopY, 0) Then Exit Function

    Call FixAllComponents(oTurret)
    Call oTurret.ForceRebuild3(False)
    oTurret.SaveAs3 pTurret, 0, 0

    ' 2) Build main SingleToolPost.SLDASM (Fixed Square_Block + Swiveling Turret_Unit)
    gStep = "Creating main Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create new Assembly.", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle

    gAssyAxisName = "Axis1"
    oAsm.ClearSelection2 True
    If oAsm.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oAsm.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oAsm.InsertAxis2(True) Then
                oAsm.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oAsm.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gAssyAxisName = oFeat.Name
                    oFeat.Name = "Axis_Assy_Y"
                    gAssyAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oAsm.ClearSelection2 True

    If Not LoadPartForAssembly(pBlock) Then Exit Function
    Call swApp.OpenDoc6(pTurret, 2, 1, "", lErr, lWarn)
    swApp.ActivateDoc2 sAsmTitle, False, lErr

    If Not PlaceComponent(oAsm, pBlock, 0, 0, 0) Then Exit Function
    If Not PlaceComponent(oAsm, pTurret, 0, 0, 0) Then Exit Function

    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    If IsArray(vComps) Then
        If UBound(vComps) >= LBound(vComps) + 1 Then
            Set oCompBlock = vComps(LBound(vComps))
            Set oCompTurret = vComps(LBound(vComps) + 1)
            oAsm.ClearSelection2 True: If oCompBlock.Select4(False, Nothing, False) Then oAsm.FixComponent
            oAsm.ClearSelection2 True: If oCompTurret.Select4(False, Nothing, False) Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True
        End If
    End If
    If Not oCompTurret Is Nothing Then
        ' Mate 1: Axis_Turret_Y coincident with Axis_Assy_Y (360-deg swivel about vertical pillar axis)
        If SelectForSTPMate(oAsm, oCompTurret, gTurretAxisName, "Axis1", "AXIS", False) Then
            If SelectForSTPMate(oAsm, Nothing, gAssyAxisName, "Axis1", "AXIS", True) Then
                Set oMate = oAsm.AddMate5(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
                If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
                If Not oMate Is Nothing Then oMate.Name = "Pillar_Swivel_Axis_Mate"
            End If
        End If
        oAsm.ClearSelection2 True
        ' Mate 2: Top Plane coincident with Top Plane (keeps turret seated on the base block)
        If SelectForSTPMate(oAsm, oCompTurret, "Top Plane", "", "PLANE", False) Then
            If SelectForSTPMate(oAsm, Nothing, "Top Plane", "", "PLANE", True) Then
                Set oMate = oAsm.AddMate5(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
                If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
                If Not oMate Is Nothing Then oMate.Name = "Base_Seat_Mate"
            End If
        End If
        oAsm.ClearSelection2 True
    End If
    oAsm.SetUserPreferenceToggle 4, False
    oAsm.SetUserPreferenceToggle 5, False
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\SingleToolPost.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Turret_Unit.SLDASM"
    swApp.CloseDoc "Square_Block.SLDPRT"
    swApp.CloseDoc "Pillar_Body.SLDPRT"
    swApp.CloseDoc "Ring.SLDPRT"
    swApp.CloseDoc "Wedge.SLDPRT"
    swApp.CloseDoc "Tool_Bit.SLDPRT"
    swApp.CloseDoc "Clamp_Screw.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    ValidateDims = False
    If pillarD < 25 Then MsgBox "Pillar diameter is too small (minimum 25 mm).", vbCritical: Exit Function
    If collarD <= pillarD + 6 Then MsgBox "Collar diameter must be at least pillar diameter + 6 mm.", vbCritical: Exit Function
    If collarD + 5 >= blockSize Then MsgBox "Collar will not fit inside the square block. Increase block size or reduce collar dia.", vbCritical: Exit Function
    If blockT < collarT + 3 Then MsgBox "Block thickness must be at least collar thickness (10) + 3 mm.", vbCritical: Exit Function
    If slotW <= wedgeW + 2 Or slotW <= toolSize + 2 Then MsgBox "Slot width must be at least 2 mm more than wedge width and tool size.", vbCritical: Exit Function
    If slotW >= pillarD - 10 Then MsgBox "Slot is too wide - the pillar sides will become too thin.", vbCritical: Exit Function
    If slotTop <= blockT + ringT + wedgeT + toolSize + 10 Then MsgBox "Slot top is too low - no room for wedge + tool + screw. Increase slot top / pillar height.", vbCritical: Exit Function
    If pillarH < slotTop + 45 Then MsgBox "Pillar height must be at least slot top + 45 mm (for the head and taper).", vbCritical: Exit Function
    If ringOD <= pillarD + 20 Then MsgBox "Ring diameter must be at least pillar diameter + 20 mm.", vbCritical: Exit Function
    If ringT < 6 Then MsgBox "Ring thickness is too small (minimum 6 mm).", vbCritical: Exit Function
    If wedgeL < ringOD Then MsgBox "Wedge length should be more than the ring diameter.", vbCritical: Exit Function
    If screwD >= pillarD * 0.64 - 6 Then MsgBox "Clamp screw is too big for the pillar head. Reduce screw dia or increase pillar dia.", vbCritical: Exit Function
    If toolLen < wedgeL Then MsgBox "Tool length should be more than the wedge length.", vbCritical: Exit Function
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "SINGLE TOOL POST MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Textbook standard values are already filled - press OK" & vbCrLf & _
           "to accept, or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old SingleToolPost files that are open.", _
           vbInformation, "Single Tool Post"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\SingleToolPost"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\SingleToolPost"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = textbook drawing values) ----
    gCancelled = False
    pillarD = AskNum("1) Pillar (body) diameter (mm)", 50)
    If gCancelled Then Exit Sub
    pillarH = AskNum("2) Pillar total height (mm)", 150)
    If gCancelled Then Exit Sub
    collarD = AskNum("3) Pillar bottom collar diameter (mm)", 62)
    If gCancelled Then Exit Sub
    slotW = AskNum("4) Slot width in pillar (mm)" & vbCrLf & "Tool and wedge pass through this slot.", 22)
    If gCancelled Then Exit Sub
    slotTop = AskNum("5) Slot TOP height from pillar bottom (mm)", 96)
    If gCancelled Then Exit Sub
    blockSize = AskNum("6) Square block size - side of square (mm)", 76)
    If gCancelled Then Exit Sub
    blockT = AskNum("7) Square block thickness (mm)", 14)
    If gCancelled Then Exit Sub
    ringOD = AskNum("8) Ring outside diameter (mm)", 100)
    If gCancelled Then Exit Sub
    ringT = AskNum("9) Ring thickness (mm)", 12)
    If gCancelled Then Exit Sub
    wedgeL = AskNum("10) Wedge length (mm)", 120)
    If gCancelled Then Exit Sub
    wedgeW = AskNum("11) Wedge width (mm)", 18)
    If gCancelled Then Exit Sub
    wedgeT = AskNum("12) Wedge maximum thickness (mm)", 16)
    If gCancelled Then Exit Sub
    toolSize = AskNum("13) Tool bit square size (mm)" & vbCrLf & "Height and width of the tool shank.", 18)
    If gCancelled Then Exit Sub
    toolLen = AskNum("14) Tool bit length (mm)", 140)
    If gCancelled Then Exit Sub
    screwD = AskNum("15) Clamp screw diameter (mm) - 22 for M22", 22)
    If gCancelled Then Exit Sub

    collarT = 10
    If Not ValidateDims() Then Exit Sub

    ' ---- Calculated values ----
    headTopD = Round(pillarD * 0.64)
    taperStart = pillarH - 40
    slotBottom = blockT + ringT
    toolTopY = slotBottom + wedgeT + toolSize

    ' ---- Summary + confirmation ----
    sSummary = "Model will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Pillar dia x height  = " & pillarD & " x " & pillarH & vbCrLf & _
        "Collar dia           = " & collarD & vbCrLf & _
        "Slot (W, bottom-top) = " & slotW & ", " & slotBottom & " to " & slotTop & vbCrLf & _
        "Square block         = " & blockSize & " x " & blockSize & " x " & blockT & vbCrLf & _
        "Ring dia x thk       = " & ringOD & " x " & ringT & vbCrLf & _
        "Wedge L x W x T      = " & wedgeL & " x " & wedgeW & " x " & wedgeT & vbCrLf & _
        "Tool bit             = " & toolLen & " long, " & toolSize & " square" & vbCrLf & _
        "Clamp screw          = M" & screwD & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Single Tool Post - Confirm") = vbCancel Then Exit Sub

    ' ---- Build all parts ----
    gStep = "Making Square Block"
    If Not MakeSquareBlock(sFolder & "\Square_Block.SLDPRT") Then Exit Sub
    gStep = "Making Pillar Body"
    If Not MakePillar(sFolder & "\Pillar_Body.SLDPRT") Then Exit Sub
    gStep = "Making Ring"
    If Not MakeRing(sFolder & "\Ring.SLDPRT") Then Exit Sub
    gStep = "Making Wedge"
    If Not MakeWedge(sFolder & "\Wedge.SLDPRT") Then Exit Sub
    gStep = "Making Tool Bit"
    If Not MakeToolBit(sFolder & "\Tool_Bit.SLDPRT") Then Exit Sub
    gStep = "Making Clamp Screw"
    If Not MakeClampScrew(sFolder & "\Clamp_Screw.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 6 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Single Tool Post"
        Exit Sub
    End If

    MsgBox "DONE!  Single Tool Post model is ready." & vbCrLf & vbCrLf & _
           "Assembly open now:  SingleToolPost.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           "Parts: Square Block, Pillar, Ring, Wedge, Tool Bit, Clamp Screw." & vbCrLf & vbCrLf & _
           "EXAM POINT: it holds ONE tool. Tool rests on the wedge, wedge" & vbCrLf & _
           "on the ring - sliding the wedge adjusts the tool-tip height." & vbCrLf & vbCrLf & _
           "Use mouse to rotate. Press Ctrl+7 for isometric view if needed." & vbCrLf & _
           "HOW TO MOVE IT: Drag the Tool Bit or Pillar with the mouse - the turret swivels 360 deg on the stationary Square Block!", _
           vbInformation, "Single Tool Post"
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Single Tool Post Version 2)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Single Tool Post - Error"
End Sub
