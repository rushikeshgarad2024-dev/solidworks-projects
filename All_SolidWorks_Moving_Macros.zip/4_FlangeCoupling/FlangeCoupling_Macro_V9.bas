'=====================================================================================
'  FLANGE COUPLING MACRO  -  VERSION 9 (THREADS + MOVING KINEMATIC MATES)
'  Standard Rigid Flange Coupling - Full Assembly
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'  V5 FIX (parts at wrong position in assembly): components are now
'  moved the recorded-macro way. The 16-number position array is first
'  copied to a Variant, then CreateTransform((variant)), then
'  SetTransformAndSolve2 to move the component, and the position is
'  READ BACK and verified for every component. V4 set only Transform2
'  with a typed array, which left bolts/nuts/keys at the origin.
'  V4 fix kept: all 6 parts are loaded (OpenDoc6) before inserting.
'  V3 fix kept: block If...ElseIf on separate lines.
'  V2 fixes kept: extrude/cut tries twice; clear STEP error message.
'  V6 NEW: after the assembly, the macro can also create the MOTION STUDY.
'  It floats the parts and writes rotation keys (all parts rotate together
'  about the shaft axis Z), verifies the keys really recorded, and only if
'  that fails it creates a "Rotate Model" animation in a second study.
'  Just press "Play from Start" in the Motion Study tab to see it rotate.
'  V7 FIX (parts drifted here-and-there during V6 rotation): the finished
'  assembly is now inserted as ONE rigid component inside a second file
'  (FlangeCoupling_Motion.SLDASM) and only that single body is rotated,
'  so parts can never move relative to each other. Model file is untouched.
'  V8: bolt + nut now have VISIBLE simplified thread ridges with standard
'  coarse pitch (e.g. M12 x 1.75). Nut ridges are phased to sit inside the
'  bolt grooves (no interference). Bolt-count pop-up made clearer - type
'  4 if you want four bolts. Whole code re-checked; 2 validation checks added.
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old FlangeCoupling files if open.
'     2) Tools > Macro > New  -> save as  FlangeCoupling.swp  (anywhere)
'     3) The macro editor opens. Select ALL old code (Ctrl+A), Delete,
'        then paste THIS FULL CODE.
'     4) Press F5  (or click the green Run / Play button).
'     5) Small pop-up boxes will ask your dimensions one by one (in mm).
'        A standard value is already filled - just press OK/Enter to accept it,
'        or type your own value from your drawing / design calculation.
'     6) Wait. The macro will automatically create:
'            Flange_A_Driving.SLDPRT   (flange with SPIGOT - male projection)
'            Flange_B_Driven.SLDPRT    (flange with RECESS - female socket)
'            Shaft.SLDPRT              (used 2 times)
'            Key.SLDPRT                (used 2 times)
'            Bolt.SLDPRT               (hex head bolt WITH thread on the end)
'            Nut.SLDPRT                (hex nut WITH internal thread)
'            FlangeCoupling.SLDASM     (all parts placed in correct position)
'            FlangeCoupling_Motion.SLDASM (only if you say YES to motion study)
'        All files are saved in the folder you choose in the first pop-up
'        (default: Documents\FlangeCoupling).
'
'  DEFAULT DIMENSIONS = standard proportions (Khurmi / R.S. Khurmi, Machine Design):
'        Hub diameter   = 2d      Hub length       = 1.5d   (total, see note below)
'        Flange dia.    = 4d      Flange thickness = 0.5d
'        Bolt PCD       = 3d      Spigot dia.      = 1.5d
'        (d = shaft diameter)
'
'  NOTE on HUB LENGTH: In this macro Hub Length is the TOTAL length of one
'  flange half, measured from the mating (joining) face to the end of the hub.
'  It INCLUDES the flange thickness. So default total length of each half = 1.5d.
'
'  NOTES (simplifications, normal for student models):
'    - Thread is a SIMPLIFIED visible ridge type (standard coarse pitch),
'      not a true helical thread - it looks threaded and keeps the macro reliable.
'    - Shaft has no separate keyseat groove - the key sits half in the shaft,
'      half in the hub keyway (looks correct in assembly).
'    - Parts in the assembly are placed exactly by position (Transform),
'      no mates are added. Do not drag parts after opening, or add mates
'      (Coincident / Concentric) if your teacher asks for mates.
'    - If you say YES to the motion study, a second file is made:
'      FlangeCoupling_Motion.SLDASM. Your model assembly stays untouched.
'      Keep all files in the same folder (motion file uses the model file).
'    - All API sizes are in METRES internally, you only type MM.
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String            ' name of current step - shown in error message (for easy fixing)
Private gAsmDoc As Object          ' V6: the finished assembly document (for the motion study)
Private gMotionOK As Boolean       ' V6: True when the motion study was created
Private gMotionMsg As String
Private gRotorAxisName As String
Private gAssyAxisName As String       ' V6: short motion-study result text for the final message

' User dimensions (mm)
Private dShaft As Double           ' Shaft / bore diameter  d
Private dHub As Double             ' Hub outside diameter
Private lHub As Double             ' Hub length (TOTAL, mating face to hub end, incl. flange thk)
Private dFlange As Double          ' Flange outside diameter
Private tFlange As Double          ' Flange thickness
Private dPCD As Double             ' Pitch circle diameter of bolts
Private dSpigot As Double          ' Spigot / recess diameter
Private nBolts As Long             ' Number of bolts
Private dBolt As Double            ' Bolt shank diameter
Private lShaftExp As Double        ' Visible shaft length outside hub (each side)
Private wKey As Double             ' Key width
Private hKey As Double             ' Key height (thickness)

' Calculated dimensions (mm)
Private spigotLen As Double        ' Spigot projection / recess depth
Private shaftPartLen As Double     ' Total length of one Shaft part
Private keyLen As Double           ' Key length
Private headH As Double, headAF As Double   ' Bolt head height / across-flats
Private nutH As Double, nutAF As Double     ' Nut height / across-flats

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.5          ' clearance (mm) for recess & bolt holes (+1 on dia = 2x0.5)
Private Const SHAFT_GAP As Double = 2      ' small gap between the two shaft ends at centre (mm)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Flange Coupling - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Flange Coupling"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Flange Coupling", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function

Private Function StdKeyWidth(ByVal d As Double) As Double
    ' Approximate standard parallel key width for shaft diameter d
    Select Case d
        Case Is <= 22: StdKeyWidth = 6
        Case Is <= 30: StdKeyWidth = 8
        Case Is <= 38: StdKeyWidth = 10
        Case Is <= 44: StdKeyWidth = 12
        Case Is <= 50: StdKeyWidth = 14
        Case Is <= 58: StdKeyWidth = 16
        Case Is <= 65: StdKeyWidth = 18
        Case Else:     StdKeyWidth = 20
    End Select
End Function

Private Function ThreadPitchFor(ByVal d As Double) As Double
    ' Standard ISO metric COARSE thread pitch (mm) for nominal bolt diameter d
    Select Case d
        Case Is <= 5:  ThreadPitchFor = 0.8
        Case Is <= 6:  ThreadPitchFor = 1
        Case Is <= 8:  ThreadPitchFor = 1.25
        Case Is <= 10: ThreadPitchFor = 1.5
        Case Is <= 12: ThreadPitchFor = 1.75
        Case Is <= 16: ThreadPitchFor = 2
        Case Is <= 22: ThreadPitchFor = 2.5
        Case Is <= 27: ThreadPitchFor = 3
        Case Is <= 33: ThreadPitchFor = 3.5
        Case Is <= 39: ThreadPitchFor = 4
        Case Is <= 45: ThreadPitchFor = 4.5
        Case Else:     ThreadPitchFor = 5
    End Select
End Function

'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Flange Coupling"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub

Private Sub DrawHex(ByVal oDoc As Object, ByVal acrossFlatsMm As Double)
    ' Regular hexagon, centre at origin. Vertex radius R = AF / sqrt(3).
    ' CreatePolygon(Xc,Yc,Zc, Xvertex,Yvertex,Zvertex, Sides, Inscribed)
    Dim R As Double
    Dim vPoly As Variant
    R = acrossFlatsMm / 1.73205080756888
    vPoly = oDoc.SketchManager.CreatePolygon(0, 0, 0, Mm(R), 0, 0, 6, True)
End Sub

' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Flange Coupling"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Flange Coupling"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function

Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Flange Coupling"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

'------------------------- Common flange cuts: bolt holes + keyway -------------------------
Private Function AddBoltHolesAndKeyway(ByVal oDoc As Object) As Boolean
    Dim i As Long, ang As Double, cx As Double, cy As Double
    Dim y1 As Double, y2 As Double
    ' --- Bolt holes: all holes in ONE sketch (no pattern feature needed) ---
    If Not OpenFrontSketch(oDoc) Then Exit Function
    For i = 0 To nBolts - 1
        ang = 2# * PI_VAL * i / nBolts
        cx = (dPCD / 2) * Cos(ang)
        cy = (dPCD / 2) * Sin(ang)
        DrawCircle oDoc, cx, cy, dBolt + 2 * CLR      ' hole = bolt dia + 1 mm clearance
    Next i
    If Not CutThroughAllFromOpenSketch(oDoc, "Bolt_Holes") Then Exit Function
    ' --- Keyway in hub bore (rectangular slot on top of bore) ---
    If Not OpenFrontSketch(oDoc) Then Exit Function
    y1 = dShaft / 2 - 2                               ' start slightly inside the bore
    y2 = dShaft / 2 + hKey / 2 + CLR                  ' hub keyway depth ~ half key height
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(y1), 0, Mm(wKey / 2), Mm(y2), 0)
    If Not CutThroughAllFromOpenSketch(oDoc, "Keyway") Then Exit Function
    AddBoltHolesAndKeyway = True
End Function

'------------------------- PART 1: Flange A (driving, with spigot) -------------------------
' Local origin = mating face. Flange+hub go in -Z, spigot sticks out in +Z.
Private Function MakeFlangeA(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    ' 1) Flange disc (annulus: flange OD + bore), reversed (-Z), depth = flange thickness
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dFlange
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, tFlange, True, 0, "Flange_Disc") Then Exit Function
    ' 2) Hub (annulus: hub OD + bore), reversed (-Z), depth = total hub length
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dHub
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, lHub, True, 0, "Hub") Then Exit Function
    ' 3) Spigot (annulus: spigot dia + bore), forward (+Z)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dSpigot
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, spigotLen, False, 0, "Spigot") Then Exit Function
    ' 4) Bolt holes + keyway
    If Not AddBoltHolesAndKeyway(oDoc) Then Exit Function
    MakeFlangeA = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 2: Flange B (driven, with recess) -------------------------
' Local origin = mating face. Everything goes in +Z.
' Recess is made WITHOUT a cut: first a ring, then the rest starts after the recess depth.
Private Function MakeFlangeB(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    ' 1) Recess ring (flange OD + recess dia), depth = recess depth.
    '    The empty middle of this ring IS the recess (socket).
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dFlange
    DrawCircle oDoc, 0, 0, dSpigot + 2 * CLR
    If Not BossFromOpenSketch(oDoc, spigotLen, False, 0, "Recess_Ring") Then Exit Function
    ' 2) Rest of flange disc (flange OD + bore), starting after recess depth
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dFlange
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, tFlange - spigotLen, False, spigotLen, "Flange_Disc") Then Exit Function
    ' 3) Hub (hub OD + bore), also starting after recess depth, up to total hub length
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dHub
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, lHub - spigotLen, False, spigotLen, "Hub") Then Exit Function
    ' 4) Bolt holes + keyway
    If Not AddBoltHolesAndKeyway(oDoc) Then Exit Function
    MakeFlangeB = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 3: Shaft -------------------------
' Local: from Z=0 to Z=shaftPartLen along +Z.
Private Function MakeShaft(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, shaftPartLen, False, 0, "Shaft") Then Exit Function
    MakeShaft = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 4: Key -------------------------
' Local: rectangle (width x height) centred on origin, extruded +Z by key length.
Private Function MakeKey(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(-hKey / 2), 0, Mm(wKey / 2), Mm(hKey / 2), 0)
    If Not BossFromOpenSketch(oDoc, keyLen, False, 0, "Key") Then Exit Function
    MakeKey = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 5: Hex head bolt -------------------------
' Local: origin at OUTER face of head. Head, then plain shank, then threaded end (V8).
Private Function MakeBolt(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim p As Double, coreDia As Double, extra As Double
    Dim totalLen As Double, threadStart As Double, threadLen As Double
    Dim i As Long, z As Double, ridgeLen As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' Head (hexagon)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawHex oDoc, headAF
    If Not BossFromOpenSketch(oDoc, headH, False, 0, "Bolt_Head") Then Exit Function
    ' V8 thread data: standard coarse pitch. Threaded part = from the nut face
    ' to the end of the bolt (plain shank stays inside the two flanges).
    p = ThreadPitchFor(dBolt)
    coreDia = dBolt - 1.1 * p                    ' thread root (minor) diameter
    If coreDia < dBolt * 0.5 Then coreDia = dBolt * 0.5
    extra = 3                                    ' bolt end sticking out of the nut
    If 1.5 * p > extra Then extra = 1.5 * p
    totalLen = headH + 2 * tFlange + nutH + extra
    threadStart = headH + 2 * tFlange
    threadLen = totalLen - threadStart
    ' Plain shank (full diameter) up to the thread start
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dBolt
    If Not BossFromOpenSketch(oDoc, threadStart, False, 0, "Bolt_Shank") Then Exit Function
    ' Thread core (minor diameter) for the threaded length
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, coreDia
    If Not BossFromOpenSketch(oDoc, threadLen, False, threadStart, "Thread_Core") Then Exit Function
    ' Thread ridges: short full-diameter rings, one every pitch (simplified thread)
    i = 0
    Do While (i * p) < (threadLen - 0.05)
        z = threadStart + i * p
        ridgeLen = 0.45 * p
        If z + ridgeLen > totalLen Then ridgeLen = totalLen - z
        If ridgeLen > 0.15 Then
            If Not OpenFrontSketch(oDoc) Then Exit Function
            DrawCircle oDoc, 0, 0, dBolt
            If Not BossFromOpenSketch(oDoc, ridgeLen, False, z, "Thread_" & (i + 1)) Then Exit Function
        End If
        i = i + 1
    Loop
    MakeBolt = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 6: Hex nut -------------------------
' Local: hexagon with centre hole, extruded +Z.
Private Function MakeNut(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim p As Double, rootDia As Double, ridgeInner As Double
    Dim i As Long, z As Double, ridgeLen As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' V8: nut hole = thread ROOT diameter (just above bolt major diameter),
    ' then internal ridges are added inside it.
    p = ThreadPitchFor(dBolt)
    rootDia = dBolt + 0.4
    ridgeInner = (dBolt - 1.1 * p) + 0.3         ' = bolt core dia + small clearance
    If ridgeInner < 1 Then ridgeInner = 1
    If ridgeInner > rootDia - 0.4 Then ridgeInner = rootDia - 0.4
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawHex oDoc, nutAF
    DrawCircle oDoc, 0, 0, rootDia
    If Not BossFromOpenSketch(oDoc, nutH, False, 0, "Nut") Then Exit Function
    ' Internal thread ridges, shifted half a pitch so they sit inside the
    ' bolt thread grooves when assembled (no interference).
    i = 0
    Do While (0.5 * p + i * p) < (nutH - 0.05)
        z = 0.5 * p + i * p
        ridgeLen = 0.45 * p
        If z + ridgeLen > nutH Then ridgeLen = nutH - z
        If ridgeLen > 0.15 Then
            If Not OpenFrontSketch(oDoc) Then Exit Function
            DrawCircle oDoc, 0, 0, rootDia + 2
            DrawCircle oDoc, 0, 0, ridgeInner
            If Not BossFromOpenSketch(oDoc, ridgeLen, False, z, "Nut_Thread_" & (i + 1)) Then Exit Function
        End If
        i = i + 1
    Loop
    MakeNut = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly -------------------------
' V4 FIX: AddComponent5 inserts a PRE-LOADED part, so first load the part
' file into memory (silent). 1 = swDocPART, 1 = swOpenDocOptions_Silent.
Private Function LoadPartForAssembly(ByVal sPath As String) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading part for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, 1, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this part file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Flange Coupling"
        LoadPartForAssembly = False
        Exit Function
    End If
    LoadPartForAssembly = True
End Function


' V5: check the actual position of a component by reading its transform back.
' Transform ArrayData: elements 9, 10, 11 = translation X, Y, Z (metres).
Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

' Insert one component and put its ORIGIN exactly at (xMm,yMm,zMm), no rotation.
' V5 FIX: move the component the recorded-macro way -
'   1) copy the 16-number transform array into a VARIANT variable,
'   2) CreateTransform((variant))  [double brackets are intentional],
'   3) SetTransformAndSolve2(...) to actually move+solve the component,
'   4) read the position back and verify it really moved.
Private Function PlaceComponent(ByVal oAsm As Object, ByVal sPath As String, _
                                ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Flange Coupling"
        PlaceComponent = False
        Exit Function
    End If
    ' Identity rotation + translation to (xMm, yMm, zMm)
    aData(0) = 1: aData(1) = 0: aData(2) = 0: aData(3) = 0
    aData(4) = 1: aData(5) = 0: aData(6) = 0: aData(7) = 0
    aData(8) = 1: aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    ' If still not at the required position, try the direct Transform2 method also.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        On Error Resume Next
        oComp.Transform2 = oXf
        On Error GoTo 0
    End If
    ' Final verification - do not silently save a wrong assembly.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        MsgBox "Component was inserted but could NOT be moved to its correct position:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Flange Coupling"
        PlaceComponent = False
        Exit Function
    End If
    PlaceComponent = True
End Function

Private Sub FixAllComponents(ByVal oAsm As Object)
    Dim vComps As Variant
    Dim j As Long
    Dim oComp As Object
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If Not IsArray(vComps) Then Exit Sub
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        If Not oComp Is Nothing Then
            On Error Resume Next
            oAsm.ClearSelection2 True
            If oComp.Select4(False, Nothing, False) Then oAsm.FixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

Private Function SelectForFlangeMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                     ByVal sFeatName As String, ByVal sAltName As String, _
                                     ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then Set oFeat = oComp.FeatureByName(sAltName)
        If Not oFeat Is Nothing Then bOk = oFeat.Select2(bAppend, 1)
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectForFlangeMate = bOk
End Function

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oRotor As Object, oAsm As Object, oCompRotor As Object, oFeat As Object, oMate As Object
    Dim vComps As Variant
    Dim pA As String, pB As String, pShaft As String, pKey As String, pBolt As String, pNut As String
    Dim pRotor As String
    Dim i As Long, ang As Double, bx As Double, by As Double
    Dim sRotorTitle As String, sAsmTitle As String
    Dim lErr As Long, lWarn As Long, lMateErr As Long
    pA = sFolder & "\Flange_A_Driving.SLDPRT"
    pB = sFolder & "\Flange_B_Driven.SLDPRT"
    pShaft = sFolder & "\Shaft.SLDPRT"
    pKey = sFolder & "\Key.SLDPRT"
    pBolt = sFolder & "\Bolt.SLDPRT"
    pNut = sFolder & "\Nut.SLDPRT"
    pRotor = sFolder & "\Flange_Rotor_Unit.SLDASM"

    gStep = "Creating Flange_Rotor_Unit subassembly"
    Set oRotor = NewAssemblyDoc()
    If oRotor Is Nothing Then MsgBox "Could not create new Assembly (check default Assembly template).", vbCritical: Exit Function
    sRotorTitle = oRotor.GetTitle

    ' Create Z rotation axis in Flange_Rotor_Unit
    gRotorAxisName = "Axis1"
    oRotor.ClearSelection2 True
    If oRotor.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oRotor.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oRotor.InsertAxis2(True) Then
                oRotor.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oRotor.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gRotorAxisName = oFeat.Name
                    oFeat.Name = "Axis_Rotor_Z"
                    gRotorAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oRotor.ClearSelection2 True

    If Not LoadPartForAssembly(pA) Then Exit Function
    If Not LoadPartForAssembly(pB) Then Exit Function
    If Not LoadPartForAssembly(pShaft) Then Exit Function
    If Not LoadPartForAssembly(pKey) Then Exit Function
    If Not LoadPartForAssembly(pBolt) Then Exit Function
    If Not LoadPartForAssembly(pNut) Then Exit Function
    swApp.ActivateDoc2 sRotorTitle, False, lErr

    If Not PlaceComponent(oRotor, pA, 0, 0, 0) Then Exit Function
    If Not PlaceComponent(oRotor, pB, 0, 0, 0) Then Exit Function
    If Not PlaceComponent(oRotor, pShaft, 0, 0, -SHAFT_GAP - shaftPartLen) Then Exit Function
    If Not PlaceComponent(oRotor, pShaft, 0, 0, SHAFT_GAP) Then Exit Function
    If Not PlaceComponent(oRotor, pKey, 0, dShaft / 2, -lHub + 5) Then Exit Function
    If Not PlaceComponent(oRotor, pKey, 0, dShaft / 2, 5) Then Exit Function
    For i = 0 To nBolts - 1
        ang = 2# * PI_VAL * i / nBolts
        bx = (dPCD / 2) * Cos(ang)
        by = (dPCD / 2) * Sin(ang)
        If Not PlaceComponent(oRotor, pBolt, bx, by, -tFlange - headH) Then Exit Function
        If Not PlaceComponent(oRotor, pNut, bx, by, tFlange) Then Exit Function
    Next i

    ' Fix all bolted parts inside Flange_Rotor_Unit so they rotate together as one solid body
    Call FixAllComponents(oRotor)
    Call oRotor.ForceRebuild3(False)
    oRotor.SaveAs3 pRotor, 0, 0

    ' Now create main assembly FlangeCoupling.SLDASM with Revolute Bearing Mates on the Z axis
    gStep = "Creating main Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create main Assembly.", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle
    Set gAsmDoc = oAsm

    gAssyAxisName = "Axis1"
    oAsm.ClearSelection2 True
    If oAsm.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oAsm.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oAsm.InsertAxis2(True) Then
                oAsm.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oAsm.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gAssyAxisName = oFeat.Name
                    oFeat.Name = "Axis_Assy_Z"
                    gAssyAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oAsm.ClearSelection2 True

    Call swApp.OpenDoc6(pRotor, 2, 1, "", lErr, lWarn)
    swApp.ActivateDoc2 sAsmTitle, False, lErr
    If Not PlaceComponent(oAsm, pRotor, 0, 0, 0) Then Exit Function

    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    If IsArray(vComps) Then
        Call FloatFixedComponents(oAsm, vComps)
        Set oCompRotor = vComps(LBound(vComps))
    End If
    If Not oCompRotor Is Nothing Then
        ' Mate 1: Axis_Rotor_Z coincident with Axis_Assy_Z
        oAsm.ClearSelection2 True
        If SelectForFlangeMate(oAsm, oCompRotor, gRotorAxisName, "Axis1", "AXIS", False) Then
            If SelectForFlangeMate(oAsm, Nothing, gAssyAxisName, "Axis1", "AXIS", True) Then
                Set oMate = oAsm.AddMate5(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
                If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 2, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
                If Not oMate Is Nothing Then oMate.Name = "Shaft_Axis_Bearing_Mate"
            End If
        End If
        ' Mate 2: Front Plane coincident with Front Plane
        oAsm.ClearSelection2 True
        If SelectForFlangeMate(oAsm, oCompRotor, "Front Plane", "", "PLANE", False) Then
            If SelectForFlangeMate(oAsm, Nothing, "Front Plane", "", "PLANE", True) Then
                Set oMate = oAsm.AddMate5(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
                If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
                If Not oMate Is Nothing Then oMate.Name = "Axial_Position_Lock_Mate"
            End If
        End If
        oAsm.ClearSelection2 True
    End If
    oAsm.SetUserPreferenceToggle 4, False
    oAsm.SetUserPreferenceToggle 5, False
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\FlangeCoupling.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Flange_Rotor_Unit.SLDASM"
    swApp.CloseDoc "Flange_A_Driving.SLDPRT"
    swApp.CloseDoc "Flange_B_Driven.SLDPRT"
    swApp.CloseDoc "Shaft.SLDPRT"
    swApp.CloseDoc "Key.SLDPRT"
    swApp.CloseDoc "Bolt.SLDPRT"
    swApp.CloseDoc "Nut.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'=====================================================================================
'  V7 - MOTION STUDY
'  Type created = Animation (works in every SolidWorks, no Motion add-in needed).
'  Method: the finished coupling assembly is inserted as ONE rigid component
'  into a new file FlangeCoupling_Motion.SLDASM, and only that one component
'  is rotated about the Z (shaft) axis using animation keys. Because it is a
'  single rigid body, all parts stay perfectly together during rotation.
'  The result is VERIFIED by jumping to a quarter-turn time and reading the
'  rotation back. If keys did not record, a "Rotate Model" study is made.
'=====================================================================================

' Move one component to the given transform (same two methods as PlaceComponent).
Private Sub SetCompTransform(ByVal oComp As Object, ByVal oXf As Object)
    Dim bOk As Boolean
    bOk = False
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    If Err.Number <> 0 Or Not bOk Then
        Err.Clear
        oComp.Transform2 = oXf
    End If
    On Error GoTo 0
End Sub

' True if the component origin is at the translation stored inside oXf.
Private Function CompAtTransform(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vE As Variant
    On Error Resume Next
    vE = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vE) Then Exit Function
    CompAtTransform = CompAtPosition(oComp, vE(9) * 1000#, vE(10) * 1000#, vE(11) * 1000#)
End Function

' Fixed components cannot move in a motion study - float them.
Private Sub FloatFixedComponents(ByVal oAsm As Object, ByVal vComps As Variant)
    Dim j As Long
    Dim oComp As Object
    Dim bSel As Boolean, bFixed As Boolean
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        bFixed = False
        On Error Resume Next
        bFixed = oComp.IsFixed
        On Error GoTo 0
        If bFixed Then
            bSel = False
            On Error Resume Next
            oAsm.ClearSelection2 True
            bSel = oComp.Select4(False, Nothing, False)
            If bSel Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

' True if the component rotation (first 9 transform values) matches oXf.
Private Function CompRotationAt(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vNow As Variant, vExp As Variant
    Dim i As Long
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    vExp = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Not IsArray(vExp) Then Exit Function
    For i = 0 To 8
        If Abs(vNow(i) - vExp(i)) > 0.02 Then Exit Function
    Next i
    CompRotationAt = True
End Function

' V7: make FlangeCoupling_Motion.SLDASM with the finished coupling assembly
' inside it as ONE rigid component, then rotate that one component.
Private Function MakeMotionStudy(ByVal sFolder As String, _
                                 ByVal rpm As Double, ByVal durationSec As Double) As Boolean
    Dim oWrap As Object, oComp As Object
    Dim oMgr As Object, oStudy As Object, oStudy2 As Object
    Dim oMU As Object, oPt As Object, oVec As Object
    Dim oRot As Object, oNew As Object, oOrigXf As Object, oIdXf As Object
    Dim vComps As Variant
    Dim aId(0 To 15) As Double
    Dim vId As Variant
    Dim aPt(0 To 2) As Double, aVec(0 To 2) As Double
    Dim vPt As Variant, vVec As Variant
    Dim sMainAsm As String, sMotionAsm As String
    Dim k As Long, nSteps As Long, kTest As Long
    Dim totalTurns As Double, ang As Double, tNow As Double
    Dim bKeysOK As Boolean, bRotOK As Boolean
    MakeMotionStudy = False
    gMotionMsg = ""
    sMainAsm = sFolder & "\FlangeCoupling.SLDASM"
    sMotionAsm = sFolder & "\FlangeCoupling_Motion.SLDASM"

    ' Make sure the main assembly is saved (the motion file will use it)
    gStep = "Motion study: saving main assembly"
    On Error Resume Next
    If Not gAsmDoc Is Nothing Then gAsmDoc.SaveAs3 sMainAsm, 0, 0
    On Error GoTo 0

    gStep = "Motion study: creating motion assembly"
    Set oWrap = NewAssemblyDoc()
    If oWrap Is Nothing Then
        MsgBox "Could not create the motion assembly. Model is safe.", vbExclamation, "Flange Coupling"
        Exit Function
    End If

    gStep = "Motion study: inserting coupling assembly as one rigid body"
    On Error Resume Next
    Set oComp = oWrap.AddComponent5(sMainAsm, 0, "", False, "", 0, 0, 0)
    On Error GoTo 0
    If oComp Is Nothing Then
        MsgBox "Could not insert the coupling assembly into the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Flange Coupling"
        Exit Function
    End If

    ' Float it (first component is usually fixed), then place exactly at origin
    On Error Resume Next
    vComps = oWrap.GetComponents(True)
    On Error GoTo 0
    If IsArray(vComps) Then Call FloatFixedComponents(oWrap, vComps)
    Set oMU = swApp.GetMathUtility()
    aId(0) = 1: aId(1) = 0: aId(2) = 0: aId(3) = 0
    aId(4) = 1: aId(5) = 0: aId(6) = 0: aId(7) = 0
    aId(8) = 1: aId(9) = 0: aId(10) = 0: aId(11) = 0
    aId(12) = 1: aId(13) = 0: aId(14) = 0: aId(15) = 0
    vId = aId
    Set oIdXf = oMU.CreateTransform((vId))
    Call SetCompTransform(oComp, oIdXf)
    If Not CompAtPosition(oComp, 0, 0, 0) Then
        MsgBox "Coupling could not be placed at the origin in the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Flange Coupling"
        Exit Function
    End If
    Set oOrigXf = oComp.Transform2

    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    On Error Resume Next
    oWrap.ShowNamedView2 "*Isometric", 7
    oWrap.ViewZoomtofit2
    On Error GoTo 0

    gStep = "Motion study: opening Motion Study manager"
    On Error Resume Next
    Set oMgr = oWrap.Extension.GetMotionStudyManager()
    On Error GoTo 0
    If oMgr Is Nothing Then
        MsgBox "Motion Study is not available in this SolidWorks window." & vbCrLf & _
               "Model is safe. Create the motion study manually (Motion Study tab at bottom).", _
               vbExclamation, "Flange Coupling"
        Exit Function
    End If

    gStep = "Motion study: creating the study"
    On Error Resume Next
    Set oStudy = oMgr.GetMotionStudy("Motion Study 1")
    On Error GoTo 0
    If oStudy Is Nothing Then
        On Error Resume Next
        Set oStudy = oMgr.CreateMotionStudy()
        On Error GoTo 0
    End If
    If oStudy Is Nothing Then
        MsgBox "Could not create a Motion Study. Model is safe.", vbExclamation, "Flange Coupling"
        Exit Function
    End If
    On Error Resume Next
    oStudy.Activate
    oStudy.StudyType = 1              ' 1 = Animation
    oStudy.SetDuration durationSec
    On Error GoTo 0

    ' Rotation axis = Z axis (the shaft axis), through the origin
    gStep = "Motion study: preparing rotation"
    aPt(0) = 0: aPt(1) = 0: aPt(2) = 0
    aVec(0) = 0: aVec(1) = 0: aVec(2) = 1
    vPt = aPt
    vVec = aVec
    On Error Resume Next
    Set oPt = oMU.CreatePoint((vPt))
    Set oVec = oMU.CreateVector((vVec))
    On Error GoTo 0
    If oPt Is Nothing Or oVec Is Nothing Then
        MsgBox "Could not prepare the rotation axis - motion study skipped.", vbExclamation, "Flange Coupling"
        Exit Function
    End If

    totalTurns = rpm / 60# * durationSec
    nSteps = CLng(totalTurns * 24# + 0.5)        ' one key every 15 degrees of rotation
    If nSteps < 8 Then nSteps = 8
    If nSteps > 120 Then nSteps = 120

    ' Write keys for the ONE rigid component only
    gStep = "Motion study: writing rotation keys"
    For k = 0 To nSteps
        ang = 2# * PI_VAL * totalTurns * k / nSteps
        tNow = durationSec * k / nSteps
        On Error Resume Next
        oStudy.SetTime tNow
        On Error GoTo 0
        Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
        If oRot Is Nothing Then
            MsgBox "Could not create rotation transform - motion study stopped.", vbExclamation, "Flange Coupling"
            Exit Function
        End If
        Set oNew = oOrigXf.Multiply(oRot)
        Call SetCompTransform(oComp, oNew)
    Next k

    gStep = "Motion study: calculating and checking"
    On Error Resume Next
    oStudy.Calculate
    On Error GoTo 0

    ' VERIFY: jump to a quarter-turn key time and read the rotation back
    If totalTurns >= 0.25 Then
        kTest = CLng(nSteps / (4# * totalTurns) + 0.5)
    Else
        kTest = nSteps
    End If
    If kTest < 1 Then kTest = 1
    If kTest > nSteps Then kTest = nSteps
    ang = 2# * PI_VAL * totalTurns * kTest / nSteps
    Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
    Set oNew = oOrigXf.Multiply(oRot)
    On Error Resume Next
    oStudy.SetTime durationSec * kTest / nSteps
    On Error GoTo 0
    bKeysOK = CompRotationAt(oComp, oNew)

    If bKeysOK Then
        On Error Resume Next
        oStudy.SetTime 0
        On Error GoTo 0
        gStep = "Motion study: saving motion assembly"
        oWrap.SaveAs3 sMotionAsm, 0, 0
        gMotionMsg = "Motion Study READY in FlangeCoupling_Motion.SLDASM (open now): " & _
                     "whole coupling rotates as ONE body at " & rpm & " RPM for " & durationSec & " seconds."
        MakeMotionStudy = True
        Exit Function
    End If

    ' FALLBACK: keys did not record on this PC - use "Rotate Model" instead
    gStep = "Motion study: fallback (Rotate Model)"
    On Error Resume Next
    oStudy.SetTime 0
    On Error GoTo 0
    Call SetCompTransform(oComp, oOrigXf)
    On Error Resume Next
    Call oWrap.ForceRebuild3(False)
    Set oStudy2 = oMgr.CreateMotionStudy()
    On Error GoTo 0
    If oStudy2 Is Nothing Then
        MsgBox "Motion keys did not record and the fallback study could not be created." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Flange Coupling"
        Exit Function
    End If
    bRotOK = False
    On Error Resume Next
    oStudy2.Activate
    oStudy2.StudyType = 1
    Err.Clear
    Call oStudy2.CreateByRotateModel(True, 2, totalTurns, 0, durationSec, 0)
    bRotOK = (Err.Number = 0)
    oStudy2.SetDuration durationSec
    oStudy2.Calculate
    oStudy2.SetTime 0
    On Error GoTo 0
    If Not bRotOK Then
        MsgBox "Sorry, the motion study could not be created automatically." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Flange Coupling"
        Exit Function
    End If
    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    gMotionMsg = "Motion Study READY in FlangeCoupling_Motion.SLDASM (open now, use the LAST Motion Study tab): " & _
                 "Rotate Model at " & rpm & " RPM for " & durationSec & " seconds."
    MakeMotionStudy = True
End Function

'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    ValidateDims = False
    If dHub <= dShaft + 4 Then MsgBox "Hub diameter must be bigger than shaft diameter.", vbCritical: Exit Function
    If tFlange < 8 Then MsgBox "Flange thickness is too small (minimum 8 mm for the spigot/recess).", vbCritical: Exit Function
    If lHub <= tFlange + 5 Then MsgBox "Hub length (total) must be bigger than flange thickness + 5 mm.", vbCritical: Exit Function
    If dSpigot <= dShaft Or dSpigot >= dHub Then MsgBox "Spigot diameter must be between shaft dia and hub dia.", vbCritical: Exit Function
    If (dPCD / 2 - dBolt / 2) <= (dHub / 2 + 2) Then MsgBox "Bolt holes will touch the hub. Increase PCD or reduce bolt dia / hub dia.", vbCritical: Exit Function
    If (dPCD / 2 + dBolt / 2) >= (dFlange / 2 - 2) Then MsgBox "Bolt holes will go outside the flange. Increase flange dia or reduce PCD / bolt dia.", vbCritical: Exit Function
    If nBolts < 3 Or nBolts > 16 Then MsgBox "Number of bolts should be between 3 and 16.", vbCritical: Exit Function
    If dPCD * Sin(PI_VAL / nBolts) <= dBolt + 3 Then MsgBox "Bolt holes will overlap each other. Reduce number of bolts / bolt dia, or increase PCD.", vbCritical: Exit Function
    If (dPCD / 2 - dBolt) <= (dHub / 2 + 1) Then MsgBox "Bolt heads / nuts will touch the hub. Increase PCD or reduce bolt dia / hub dia.", vbCritical: Exit Function
    If (dPCD / 2 + dBolt) >= (dFlange / 2 - 1) Then MsgBox "Bolt heads / nuts will go outside the flange. Increase flange dia or reduce PCD / bolt dia.", vbCritical: Exit Function
    If wKey >= dShaft Then MsgBox "Key width is too large for this shaft.", vbCritical: Exit Function
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    Dim nDef As Long, boltDef As Double, keyWDef As Double
    Dim motionRPM As Double, motionSecs As Double
    Dim sMotionLine As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "FLANGE COUPLING MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Standard values are already filled - press OK to accept," & vbCrLf & _
           "or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old FlangeCoupling files that are open.", _
           vbInformation, "Flange Coupling"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\FlangeCoupling"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\FlangeCoupling"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = standard proportions from shaft dia d) ----
    gCancelled = False
    dShaft = AskNum("1) Shaft diameter  d  (mm)" & vbCrLf & "This is also the bore diameter of both flanges.", 40)
    If gCancelled Then Exit Sub
    dHub = AskNum("2) Hub outside diameter (mm)" & vbCrLf & "Standard = 2 x d", 2 * dShaft)
    If gCancelled Then Exit Sub
    lHub = AskNum("3) Hub length - TOTAL (mm)" & vbCrLf & "From mating face to end of hub. INCLUDES flange thickness." & vbCrLf & "Standard = 1.5 x d", 1.5 * dShaft)
    If gCancelled Then Exit Sub
    dFlange = AskNum("4) Flange outside diameter (mm)" & vbCrLf & "Standard = 4 x d", 4 * dShaft)
    If gCancelled Then Exit Sub
    tFlange = AskNum("5) Flange thickness (mm)" & vbCrLf & "Standard = 0.5 x d", 0.5 * dShaft)
    If gCancelled Then Exit Sub
    dPCD = AskNum("6) Bolt PCD - Pitch Circle Diameter (mm)" & vbCrLf & "Diameter of the circle passing through all bolt centres." & vbCrLf & "Standard = 3 x d", 3 * dShaft)
    If gCancelled Then Exit Sub
    dSpigot = AskNum("7) Spigot / Recess diameter (mm)" & vbCrLf & "Centring projection on one flange fitting into the other." & vbCrLf & "Standard = 1.5 x d", 1.5 * dShaft)
    If gCancelled Then Exit Sub

    ' V3 FIX: block If...ElseIf must be on separate lines in VBA (one-line ElseIf is NOT allowed)
    If dShaft <= 35 Then
        nDef = 4
    ElseIf dShaft <= 55 Then
        nDef = 6
    ElseIf dShaft <= 85 Then
        nDef = 8
    Else
        nDef = 10
    End If
    nBolts = CLng(AskNum("8) HOW MANY BOLTS do you want?" & vbCrLf & _
                         "Type 4 for FOUR, 6 for SIX, 8 for EIGHT (3 to 16 allowed)." & vbCrLf & _
                         "Same number of NUTS will be made automatically.", CDbl(nDef)))
    If gCancelled Then Exit Sub

    ' V3 FIX: same correction for bolt diameter default
    If dShaft <= 30 Then
        boltDef = 10
    ElseIf dShaft <= 50 Then
        boltDef = 12
    ElseIf dShaft <= 70 Then
        boltDef = 16
    Else
        boltDef = 20
    End If
    dBolt = AskNum("9) Bolt diameter (mm)  - e.g. 12 for M12" & vbCrLf & "Standard coarse THREAD will be added automatically. Bolt holes in flanges will be 1 mm bigger (clearance).", boltDef)
    If gCancelled Then Exit Sub

    lShaftExp = AskNum("10) Visible shaft length OUTSIDE the hub, each side (mm)", 2 * dShaft)
    If gCancelled Then Exit Sub

    keyWDef = StdKeyWidth(dShaft)
    wKey = AskNum("11) Key width (mm)" & vbCrLf & "Standard key width for this shaft is filled.", keyWDef)
    If gCancelled Then Exit Sub
    hKey = AskNum("12) Key height / thickness (mm)", Round(wKey * 0.7))
    If gCancelled Then Exit Sub

    If Not ValidateDims() Then Exit Sub

    ' ---- Calculated values ----
    spigotLen = 0.12 * dShaft
    If spigotLen < 3 Then spigotLen = 3
    If spigotLen > 8 Then spigotLen = 8
    If spigotLen >= tFlange * 0.5 Then spigotLen = Round(tFlange * 0.4)
    shaftPartLen = lHub - SHAFT_GAP + lShaftExp
    keyLen = lHub - 10
    If keyLen < 10 Then keyLen = lHub * 0.8
    headAF = 1.7 * dBolt: headH = 0.7 * dBolt
    nutAF = 1.7 * dBolt:  nutH = 0.9 * dBolt

    ' ---- Summary + confirmation ----
    sSummary = "Model will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Shaft dia (d)        = " & dShaft & vbCrLf & _
        "Hub dia / length     = " & dHub & " / " & lHub & vbCrLf & _
        "Flange dia / thk     = " & dFlange & " / " & tFlange & vbCrLf & _
        "Bolt PCD             = " & dPCD & vbCrLf & _
        "Spigot dia / length  = " & dSpigot & " / " & spigotLen & vbCrLf & _
        "Bolts                = " & nBolts & " x M" & dBolt & " x " & ThreadPitchFor(dBolt) & " (with thread)" & vbCrLf & _
        "Key (L x W x H)      = " & keyLen & " x " & wKey & " x " & hKey & vbCrLf & _
        "Shaft length (each)  = " & shaftPartLen & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Flange Coupling - Confirm") = vbCancel Then Exit Sub

    ' ---- Build all parts ----
    gStep = "Making Flange A (driving)"
    If Not MakeFlangeA(sFolder & "\Flange_A_Driving.SLDPRT") Then Exit Sub
    gStep = "Making Flange B (driven)"
    If Not MakeFlangeB(sFolder & "\Flange_B_Driven.SLDPRT") Then Exit Sub
    gStep = "Making Shaft"
    If Not MakeShaft(sFolder & "\Shaft.SLDPRT") Then Exit Sub
    gStep = "Making Key"
    If Not MakeKey(sFolder & "\Key.SLDPRT") Then Exit Sub
    gStep = "Making Bolt"
    If Not MakeBolt(sFolder & "\Bolt.SLDPRT") Then Exit Sub
    gStep = "Making Nut"
    If Not MakeNut(sFolder & "\Nut.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 6 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Flange Coupling"
        Exit Sub
    End If

    ' ---- V6: optional Motion Study ----
    gMotionOK = False
    gMotionMsg = ""
    If MsgBox("Model is ready." & vbCrLf & vbCrLf & _
              "Create the MOTION STUDY also? (rotating coupling)" & vbCrLf & vbCrLf & _
              "YES = create motion study now" & vbCrLf & _
              "NO  = finish with model only", _
              vbYesNo + vbQuestion, "Flange Coupling - Motion Study") = vbYes Then
        gCancelled = False
        motionRPM = AskNum("13) MOTION: Speed in RPM" & vbCrLf & "60 RPM = 1 full rotation per second", 60)
        If Not gCancelled Then
            motionSecs = AskNum("14) MOTION: Duration in SECONDS", 5)
            If Not gCancelled Then
                MsgBox "Motion Study is being created. Please WAIT..." & vbCrLf & _
                       "Do not click anywhere till the DONE message comes.", vbInformation, "Flange Coupling"
                gStep = "Creating motion study"
                gMotionOK = MakeMotionStudy(sFolder, motionRPM, motionSecs)
            End If
        End If
    End If

    If gMotionOK Then
        sMotionLine = gMotionMsg & vbCrLf & vbCrLf & _
            "TO PLAY: click the 'Motion Study' tab at the BOTTOM of the window," & vbCrLf & _
            "then click 'Play from Start' (play button at top-left of the timeline)." & vbCrLf & vbCrLf
    Else
        sMotionLine = ""
    End If

    MsgBox "DONE!  Flange Coupling model is ready." & vbCrLf & vbCrLf & _
           "Model assembly file:  FlangeCoupling.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           sMotionLine & _
           "Use mouse to rotate. Press Ctrl+7 for isometric view if needed." & vbCrLf & _
           "HOW TO MOVE IT: Drag any flange, shaft, key, or bolt with the mouse - the entire bolted coupling rotates 360 deg around the shaft axis!", _
           vbInformation, "Flange Coupling"
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Version 9)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Flange Coupling - Error"
End Sub
