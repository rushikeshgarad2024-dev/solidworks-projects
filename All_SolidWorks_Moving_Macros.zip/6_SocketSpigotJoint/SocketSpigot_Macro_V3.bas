'=====================================================================================
'  SOCKET AND SPIGOT JOINT MACRO  -  VERSION 2 (checked)
'  Socket & Spigot Cotter Joint - Full Assembly (exam model)
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'  V2: full code re-check - small-rod (20-24 mm) standard defaults now pass
'  validation, and the cotter is extruded half in each direction so its
'  thickness is always centred on the slot.
'  Standard steel proportions in terms of rod diameter d:
'    socket OD d1=1.75d, spigot dia d2=1.21d (taken 1.25d), spigot collar
'    d3=1.5d, socket collar d4=2.4d, a=c=0.75d, e=1.2d, cotter width
'    b=1.3d, cotter length l=4d, cotter thickness t=0.31d, t1=0.45d,
'    cotter taper 1 in 25.  (Default rod dia = 40 mm.)
'-------------------------------------------------------------------------------------
'  EXAM POINT: A socket and spigot cotter joint connects two co-axial rods
'  subjected to axial tensile/compressive load. The spigot end of one rod
'  fits into the socket end of the other rod, and a tapered COTTER is
'  driven through the aligned rectangular slots to lock the joint.
'  Compressive load is taken by the spigot collar against the socket end.
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old SocketSpigotJoint files if open.
'     2) Tools > Macro > New  -> save as  SocketSpigotJoint.swp
'     3) Select ALL old code (Ctrl+A), Delete, paste THIS FULL CODE.
'     4) Press F5. Answer the pop-ups (standard values pre-filled).
'     5) The macro creates automatically:
'            Socket_Rod.SLDPRT    (rod with hollow socket + socket collar)
'            Spigot_Rod.SLDPRT    (rod with spigot + spigot collar)
'            Cotter.SLDPRT        (tapered flat cotter)
'            SocketSpigotJoint.SLDASM (full assembly)
'        Saved in the first pop-up folder (default Documents\SocketSpigotJoint).
'
'  NOTES:
'    - Rod axis is Z. Cotter is vertical (Y), tapered 1 in 25 on one edge.
'    - Slots have small clearance (draw) so parts do not overlap in CAD.
'    - Parts are placed exactly by position (no mates). Do not drag parts.
'    - Cotter ends are kept flat (rounded ends omitted - normal student model).
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String
Private gSpigSlotPlaneName As String            ' name of current step - shown in error message (for easy fixing)

' User dimensions (mm)
Private rodD As Double             ' d  - diameter of both rods
Private sockOD As Double           ' d1 - outside diameter of socket
Private spigD As Double            ' d2 - spigot diameter (= socket bore, nominal)
Private spigCollarD As Double      ' d3 - outside diameter of spigot collar
Private sockCollarD As Double      ' d4 - outside diameter of socket collar
Private cotT As Double             ' t  - cotter thickness (X direction)
Private cotW As Double             ' b  - cotter mean width (along rod axis Z)
Private cotL As Double             ' l  - cotter length (vertical, Y direction)
Private rodLen As Double           ' plain rod length on each side

' Calculated dimensions (mm) - standard proportions
Private aDist As Double            ' a  - slot edge to spigot tip   = 0.75d
Private cDist As Double            ' c  - slot edge to socket mouth = 0.75d (socket collar thickness)
Private eDist As Double            ' e  - socket end-wall thickness = 1.2d
Private spigCollarT As Double      ' t1 - spigot collar thickness   = 0.45d
Private slotW As Double            ' cotter slot width along Z (cotter width + clearance for taper)
Private slotT As Double            ' cotter slot thickness along X (cotter thickness + 1)
Private spigLen As Double          ' spigot length, tip to collar face
Private slotCtrSocket As Double    ' slot centre Z in Socket_Rod local coords
Private slotCtrSpigot As Double    ' slot centre Z in Spigot_Rod local coords

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.5          ' clearance (mm) for recess & bolt holes (+1 on dia = 2x0.5)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Socket and Spigot Joint - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Socket and Spigot Joint"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Socket and Spigot Joint", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function



'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Socket and Spigot Joint"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

' Open a sketch on a named reference plane ("Top Plane" / "Right Plane").
Private Function OpenNamedSketch(ByVal oDoc As Object, ByVal sPlaneName As String) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2(sPlaneName, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select plane: " & sPlaneName & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Socket and Spigot Joint"
        OpenNamedSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True
    OpenNamedSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub


' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Socket and Spigot Joint"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Socket and Spigot Joint"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function


Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Socket and Spigot Joint"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

' Rectangular cotter slot through a rod (axis Z).
' Sketch on Top Plane: local X = global X, local Y = -global Z (SOLIDWORKS
' default), so the slot centre is drawn at local Y = -slotCenterZ.
' The cut goes through-all along Y (vertical - the cotter direction).
Private Function AddCotterSlot(ByVal oDoc As Object, ByVal slotCenterZ As Double, _
                               ByVal featName As String) As Boolean
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-slotT / 2), Mm(-(slotCenterZ + slotW / 2)), 0, _
                                                  Mm(slotT / 2), Mm(-(slotCenterZ - slotW / 2)), 0)
    AddCotterSlot = CutThroughAllFromOpenSketch(oDoc, featName)
End Function

'------------------------- PART 1: Socket rod -------------------------
' Local origin = outer end of the plain rod. Axis along +Z towards joint.
' Plain rod -> solid socket end (e) -> hollow socket body -> socket collar.
Private Function MakeSocketRod(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim bodyLen As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    bodyLen = 3 + aDist + slotW      ' 3 mm tip clearance + a + slot width
    ' Plain rod
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, rodD
    If Not BossFromOpenSketch(oDoc, rodLen, False, 0, "Rod") Then Exit Function
    ' Solid socket end wall (thickness e)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, sockOD
    If Not BossFromOpenSketch(oDoc, eDist, False, rodLen, "Socket_End") Then Exit Function
    ' Hollow socket body (annulus)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, sockOD
    DrawCircle oDoc, 0, 0, spigD + 1
    If Not BossFromOpenSketch(oDoc, bodyLen, False, rodLen + eDist, "Socket_Body") Then Exit Function
    ' Socket collar at the mouth (annulus, thickness c)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, sockCollarD
    DrawCircle oDoc, 0, 0, spigD + 1
    If Not BossFromOpenSketch(oDoc, cDist, False, rodLen + eDist + bodyLen, "Socket_Collar") Then Exit Function
    ' Cotter slot
    If Not AddCotterSlot(oDoc, slotCtrSocket, "Cotter_Slot_Socket") Then Exit Function
    MakeSocketRod = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 2: Spigot rod -------------------------
' Local origin = spigot tip. Axis along +Z away from the joint.
' Spigot -> spigot collar (t1) -> plain rod.
Private Function MakeSpigotRod(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' Spigot (inserted portion)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, spigD
    If Not BossFromOpenSketch(oDoc, spigLen, False, 0, "Spigot") Then Exit Function
    ' Spigot collar
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, spigCollarD
    If Not BossFromOpenSketch(oDoc, spigCollarT, False, spigLen, "Spigot_Collar") Then Exit Function
    ' Plain rod
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, rodD
    If Not BossFromOpenSketch(oDoc, rodLen, False, spigLen + spigCollarT, "Rod") Then Exit Function
    ' Cotter slot
    If Not AddCotterSlot(oDoc, slotCtrSpigot, "Cotter_Slot_Spigot") Then Exit Function
    ' Reference plane at slot centre (Z = +slotCtrSpigot) for axial lock mate
    Dim oRefP As Object, oFeat As Object
    gSpigSlotPlaneName = "Plane1"
    oDoc.ClearSelection2 True
    If oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        Set oRefP = oDoc.FeatureManager.InsertRefPlane(8, Mm(slotCtrSpigot), 0, 0, 0, 0)
        oDoc.ClearSelection2 True
        On Error Resume Next
        Set oFeat = oDoc.FeatureByPositionReverse(0)
        If Not oFeat Is Nothing Then
            gSpigSlotPlaneName = oFeat.Name
            oFeat.Name = "Plane_SpigSlot"
            gSpigSlotPlaneName = oFeat.Name
        End If
        On Error GoTo 0
    End If
    MakeSpigotRod = SaveAndClose(oDoc, sPath)
End Function

Private Sub DrawCotterProfile(ByVal oDoc As Object, ByVal xLeft As Double, _
                              ByVal bBot As Double, ByVal bTop As Double)
    Call oDoc.SketchManager.CreateLine(Mm(xLeft), Mm(-cotL / 2), 0, Mm(xLeft + bBot), Mm(-cotL / 2), 0)
    Call oDoc.SketchManager.CreateLine(Mm(xLeft + bBot), Mm(-cotL / 2), 0, Mm(xLeft + bTop), Mm(cotL / 2), 0)
    Call oDoc.SketchManager.CreateLine(Mm(xLeft + bTop), Mm(cotL / 2), 0, Mm(xLeft), Mm(cotL / 2), 0)
    Call oDoc.SketchManager.CreateLine(Mm(xLeft), Mm(cotL / 2), 0, Mm(xLeft), Mm(-cotL / 2), 0)
End Sub

'------------------------- PART 3: Cotter -------------------------
' Profile on Right Plane: horizontal = width b (rod-axis direction),
' vertical = length l. One edge straight, other edge tapered 1 in 25.
' Extruded by thickness t (half each way). Local origin = centre of cotter.
Private Function MakeCotter(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim delta As Double, bTop As Double, bBot As Double, xLeft As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    delta = cotL / 25                ' total taper over the length (1 in 25)
    bTop = cotW + delta / 2
    bBot = cotW - delta / 2
    xLeft = -cotW / 2                ' straight edge
    ' Extrude half the thickness in each direction: the cotter is then always
    ' centred on X=0, whichever way the Right Plane normal points.
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    DrawCotterProfile oDoc, xLeft, bBot, bTop
    If Not BossFromOpenSketch(oDoc, cotT / 2, False, 0, "Cotter_Half1") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    DrawCotterProfile oDoc, xLeft, bBot, bTop
    If Not BossFromOpenSketch(oDoc, cotT / 2, True, 0, "Cotter_Half2") Then Exit Function
    MakeCotter = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly -------------------------
' AddComponent5 inserts a PRE-LOADED part, so first load the part
' file into memory (silent). 1 = swDocPART, 1 = swOpenDocOptions_Silent.
Private Function LoadPartForAssembly(ByVal sPath As String) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading part for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, 1, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this part file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Socket and Spigot Joint"
        LoadPartForAssembly = False
        Exit Function
    End If
    LoadPartForAssembly = True
End Function


' V5: check the actual position of a component by reading its transform back.
' Transform ArrayData: elements 9, 10, 11 = translation X, Y, Z (metres).
Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

' Insert one component and put its ORIGIN exactly at (xMm,yMm,zMm), no rotation.
' V5 FIX: move the component the recorded-macro way -
'   1) copy the 16-number transform array into a VARIANT variable,
'   2) CreateTransform((variant))  [double brackets are intentional],
'   3) SetTransformAndSolve2(...) to actually move+solve the component,
'   4) read the position back and verify it really moved.
Private Function PlaceComponent(ByVal oAsm As Object, ByVal sPath As String, _
                                ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Socket and Spigot Joint"
        PlaceComponent = False
        Exit Function
    End If
    ' Identity rotation + translation to (xMm, yMm, zMm)
    aData(0) = 1: aData(1) = 0: aData(2) = 0: aData(3) = 0
    aData(4) = 1: aData(5) = 0: aData(6) = 0: aData(7) = 0
    aData(8) = 1: aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    ' If still not at the required position, try the direct Transform2 method also.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        On Error Resume Next
        oComp.Transform2 = oXf
        On Error GoTo 0
    End If
    ' Final verification - do not silently save a wrong assembly.
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        MsgBox "Component was inserted but could NOT be moved to its correct position:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Socket and Spigot Joint"
        PlaceComponent = False
        Exit Function
    End If
    PlaceComponent = True
End Function

Private Function SelectForSockMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                   ByVal sFeatName As String, ByVal sAltName As String, _
                                   ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then Set oFeat = oComp.FeatureByName(sAltName)
        If Not oFeat Is Nothing Then bOk = oFeat.Select2(bAppend, 1)
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectForSockMate = bOk
End Function

Private Sub AddSockPlaneMate(ByVal oAsm As Object, _
                             ByVal oComp1 As Object, ByVal sPlane1 As String, ByVal sAlt1 As String, _
                             ByVal oComp2 As Object, ByVal sPlane2 As String, ByVal sAlt2 As String, _
                             ByVal sMateName As String)
    Dim oMate As Object
    Dim lMateErr As Long
    oAsm.ClearSelection2 True
    If SelectForSockMate(oAsm, oComp1, sPlane1, sAlt1, "PLANE", False) Then
        If SelectForSockMate(oAsm, oComp2, sPlane2, sAlt2, "PLANE", True) Then
            On Error Resume Next
            Set oMate = oAsm.AddMate5(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
            If oMate Is Nothing Then Set oMate = oAsm.AddMate3(0, 0, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
            If Not oMate Is Nothing Then oMate.Name = sMateName
            On Error GoTo 0
        End If
    End If
    oAsm.ClearSelection2 True
End Sub

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oAsm As Object
    Dim oCompSock As Object, oCompSpig As Object, oCompCot As Object
    Dim vComps As Variant
    Dim pSocket As String, pSpigot As String, pCotter As String
    Dim sAsmTitle As String
    Dim lErr As Long
    pSocket = sFolder & "\Socket_Rod.SLDPRT"
    pSpigot = sFolder & "\Spigot_Rod.SLDPRT"
    pCotter = sFolder & "\Cotter.SLDPRT"

    gStep = "Creating new Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create new Assembly (check default Assembly template).", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle

    If Not LoadPartForAssembly(pSocket) Then Exit Function
    If Not LoadPartForAssembly(pSpigot) Then Exit Function
    If Not LoadPartForAssembly(pCotter) Then Exit Function
    gStep = "Activating assembly window"
    swApp.ActivateDoc2 sAsmTitle, False, lErr

    If Not PlaceComponent(oAsm, pSocket, 0, 0, -slotCtrSocket) Then Exit Function
    If Not PlaceComponent(oAsm, pSpigot, 0, 0, -slotCtrSpigot) Then Exit Function
    If Not PlaceComponent(oAsm, pCotter, 0, 0, 0) Then Exit Function

    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    If IsArray(vComps) Then
        If UBound(vComps) >= LBound(vComps) + 2 Then
            Set oCompSock = vComps(LBound(vComps))
            Set oCompSpig = vComps(LBound(vComps) + 1)
            Set oCompCot = vComps(LBound(vComps) + 2)
            oAsm.ClearSelection2 True: If oCompSock.Select4(False, Nothing, False) Then oAsm.FixComponent
            oAsm.ClearSelection2 True: If oCompSpig.Select4(False, Nothing, False) Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True: If oCompCot.Select4(False, Nothing, False) Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True
        End If
    End If

    If Not oCompSpig Is Nothing And Not oCompCot Is Nothing Then
        ' 1) Cotter guided vertically in the slot (slides up/down along Y when dragged!):
        Call AddSockPlaneMate(oAsm, oCompCot, "Right Plane", "", Nothing, "Right Plane", "", "Cotter_Slot_Side_Mate")
        Call AddSockPlaneMate(oAsm, oCompCot, "Front Plane", "", Nothing, "Front Plane", "", "Cotter_Slot_Axial_Mate")

        ' 2) Spigot_Rod guided coaxially inside Socket_Rod bore (along Z):
        Call AddSockPlaneMate(oAsm, oCompSpig, "Top Plane", "", Nothing, "Top Plane", "", "Spigot_Coaxial_Horiz_Mate")
        Call AddSockPlaneMate(oAsm, oCompSpig, "Right Plane", "", Nothing, "Right Plane", "", "Spigot_Coaxial_Vert_Mate")
        Call AddSockPlaneMate(oAsm, oCompSpig, gSpigSlotPlaneName, "Plane1", Nothing, "Front Plane", "", "Spigot_Locked_By_Cotter_(Suppress_To_Slide_Spigot)")
    End If
    oAsm.SetUserPreferenceToggle 4, False
    oAsm.SetUserPreferenceToggle 5, False
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\SocketSpigotJoint.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Socket_Rod.SLDPRT"
    swApp.CloseDoc "Spigot_Rod.SLDPRT"
    swApp.CloseDoc "Cotter.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    ValidateDims = False
    If rodD < 20 Then MsgBox "Rod diameter is too small (minimum 20 mm).", vbCritical: Exit Function
    If spigD <= rodD + 4 Then MsgBox "Spigot diameter must be more than rod diameter + 4 mm (spigot is an enlarged end).", vbCritical: Exit Function
    If sockOD < spigD + 10 Then MsgBox "Socket outside diameter is too small - socket wall will be too thin. Increase socket OD.", vbCritical: Exit Function
    If spigCollarD <= spigD + 4 Then MsgBox "Spigot collar diameter must be more than spigot diameter + 4 mm.", vbCritical: Exit Function
    If sockCollarD <= sockOD + 10 Then MsgBox "Socket collar diameter must be more than socket OD + 10 mm.", vbCritical: Exit Function
    If cotT < 4 Then MsgBox "Cotter thickness is too small (minimum 4 mm).", vbCritical: Exit Function
    If slotT >= spigD - 10 Then MsgBox "Cotter is too thick - the slot would leave less than 5 mm material on each side of the spigot.", vbCritical: Exit Function
    If cotW < 15 Then MsgBox "Cotter width is too small (minimum 15 mm).", vbCritical: Exit Function
    If cotL <= sockCollarD + 20 Then MsgBox "Cotter length must be more than socket collar diameter + 20 mm (it must project out both sides).", vbCritical: Exit Function
    If cotW - cotL / 50 < 10 Then MsgBox "Cotter bottom width becomes too small due to taper. Increase cotter width or reduce cotter length.", vbCritical: Exit Function
    If rodLen < rodD Then MsgBox "Plain rod length should be at least equal to the rod diameter.", vbCritical: Exit Function
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "SOCKET AND SPIGOT JOINT MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Standard textbook proportions are already filled - press OK" & vbCrLf & _
           "to accept, or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old SocketSpigotJoint files that are open.", _
           vbInformation, "Socket and Spigot Joint"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\SocketSpigotJoint"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\SocketSpigotJoint"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = standard proportions of rod diameter) ----
    gCancelled = False
    rodD = AskNum("1) Rod diameter  d  (mm)" & vbCrLf & "All other default values are calculated from this.", 40)
    If gCancelled Then Exit Sub
    sockOD = AskNum("2) Socket outside diameter  d1 = 1.75d  (mm)", Round(1.75 * rodD))
    If gCancelled Then Exit Sub
    spigD = AskNum("3) Spigot diameter  d2 = 1.25d  (mm)" & vbCrLf & "Socket bore is made 1 mm bigger for fitting clearance.", Round(1.25 * rodD))
    If gCancelled Then Exit Sub
    spigCollarD = AskNum("4) Spigot collar diameter  d3 = 1.5d  (mm)", Round(1.5 * rodD))
    If gCancelled Then Exit Sub
    sockCollarD = AskNum("5) Socket collar diameter  d4 = 2.4d  (mm)", Round(2.4 * rodD))
    If gCancelled Then Exit Sub
    cotT = AskNum("6) Cotter thickness  t = 0.31d  (mm)", Round(0.31 * rodD))
    If gCancelled Then Exit Sub
    cotW = AskNum("7) Cotter mean width  b = 1.3d  (mm)" & vbCrLf & "Width measured along the rod axis. Taper 1 in 25 is added automatically.", Round(1.3 * rodD))
    If gCancelled Then Exit Sub
    cotL = AskNum("8) Cotter length  l = 4d  (mm)" & vbCrLf & "Vertical length of the cotter.", Round(4 * rodD))
    If gCancelled Then Exit Sub
    rodLen = AskNum("9) Plain rod length on each side (mm)", Round(3 * rodD))
    If gCancelled Then Exit Sub

    ' ---- Calculated standard proportions (set BEFORE validation) ----
    aDist = 0.75 * rodD
    cDist = 0.75 * rodD
    eDist = 1.2 * rodD
    spigCollarT = 0.45 * rodD
    slotW = cotW + sockCollarD / 25 + 1
    slotT = cotT + 1
    spigLen = aDist + slotW + cDist
    slotCtrSpigot = aDist + slotW / 2
    slotCtrSocket = rodLen + eDist + 3 + aDist + slotW / 2

    If Not ValidateDims() Then Exit Sub

    ' ---- Summary + confirmation ----
    sSummary = "Model will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Rod diameter d          = " & rodD & vbCrLf & _
        "Socket OD d1            = " & sockOD & vbCrLf & _
        "Spigot dia d2           = " & spigD & "  (socket bore " & (spigD + 1) & ")" & vbCrLf & _
        "Spigot collar d3 x t1   = " & spigCollarD & " x " & spigCollarT & vbCrLf & _
        "Socket collar d4 x c    = " & sockCollarD & " x " & cDist & vbCrLf & _
        "Socket end wall e       = " & eDist & vbCrLf & _
        "Slot end distance a     = " & aDist & vbCrLf & _
        "Cotter b x t x l        = " & cotW & " x " & cotT & " x " & cotL & "  (taper 1:25)" & vbCrLf & _
        "Plain rod length (each) = " & rodLen & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Socket and Spigot Joint - Confirm") = vbCancel Then Exit Sub

    ' ---- Build all parts ----
    gStep = "Making Socket Rod"
    If Not MakeSocketRod(sFolder & "\Socket_Rod.SLDPRT") Then Exit Sub
    gStep = "Making Spigot Rod"
    If Not MakeSpigotRod(sFolder & "\Spigot_Rod.SLDPRT") Then Exit Sub
    gStep = "Making Cotter"
    If Not MakeCotter(sFolder & "\Cotter.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 3 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Socket and Spigot Joint"
        Exit Sub
    End If

    MsgBox "DONE!  Socket and Spigot Joint model is ready." & vbCrLf & vbCrLf & _
           "Assembly open now:  SocketSpigotJoint.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           "Parts: Socket Rod, Spigot Rod, Cotter." & vbCrLf & vbCrLf & _
           "EXAM POINT: it connects two co-axial rods under axial" & vbCrLf & _
           "tensile/compressive load. The tapered cotter locks the" & vbCrLf & _
           "spigot inside the socket; compression is taken by the collars." & vbCrLf & vbCrLf & _
           "Use mouse to rotate. Press Ctrl+7 for isometric view if needed." & vbCrLf & _
           "HOW TO MOVE IT: Drag the Cotter up/down with the mouse - it slides smoothly in and out of the slot! (Suppress 'Spigot_Locked_By_Cotter' in Mates to slide the Spigot Rod axially.)", _
           vbInformation, "Socket and Spigot Joint"
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Socket and Spigot Joint Version 2)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Socket and Spigot Joint - Error"
End Sub
