'=====================================================================================
'  UNIVERSAL COUPLING (HOOKE'S JOINT) MACRO  -  VERSION 2 (MOVING KINEMATIC MATES)
'  Standard Universal / Hooke's Coupling - Full Moving Assembly with Mates
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'-------------------------------------------------------------------------------------
'  WHAT IS NEW IN VERSION 2:
'    - Each side (Fork + Shaft + Key + Main Pin + Collar + Taper Pin) is grouped
'      into a rigid subassembly (Fork_Unit.SLDASM) so parts NEVER separate when
'      you drag them with the mouse.
'    - All 3 moving links in UniversalCoupling.SLDASM (Driving Fork_Unit,
'      floating Centre_Block, and Driven Fork_Unit) are unfixed and connected by
'      REAL SOLIDWORKS MATES (Revolute hinge mates on the shaft and perpendicular
'      centre-block pins + an alignment mate).
'    - Dragging EITHER shaft or fork with the mouse in SOLIDWORKS rotates the
'      centre block and the other shaft/fork together!
'    - To also tilt/bend the Driven Shaft at an angle around the pins, either
'      choose NO at the "Keep shafts aligned?" prompt or right-click the mate
'      "Keep_Shafts_Aligned_(Suppress_To_Bend)" in the Mates folder -> Suppress.
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old UniversalCoupling files if open.
'     2) Tools > Macro > New  -> save as  UniversalCoupling_V2.swp  (anywhere)
'     3) Select ALL old code (Ctrl+A), Delete, then paste THIS FULL CODE.
'     4) Press F5  (or click the green Run / Play button).
'     5) Accept default dimensions (or enter your own) in the pop-ups.
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String            ' name of current step - shown in error message
Private gAsmDoc As Object          ' finished assembly document (for motion study)
Private gMotionOK As Boolean       ' True when the motion study was created
Private gMotionMsg As String       ' short motion-study result text for final message
Private gKeepAligned As Boolean    ' True = add Parallel mate so dragging either side rotates both shafts
Private gMatesOK As Boolean        ' True when all kinematic mates were added

' Actual feature names of created reference planes/axes (stored at creation time)
Private gCB_PlaneVertName As String
Private gCB_AxisHorizName As String
Private gCB_AxisVertName As String
Private gFU_AxisPinName As String
Private gFU_AxisShaftName As String
Private gAssy_AxisZName As String

' User dimensions (mm)
Private shaftD As Double           ' Shaft diameter D
Private hubOD As Double            ' Fork hub outside diameter (1.8 D)
Private hubLen As Double           ' Fork hub length (1.1 D)
Private webT As Double             ' Fork back web thickness (0.6 D)
Private hubToPin As Double         ' Distance from hub back face to pin axis (2.6 D)
Private forkW As Double            ' Fork arm width & rounded ear OD (1.6 D)
Private forkGap As Double          ' Inside gap between fork arms & centre block length (2.2 D)
Private armT As Double             ' Thickness of each fork arm / cheek (0.5 D)
Private pinD As Double             ' Main pin diameter & centre block bore (0.6 D)
Private cbOD As Double             ' Centre block sleeve outside diameter (1.1 D)
Private pinOffset As Double        ' Offset between perpendicular pin axes in centre block (0.8 D)
Private collarOD As Double         ' Pin head & collar outside diameter (1.0 D)
Private collarT As Double          ' Pin head & collar thickness (0.25 D)
Private lockPinD As Double         ' Taper / split locking pin diameter (5 mm standard)
Private shaftLen As Double         ' Visible shaft length outside hub on each side (2.5 D)
Private wKey As Double             ' Key width
Private hKey As Double             ' Key height (thickness)

' Calculated dimensions (mm)
Private forkOuterH As Double       ' Total height across outside of fork arms (forkGap + 2*armT)
Private forkMidY As Double         ' Half height of fork (armT + forkGap/2)
Private pinTipExtra As Double      ' Pin protrusion beyond collar (0.15 D)
Private pinShaftLen As Double      ' Under-head length of main pin (3.6 D)
Private lockPinLen As Double       ' Length of collar locking pin (collarOD + 6)
Private shaftFitLen As Double      ' Shaft engagement length inside hub + web
Private shaftPartLen As Double     ' Total length of one Shaft part
Private keyLen As Double           ' Length of one Key part

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.2          ' radial running clearance (mm)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Universal Coupling - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Universal Coupling"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Universal Coupling", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function

Private Function StdKeyWidth(ByVal d As Double) As Double
    ' Approximate standard parallel key width for shaft diameter d
    Select Case d
        Case Is <= 22: StdKeyWidth = 6
        Case Is <= 30: StdKeyWidth = 8
        Case Is <= 38: StdKeyWidth = 10
        Case Is <= 44: StdKeyWidth = 12
        Case Is <= 50: StdKeyWidth = 14
        Case Is <= 58: StdKeyWidth = 16
        Case Is <= 65: StdKeyWidth = 18
        Case Else:     StdKeyWidth = 20
    End Select
End Function


'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Universal Coupling"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

' Open a sketch on a named reference plane ("Top Plane" / "Right Plane").
Private Function OpenNamedSketch(ByVal oDoc As Object, ByVal sPlaneName As String) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2(sPlaneName, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select plane: " & sPlaneName & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Universal Coupling"
        OpenNamedSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True
    OpenNamedSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub

' Rectangle on an OPEN Top Plane sketch, given by width (X) and a global
' Z range. Top Plane sketch local Y = -global Z (SOLIDWORKS default).
Private Sub DrawTopRectZ(ByVal oDoc As Object, ByVal widthX As Double, _
                         ByVal zStart As Double, ByVal zEnd As Double)
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-widthX / 2), Mm(-zEnd), 0, Mm(widthX / 2), Mm(-zStart), 0)
End Sub

' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Universal Coupling"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Universal Coupling"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function

Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Universal Coupling"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

' Create a Reference Axis at the intersection of two planes and return its actual feature name.
Private Function CreateAxisFromPlanes(ByVal oDoc As Object, ByVal sPlane1 As String, _
                                      ByVal sPlane2 As String, ByVal sDesiredName As String, _
                                      ByRef sOutName As String) As Boolean
    Dim bOk As Boolean
    Dim oFeat As Object
    gStep = "Creating reference axis: " & sDesiredName
    sOutName = sDesiredName
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2(sPlane1, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then Exit Function
    bOk = oDoc.Extension.SelectByID2(sPlane2, "PLANE", 0, 0, 0, True, 0, Nothing, 0)
    If Not bOk Then Exit Function
    bOk = oDoc.InsertAxis2(True)
    oDoc.ClearSelection2 True
    If Not bOk Then Exit Function
    On Error Resume Next
    Set oFeat = oDoc.FeatureByPositionReverse(0)
    If Not oFeat Is Nothing Then
        sOutName = oFeat.Name
        oFeat.Name = sDesiredName
        sOutName = oFeat.Name
    End If
    On Error GoTo 0
    CreateAxisFromPlanes = True
End Function

'------------------------- PART 1: Centre Block (Cross Piece) -------------------------
' Two perpendicular hollow sleeves of OD = cbOD, bore = pinD, length = forkGap,
' whose axes are offset by pinOffset along Z so the sleeves merge into one solid
' while the two perpendicular bores have a solid wall between them.
' Local origin (0,0,0) = centre of the HORIZONTAL sleeve (axis along X, at Z = 0).
' Vertical sleeve (axis along Y) is at local Z = +pinOffset (on Plane_Vert).
Private Function MakeCentreBlock(ByVal sPath As String) As Boolean
    Dim oDoc As Object, oRefPlane As Object, oPlaneFeat As Object, oSpecPlane As Object
    Dim vPlaneXf As Variant
    Dim halfL As Double, zVertMm As Double
    Dim bOk As Boolean
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    halfL = forkGap / 2
    zVertMm = pinOffset

    ' 1) Create offset Reference Plane at Z = +pinOffset for the Vertical Pin axis
    gStep = "Centre Block: creating offset plane Plane_Vert"
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then Exit Function
    Set oRefPlane = oDoc.FeatureManager.InsertRefPlane(8, Mm(pinOffset), 0, 0, 0, 0)
    oDoc.ClearSelection2 True
    gCB_PlaneVertName = "Plane1"
    On Error Resume Next
    Set oPlaneFeat = oDoc.FeatureByPositionReverse(0)
    If Not oPlaneFeat Is Nothing Then
        gCB_PlaneVertName = oPlaneFeat.Name
        oPlaneFeat.Name = "Plane_Vert"
        gCB_PlaneVertName = oPlaneFeat.Name
        Set oSpecPlane = oPlaneFeat.GetSpecificFeature2
        If Not oSpecPlane Is Nothing Then
            vPlaneXf = oSpecPlane.Transform.ArrayData
            If IsArray(vPlaneXf) Then
                If Abs(vPlaneXf(11)) > 0.0001 Then zVertMm = vPlaneXf(11) * 1000#
            End If
        End If
    End If
    On Error GoTo 0

    ' 2) Create Reference Axes for mating (Axis_Horiz along X at Z=0; Axis_Vert along Y at Z=zVertMm)
    If Not CreateAxisFromPlanes(oDoc, "Front Plane", "Top Plane", "Axis_Horiz", gCB_AxisHorizName) Then Exit Function
    If Not CreateAxisFromPlanes(oDoc, gCB_PlaneVertName, "Right Plane", "Axis_Vert", gCB_AxisVertName) Then Exit Function

    ' 3) Horizontal sleeve solid cylinder along X (centred at origin on Right Plane)
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, cbOD
    If Not BossFromOpenSketch(oDoc, halfL, False, 0, "CB_Horiz_Half1") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, cbOD
    If Not BossFromOpenSketch(oDoc, halfL, True, 0, "CB_Horiz_Half2") Then Exit Function

    ' 4) Vertical sleeve solid cylinder along Y at global Z = zVertMm (Top Plane local Y = -zVertMm)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -zVertMm, cbOD
    If Not BossFromOpenSketch(oDoc, halfL, False, 0, "CB_Vert_Half1") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -zVertMm, cbOD
    If Not BossFromOpenSketch(oDoc, halfL, True, 0, "CB_Vert_Half2") Then Exit Function

    ' 5) Cut horizontal pin bore (axis X, Through All both ways)
    If Not OpenNamedSketch(oDoc, "Right Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pinD + 2 * CLR
    If Not CutThroughAllFromOpenSketch(oDoc, "CB_Bore_Horiz") Then Exit Function

    ' 6) Cut vertical pin bore (axis Y, Through All both ways)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -zVertMm, pinD + 2 * CLR
    If Not CutThroughAllFromOpenSketch(oDoc, "CB_Bore_Vert") Then Exit Function

    MakeCentreBlock = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 2: Fork (Yoke) -------------------------
' Used twice (once in each Fork_Unit).
' Local Z = 0 is the outer back face of the hub; Local Y = 0 is the bottom
' outer face of the fork. Shaft/hub axis is at (X = 0, Y = forkMidY) along +Z.
' Pin hole axis is along Y at (X = 0, Z = hubToPin).
Private Function MakeFork(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim topArmY As Double, y1 As Double, y2 As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    topArmY = armT + forkGap
    ' 1) Cylindrical hub from Z = 0 to Z = hubLen
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, forkMidY, hubOD
    If Not BossFromOpenSketch(oDoc, hubLen, False, 0, "Fork_Hub") Then Exit Function
    ' 2) Fork back web from Z = hubLen to Z = hubLen + webT (full height forkOuterH, touches Hub)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopRectZ oDoc, forkW, hubLen, hubLen + webT
    If Not BossFromOpenSketch(oDoc, forkOuterH, False, 0, "Fork_Web") Then Exit Function
    ' 3) Bottom fork arm strap + rounded ear disc (Y = 0 to armT)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopRectZ oDoc, forkW, hubLen, hubToPin
    If Not BossFromOpenSketch(oDoc, armT, False, 0, "Fork_Arm_Bot") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -hubToPin, forkW
    If Not BossFromOpenSketch(oDoc, armT, False, 0, "Fork_Ear_Bot") Then Exit Function
    ' 4) Top fork arm strap + rounded ear disc (Y = armT + forkGap to forkOuterH)
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawTopRectZ oDoc, forkW, hubLen, hubToPin
    If Not BossFromOpenSketch(oDoc, armT, False, topArmY, "Fork_Arm_Top") Then Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -hubToPin, forkW
    If Not BossFromOpenSketch(oDoc, armT, False, topArmY, "Fork_Ear_Top") Then Exit Function
    ' 5) Pin hole through both fork ears along Y
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, -hubToPin, pinD + 2 * CLR
    If Not CutThroughAllFromOpenSketch(oDoc, "Fork_Pin_Hole") Then Exit Function
    ' 6) Shaft bore through hub and web (passes cleanly between the two fork arms)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, forkMidY, shaftD
    If Not CutThroughAllFromOpenSketch(oDoc, "Fork_Shaft_Bore") Then Exit Function
    ' 7) Keyway in hub and web bore
    If Not OpenFrontSketch(oDoc) Then Exit Function
    y1 = forkMidY + shaftD / 2 - 2
    y2 = forkMidY + shaftD / 2 + hKey / 2 + CLR
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(y1), 0, Mm(wKey / 2), Mm(y2), 0)
    If Not CutThroughAllFromOpenSketch(oDoc, "Fork_Keyway") Then Exit Function
    MakeFork = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 3: Main Pin -------------------------
' Local origin = tip end (collar side) at Y = 0. Axis along +Y.
' Head (collarOD x collarT) is at Y = pinShaftLen .. pinShaftLen + collarT.
Private Function MakePin(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim lockHoleY As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    lockHoleY = pinTipExtra + collarT / 2
    ' 1) Cylindrical pin shank along +Y
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, pinD
    If Not BossFromOpenSketch(oDoc, pinShaftLen, False, 0, "Pin_Shank") Then Exit Function
    ' 2) Pin head on top of shank
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, collarOD
    If Not BossFromOpenSketch(oDoc, collarT, False, pinShaftLen, "Pin_Head") Then Exit Function
    ' 3) Transverse taper-pin hole through the collar zone (axis Z)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, lockHoleY, lockPinD + CLR
    If Not CutThroughAllFromOpenSketch(oDoc, "Pin_Lock_Hole") Then Exit Function
    MakePin = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 4: Collar -------------------------
' Ring (collarOD, bore pinD) of thickness collarT along +Y,
' with transverse locking-pin hole along Z at mid-height.
Private Function MakeCollar(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenNamedSketch(oDoc, "Top Plane") Then Exit Function
    DrawCircle oDoc, 0, 0, collarOD
    DrawCircle oDoc, 0, 0, pinD + 2 * CLR
    If Not BossFromOpenSketch(oDoc, collarT, False, 0, "Collar_Body") Then Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, collarT / 2, lockPinD + CLR
    If Not CutThroughAllFromOpenSketch(oDoc, "Collar_Lock_Hole") Then Exit Function
    MakeCollar = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 5: Taper / Split Locking Pin -------------------------
' Centred on local origin (Z = -lockPinLen/2 to +lockPinLen/2).
Private Function MakeTaperPin(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim halfL As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    halfL = lockPinLen / 2
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, lockPinD
    If Not BossFromOpenSketch(oDoc, halfL, False, 0, "LockPin_Half1") Then Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, lockPinD
    If Not BossFromOpenSketch(oDoc, halfL, True, 0, "LockPin_Half2") Then Exit Function
    MakeTaperPin = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 6: Shaft -------------------------
' Runs from Z = 0 to Z = shaftPartLen along +Z.
Private Function MakeShaft(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, shaftD
    If Not BossFromOpenSketch(oDoc, shaftPartLen, False, 0, "Shaft") Then Exit Function
    MakeShaft = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 7: Key -------------------------
' Rectangular sunk key (wKey x hKey) extruded +Z by keyLen.
Private Function MakeKey(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(-hKey / 2), 0, Mm(wKey / 2), Mm(hKey / 2), 0)
    If Not BossFromOpenSketch(oDoc, keyLen, False, 0, "Key") Then Exit Function
    MakeKey = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly & Mate Helpers -------------------------
' Pre-load a part (docType = 1) or subassembly (docType = 2) into memory.
Private Function LoadDocForAssembly(ByVal sPath As String, ByVal docType As Long) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading document for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, docType, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Universal Coupling"
        LoadDocForAssembly = False
        Exit Function
    End If
    LoadDocForAssembly = True
End Function

' Check the actual position of a component by reading its transform back.
Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

' Insert one component and set its transform, returning the IComponent2 object in oOutComp.
' rotMode = 0 : Identity   [[ 1, 0, 0], [ 0, 1, 0], [0, 0,  1]]
' rotMode = 1 : Driven     [[ 0,-1, 0], [-1, 0, 0], [0, 0, -1]] (symmetric, det = +1, maps Y->-X, X->-Y, Z->-Z)
' rotMode = 2 : CentreBlk  [[-1, 0, 0], [ 0, 1, 0], [0, 0, -1]] (diagonal,  det = +1, 180 deg around Y)
Private Function PlaceComponentMode(ByVal oAsm As Object, ByVal sPath As String, _
                                    ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double, _
                                    ByVal rotMode As Long, ByRef oOutComp As Object) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean, bSel As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Universal Coupling"
        PlaceComponentMode = False
        Exit Function
    End If
    Set oOutComp = oComp
    If rotMode = 0 Then
        aData(0) = 1: aData(1) = 0: aData(2) = 0
        aData(3) = 0: aData(4) = 1: aData(5) = 0
        aData(6) = 0: aData(7) = 0: aData(8) = 1
    Else
        If rotMode = 1 Then
            aData(0) = 0: aData(1) = -1: aData(2) = 0
            aData(3) = -1: aData(4) = 0: aData(5) = 0
            aData(6) = 0: aData(7) = 0: aData(8) = -1
        Else
            aData(0) = -1: aData(1) = 0: aData(2) = 0
            aData(3) = 0: aData(4) = 1: aData(5) = 0
            aData(6) = 0: aData(7) = 0: aData(8) = -1
        End If
    End If
    aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Or Not CompRotationAt(oComp, oXf) Then
        On Error Resume Next
        oAsm.ClearSelection2 True
        bSel = oComp.Select4(False, Nothing, False)
        If bSel Then oAsm.UnfixComponent
        oAsm.ClearSelection2 True
        oComp.Transform2 = oXf
        bOk = oComp.SetTransformAndSolve2(oXf)
        On Error GoTo 0
    End If
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Or Not CompRotationAt(oComp, oXf) Then
        MsgBox "Component was inserted but could NOT be placed at its required transform:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Universal Coupling"
        PlaceComponentMode = False
        Exit Function
    End If
    PlaceComponentMode = True
End Function

' Fix all top-level components in an assembly (used inside Fork_Unit.SLDASM so the 6 parts
' of each fork unit stay permanently locked together as one rigid body when dragged).
Private Sub FixAllComponents(ByVal oAsm As Object)
    Dim vComps As Variant
    Dim j As Long
    Dim oComp As Object
    Dim bSel As Boolean
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If Not IsArray(vComps) Then Exit Sub
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        If Not oComp Is Nothing Then
            On Error Resume Next
            oAsm.ClearSelection2 True
            bSel = oComp.Select4(False, Nothing, False)
            If bSel Then oAsm.FixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

' Build Fork_Unit.SLDASM (contains 1 Fork, 1 Pin, 1 Collar, 1 Taper_Pin, 1 Shaft, 1 Key).
' Origin (0,0,0) of Fork_Unit.SLDASM is the Pin Hole Centre on the Shaft Axis:
'   - Axis_Pin   = Y axis (intersection of Front Plane and Right Plane)
'   - Axis_Shaft = Z axis (intersection of Top Plane and Right Plane)
'   - Hub & Shaft extend along -Z.
Private Function MakeForkUnit(ByVal sFolder As String, ByVal sUnitPath As String) As Boolean
    Dim oSub As Object, oDummy As Object
    Dim pFork As String, pPin As String, pCollar As String
    Dim pTaper As String, pShaft As String, pKey As String
    Dim sSubTitle As String
    Dim lErr As Long
    Dim yPinTip As Double, yCollarBot As Double, yLockCtr As Double

    pFork = sFolder & "\Fork.SLDPRT"
    pPin = sFolder & "\Pin.SLDPRT"
    pCollar = sFolder & "\Collar.SLDPRT"
    pTaper = sFolder & "\Taper_Pin.SLDPRT"
    pShaft = sFolder & "\Shaft.SLDPRT"
    pKey = sFolder & "\Key.SLDPRT"

    gStep = "Creating Fork_Unit subassembly"
    Set oSub = NewAssemblyDoc()
    If oSub Is Nothing Then MsgBox "Could not create Fork_Unit subassembly.", vbCritical: Exit Function
    sSubTitle = oSub.GetTitle

    ' Create Reference Axes for mating in the parent assembly
    If Not CreateAxisFromPlanes(oSub, "Front Plane", "Right Plane", "Axis_Pin", gFU_AxisPinName) Then Exit Function
    If Not CreateAxisFromPlanes(oSub, "Top Plane", "Right Plane", "Axis_Shaft", gFU_AxisShaftName) Then Exit Function

    ' Pre-load the 6 part files
    If Not LoadDocForAssembly(pFork, 1) Then Exit Function
    If Not LoadDocForAssembly(pPin, 1) Then Exit Function
    If Not LoadDocForAssembly(pCollar, 1) Then Exit Function
    If Not LoadDocForAssembly(pTaper, 1) Then Exit Function
    If Not LoadDocForAssembly(pShaft, 1) Then Exit Function
    If Not LoadDocForAssembly(pKey, 1) Then Exit Function
    swApp.ActivateDoc2 sSubTitle, False, lErr

    yPinTip = -(forkMidY + collarT + pinTipExtra)
    yCollarBot = -(forkMidY + collarT)
    yLockCtr = -(forkMidY + collarT / 2)

    ' Place all 6 parts with Identity rotation so Pin Hole Centre = (0,0,0) of Fork_Unit
    If Not PlaceComponentMode(oSub, pFork, 0, -forkMidY, -hubToPin, 0, oDummy) Then Exit Function
    If Not PlaceComponentMode(oSub, pPin, 0, yPinTip, 0, 0, oDummy) Then Exit Function
    If Not PlaceComponentMode(oSub, pCollar, 0, yCollarBot, 0, 0, oDummy) Then Exit Function
    If Not PlaceComponentMode(oSub, pTaper, 0, yLockCtr, 0, 0, oDummy) Then Exit Function
    If Not PlaceComponentMode(oSub, pShaft, 0, 0, -(hubToPin + shaftLen), 0, oDummy) Then Exit Function
    If Not PlaceComponentMode(oSub, pKey, 0, shaftD / 2, -hubToPin, 0, oDummy) Then Exit Function

    ' Fix all 6 parts inside Fork_Unit so they never separate when dragged
    Call FixAllComponents(oSub)
    Call oSub.ForceRebuild3(False)
    oSub.SaveAs3 sUnitPath, 0, 0
    If Len(Dir(sUnitPath)) = 0 Then
        MsgBox "Could not save Fork_Unit subassembly:" & vbCrLf & sUnitPath, vbCritical, "Universal Coupling"
        MakeForkUnit = False
        Exit Function
    End If
    MakeForkUnit = True
End Function

' Select a reference plane or reference axis on a component (or on the top-level assembly
' when oComp Is Nothing) with Mark = 1 for AddMate5 / AddMate3.
Private Function SelectFeatForMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                   ByVal sFeatName As String, ByVal sAltName As String, _
                                   ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then
            Set oFeat = oComp.FeatureByName(sAltName)
        End If
        If Not oFeat Is Nothing Then
            bOk = oFeat.Select2(bAppend, 1)
        End If
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectFeatForMate = bOk
End Function

' Add one mate (mateType: 0 = Coincident, 3 = Parallel) between two entities.
' Verifies that none of the 3 components jumped away from their home transforms.
Private Function AddKinematicMate(ByVal oAsm As Object, _
                                  ByVal oComp1 As Object, ByVal sFeat1 As String, ByVal sAlt1 As String, ByVal sType1 As String, _
                                  ByVal oComp2 As Object, ByVal sFeat2 As String, ByVal sAlt2 As String, ByVal sType2 As String, _
                                  ByVal mateType As Long, ByVal prefAlign As Long, _
                                  ByVal sMateName As String, _
                                  ByVal oC1 As Object, ByVal oXf1 As Object, _
                                  ByVal oC2 As Object, ByVal oXf2 As Object, _
                                  ByVal oC3 As Object, ByVal oXf3 As Object) As Boolean
    Dim oMate As Object
    Dim lMateErr As Long
    Dim aligns(0 To 2) As Long
    Dim idx As Long
    Dim bPoseOK As Boolean

    gStep = "Adding mate: " & sMateName
    aligns(0) = prefAlign
    If prefAlign = 0 Then
        aligns(1) = 2: aligns(2) = 1
    Else
        If prefAlign = 1 Then
            aligns(1) = 2: aligns(2) = 0
        Else
            aligns(1) = 0: aligns(2) = 1
        End If
    End If

    For idx = 0 To 2
        oAsm.ClearSelection2 True
        If SelectFeatForMate(oAsm, oComp1, sFeat1, sAlt1, sType1, False) Then
            If SelectFeatForMate(oAsm, oComp2, sFeat2, sAlt2, sType2, True) Then
                Set oMate = Nothing
                lMateErr = 0
                On Error Resume Next
                Set oMate = oAsm.AddMate5(mateType, aligns(idx), False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
                If oMate Is Nothing Then
                    Set oMate = oAsm.AddMate3(mateType, aligns(idx), False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
                End If
                On Error GoTo 0
                oAsm.ClearSelection2 True
                If Not oMate Is Nothing Then
                    Call oAsm.ForceRebuild3(False)
                    bPoseOK = CompAtTransform(oC1, oXf1) And CompRotationAt(oC1, oXf1) And _
                              CompAtTransform(oC2, oXf2) And CompRotationAt(oC2, oXf2) And _
                              CompAtTransform(oC3, oXf3) And CompRotationAt(oC3, oXf3)
                    If bPoseOK Then
                        On Error Resume Next
                        oMate.Name = sMateName
                        On Error GoTo 0
                        AddKinematicMate = True
                        Exit Function
                    Else
                        ' Wrong alignment flipped a component - delete mate and restore pose
                        On Error Resume Next
                        oAsm.ClearSelection2 True
                        Call oMate.Select2(False, 0)
                        oAsm.EditDelete
                        oAsm.ClearSelection2 True
                        Call SetCompTransform(oC1, oXf1)
                        Call SetCompTransform(oC2, oXf2)
                        Call SetCompTransform(oC3, oXf3)
                        Call oAsm.ForceRebuild3(False)
                        On Error GoTo 0
                    End If
                End If
            End If
        End If
    Next idx

    oAsm.ClearSelection2 True
    AddKinematicMate = False
End Function

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oAsm As Object
    Dim oCompF1 As Object, oCompCB As Object, oCompF2 As Object
    Dim oXfF1 As Object, oXfCB As Object, oXfF2 As Object
    Dim vComps As Variant
    Dim pCB As String, pForkUnit As String
    Dim sAsmTitle As String
    Dim lErr As Long
    Dim bM1 As Boolean, bM2 As Boolean, bM3 As Boolean
    Dim bM4 As Boolean, bM5 As Boolean, bM6 As Boolean, bM7 As Boolean

    pCB = sFolder & "\Centre_Block.SLDPRT"
    pForkUnit = sFolder & "\Fork_Unit.SLDASM"

    ' First build the Fork_Unit subassembly (1 Fork + 1 Pin + 1 Collar + 1 Taper_Pin + 1 Shaft + 1 Key)
    If Not MakeForkUnit(sFolder, pForkUnit) Then Exit Function

    gStep = "Creating new Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create new Assembly (check default Assembly template).", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle
    Set gAsmDoc = oAsm

    ' Create the Assembly Z axis (shaft rotation axis)
    If Not CreateAxisFromPlanes(oAsm, "Top Plane", "Right Plane", "Axis_Assy_Z", gAssy_AxisZName) Then Exit Function

    ' Pre-load Centre_Block.SLDPRT (type 1 = Part) and Fork_Unit.SLDASM (type 2 = Assembly)
    If Not LoadDocForAssembly(pCB, 1) Then Exit Function
    If Not LoadDocForAssembly(pForkUnit, 2) Then Exit Function
    gStep = "Activating assembly window"
    swApp.ActivateDoc2 sAsmTitle, False, lErr

    ' 1) Driving Fork_Unit-1 at (0,0,0) with Identity rotation (rotMode = 0):
    '    Pin along Y at Z = 0, Hub & Shaft extending in -Z.
    If Not PlaceComponentMode(oAsm, pForkUnit, 0, 0, 0, 0, oCompF1) Then Exit Function

    ' 2) Centre_Block-1 at (0,0,pinOffset) with 180-deg Y rotation (rotMode = 2):
    '    Vertical sleeve (Axis_Vert) at Z = 0 along Y; Horizontal sleeve (Axis_Horiz) at Z = +pinOffset along X.
    If Not PlaceComponentMode(oAsm, pCB, 0, 0, pinOffset, 2, oCompCB) Then Exit Function

    ' 3) Driven Fork_Unit-2 at (0,0,pinOffset) with Driven rotation (rotMode = 1):
    '    Pin along X at Z = +pinOffset, Hub & Shaft extending in +Z.
    If Not PlaceComponentMode(oAsm, pForkUnit, 0, 0, pinOffset, 1, oCompF2) Then Exit Function

    ' Unfix all 3 components so the entire coupling can rotate and pivot
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If IsArray(vComps) Then Call FloatFixedComponents(oAsm, vComps)

    ' Save exact home transforms for verification after each mate
    Set oXfF1 = oCompF1.Transform2
    Set oXfCB = oCompCB.Transform2
    Set oXfF2 = oCompF2.Transform2

    ' Add the 6 Revolute-Joint Mates:
    ' Joint 1 (Driving Shaft Bearing on Assembly Z axis):
    bM1 = AddKinematicMate(oAsm, oCompF1, gFU_AxisShaftName, "Axis2", "AXIS", _
                           Nothing, gAssy_AxisZName, "Axis1", "AXIS", _
                           0, 2, "Driving_Shaft_Axis_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)
    bM2 = AddKinematicMate(oAsm, oCompF1, "Front Plane", "", "PLANE", _
                           Nothing, "Front Plane", "", "PLANE", _
                           0, 0, "Driving_Axial_Lock_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)

    ' Joint 2 (Vertical Pin Hinge between Centre_Block and Driving Fork_Unit-1):
    bM3 = AddKinematicMate(oAsm, oCompCB, gCB_AxisVertName, "Axis2", "AXIS", _
                           oCompF1, gFU_AxisPinName, "Axis1", "AXIS", _
                           0, 2, "Vertical_Pin_Axis_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)
    bM4 = AddKinematicMate(oAsm, oCompCB, "Top Plane", "", "PLANE", _
                           oCompF1, "Top Plane", "", "PLANE", _
                           0, 0, "Vertical_Pin_Center_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)

    ' Joint 3 (Horizontal Pin Hinge between Driven Fork_Unit-2 and Centre_Block):
    bM5 = AddKinematicMate(oAsm, oCompF2, gFU_AxisPinName, "Axis1", "AXIS", _
                           oCompCB, gCB_AxisHorizName, "Axis1", "AXIS", _
                           0, 2, "Horizontal_Pin_Axis_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)
    bM6 = AddKinematicMate(oAsm, oCompF2, "Top Plane", "", "PLANE", _
                           oCompCB, "Right Plane", "", "PLANE", _
                           0, 0, "Horizontal_Pin_Center_Mate", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)

    ' Optional Mate 7: Keep Driven Shaft axis aligned so dragging EITHER side rotates both shafts
    bM7 = True
    If gKeepAligned Then
        bM7 = AddKinematicMate(oAsm, oCompF2, "Front Plane", "", "PLANE", _
                               Nothing, "Front Plane", "", "PLANE", _
                               3, 1, "Keep_Shafts_Aligned_(Suppress_To_Bend)", oCompF1, oXfF1, oCompCB, oXfCB, oCompF2, oXfF2)
    End If
    gMatesOK = (bM1 And bM2 And bM3 And bM4 And bM5 And bM6)

    ' Hide reference axes/planes in the graphics area for a clean look
    On Error Resume Next
    oAsm.SetUserPreferenceToggle 4, False    ' swDisplayPlanes = 4
    oAsm.SetUserPreferenceToggle 5, False    ' swDisplayAxes = 5
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\UniversalCoupling.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Fork_Unit.SLDASM"
    swApp.CloseDoc "Centre_Block.SLDPRT"
    swApp.CloseDoc "Fork.SLDPRT"
    swApp.CloseDoc "Pin.SLDPRT"
    swApp.CloseDoc "Collar.SLDPRT"
    swApp.CloseDoc "Taper_Pin.SLDPRT"
    swApp.CloseDoc "Shaft.SLDPRT"
    swApp.CloseDoc "Key.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'=====================================================================================
'  MOTION STUDY (one rigid body method)
'  Type created = Animation (works in every SolidWorks, no Motion add-in needed).
'  Method: the finished coupling assembly is inserted as ONE rigid component
'  into a new file UniversalCoupling_Motion.SLDASM, and only that one component
'  is rotated about the Z (shaft) axis using animation keys. Because it is a
'  single rigid body, all parts stay perfectly together during rotation.
'  The result is VERIFIED by jumping to a quarter-turn time and reading the
'  rotation back. If keys did not record, a "Rotate Model" study is made.
'=====================================================================================

' Move one component to the given transform (same two methods as PlaceComponent).
Private Sub SetCompTransform(ByVal oComp As Object, ByVal oXf As Object)
    Dim bOk As Boolean
    bOk = False
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    If Err.Number <> 0 Or Not bOk Then
        Err.Clear
        oComp.Transform2 = oXf
    End If
    On Error GoTo 0
End Sub

' True if the component origin is at the translation stored inside oXf.
Private Function CompAtTransform(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vE As Variant
    On Error Resume Next
    vE = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vE) Then Exit Function
    CompAtTransform = CompAtPosition(oComp, vE(9) * 1000#, vE(10) * 1000#, vE(11) * 1000#)
End Function

' Fixed components cannot move in a motion study - float them.
Private Sub FloatFixedComponents(ByVal oAsm As Object, ByVal vComps As Variant)
    Dim j As Long
    Dim oComp As Object
    Dim bSel As Boolean, bFixed As Boolean
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        bFixed = False
        On Error Resume Next
        bFixed = oComp.IsFixed
        On Error GoTo 0
        If bFixed Then
            bSel = False
            On Error Resume Next
            oAsm.ClearSelection2 True
            bSel = oComp.Select4(False, Nothing, False)
            If bSel Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

' True if the component rotation (first 9 transform values) matches oXf.
Private Function CompRotationAt(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vNow As Variant, vExp As Variant
    Dim i As Long
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    vExp = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Not IsArray(vExp) Then Exit Function
    For i = 0 To 8
        If Abs(vNow(i) - vExp(i)) > 0.02 Then Exit Function
    Next i
    CompRotationAt = True
End Function

' V7: make UniversalCoupling_Motion.SLDASM with the finished coupling assembly
' inside it as ONE rigid component, then rotate that one component.
Private Function MakeMotionStudy(ByVal sFolder As String, _
                                 ByVal rpm As Double, ByVal durationSec As Double) As Boolean
    Dim oWrap As Object, oComp As Object
    Dim oMgr As Object, oStudy As Object, oStudy2 As Object
    Dim oMU As Object, oPt As Object, oVec As Object
    Dim oRot As Object, oNew As Object, oOrigXf As Object, oIdXf As Object
    Dim vComps As Variant
    Dim aId(0 To 15) As Double
    Dim vId As Variant
    Dim aPt(0 To 2) As Double, aVec(0 To 2) As Double
    Dim vPt As Variant, vVec As Variant
    Dim sMainAsm As String, sMotionAsm As String
    Dim k As Long, nSteps As Long, kTest As Long
    Dim totalTurns As Double, ang As Double, tNow As Double
    Dim bKeysOK As Boolean, bRotOK As Boolean
    MakeMotionStudy = False
    gMotionMsg = ""
    sMainAsm = sFolder & "\UniversalCoupling.SLDASM"
    sMotionAsm = sFolder & "\UniversalCoupling_Motion.SLDASM"

    ' Make sure the main assembly is saved (the motion file will use it)
    gStep = "Motion study: saving main assembly"
    On Error Resume Next
    If Not gAsmDoc Is Nothing Then gAsmDoc.SaveAs3 sMainAsm, 0, 0
    On Error GoTo 0

    gStep = "Motion study: creating motion assembly"
    Set oWrap = NewAssemblyDoc()
    If oWrap Is Nothing Then
        MsgBox "Could not create the motion assembly. Model is safe.", vbExclamation, "Universal Coupling"
        Exit Function
    End If

    gStep = "Motion study: inserting coupling assembly as one rigid body"
    On Error Resume Next
    Set oComp = oWrap.AddComponent5(sMainAsm, 0, "", False, "", 0, 0, 0)
    On Error GoTo 0
    If oComp Is Nothing Then
        MsgBox "Could not insert the coupling assembly into the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Universal Coupling"
        Exit Function
    End If

    ' Float it (first component is usually fixed), then place exactly at origin
    On Error Resume Next
    vComps = oWrap.GetComponents(True)
    On Error GoTo 0
    If IsArray(vComps) Then Call FloatFixedComponents(oWrap, vComps)
    Set oMU = swApp.GetMathUtility()
    aId(0) = 1: aId(1) = 0: aId(2) = 0: aId(3) = 0
    aId(4) = 1: aId(5) = 0: aId(6) = 0: aId(7) = 0
    aId(8) = 1: aId(9) = 0: aId(10) = 0: aId(11) = 0
    aId(12) = 1: aId(13) = 0: aId(14) = 0: aId(15) = 0
    vId = aId
    Set oIdXf = oMU.CreateTransform((vId))
    Call SetCompTransform(oComp, oIdXf)
    If Not CompAtPosition(oComp, 0, 0, 0) Then
        MsgBox "Coupling could not be placed at the origin in the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Universal Coupling"
        Exit Function
    End If
    Set oOrigXf = oComp.Transform2

    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    On Error Resume Next
    oWrap.ShowNamedView2 "*Isometric", 7
    oWrap.ViewZoomtofit2
    On Error GoTo 0

    gStep = "Motion study: opening Motion Study manager"
    On Error Resume Next
    Set oMgr = oWrap.Extension.GetMotionStudyManager()
    On Error GoTo 0
    If oMgr Is Nothing Then
        MsgBox "Motion Study is not available in this SolidWorks window." & vbCrLf & _
               "Model is safe. Create the motion study manually (Motion Study tab at bottom).", _
               vbExclamation, "Universal Coupling"
        Exit Function
    End If

    gStep = "Motion study: creating the study"
    On Error Resume Next
    Set oStudy = oMgr.GetMotionStudy("Motion Study 1")
    On Error GoTo 0
    If oStudy Is Nothing Then
        On Error Resume Next
        Set oStudy = oMgr.CreateMotionStudy()
        On Error GoTo 0
    End If
    If oStudy Is Nothing Then
        MsgBox "Could not create a Motion Study. Model is safe.", vbExclamation, "Universal Coupling"
        Exit Function
    End If
    On Error Resume Next
    oStudy.Activate
    oStudy.StudyType = 1              ' 1 = Animation
    oStudy.SetDuration durationSec
    On Error GoTo 0

    ' Rotation axis = Z axis (the shaft axis), through the origin
    gStep = "Motion study: preparing rotation"
    aPt(0) = 0: aPt(1) = 0: aPt(2) = 0
    aVec(0) = 0: aVec(1) = 0: aVec(2) = 1
    vPt = aPt
    vVec = aVec
    On Error Resume Next
    Set oPt = oMU.CreatePoint((vPt))
    Set oVec = oMU.CreateVector((vVec))
    On Error GoTo 0
    If oPt Is Nothing Or oVec Is Nothing Then
        MsgBox "Could not prepare the rotation axis - motion study skipped.", vbExclamation, "Universal Coupling"
        Exit Function
    End If

    totalTurns = rpm / 60# * durationSec
    nSteps = CLng(totalTurns * 24# + 0.5)        ' one key every 15 degrees of rotation
    If nSteps < 8 Then nSteps = 8
    If nSteps > 120 Then nSteps = 120

    ' Write keys for the ONE rigid component only
    gStep = "Motion study: writing rotation keys"
    For k = 0 To nSteps
        ang = 2# * PI_VAL * totalTurns * k / nSteps
        tNow = durationSec * k / nSteps
        On Error Resume Next
        oStudy.SetTime tNow
        On Error GoTo 0
        Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
        If oRot Is Nothing Then
            MsgBox "Could not create rotation transform - motion study stopped.", vbExclamation, "Universal Coupling"
            Exit Function
        End If
        Set oNew = oOrigXf.Multiply(oRot)
        Call SetCompTransform(oComp, oNew)
    Next k

    gStep = "Motion study: calculating and checking"
    On Error Resume Next
    oStudy.Calculate
    On Error GoTo 0

    ' VERIFY: jump to a quarter-turn key time and read the rotation back
    If totalTurns >= 0.25 Then
        kTest = CLng(nSteps / (4# * totalTurns) + 0.5)
    Else
        kTest = nSteps
    End If
    If kTest < 1 Then kTest = 1
    If kTest > nSteps Then kTest = nSteps
    ang = 2# * PI_VAL * totalTurns * kTest / nSteps
    Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
    Set oNew = oOrigXf.Multiply(oRot)
    On Error Resume Next
    oStudy.SetTime durationSec * kTest / nSteps
    On Error GoTo 0
    bKeysOK = CompRotationAt(oComp, oNew)

    If bKeysOK Then
        On Error Resume Next
        oStudy.SetTime 0
        On Error GoTo 0
        gStep = "Motion study: saving motion assembly"
        oWrap.SaveAs3 sMotionAsm, 0, 0
        gMotionMsg = "Motion Study READY in UniversalCoupling_Motion.SLDASM (open now): " & _
                     "whole coupling rotates as ONE body at " & rpm & " RPM for " & durationSec & " seconds."
        MakeMotionStudy = True
        Exit Function
    End If

    ' FALLBACK: keys did not record on this PC - use "Rotate Model" instead
    gStep = "Motion study: fallback (Rotate Model)"
    On Error Resume Next
    oStudy.SetTime 0
    On Error GoTo 0
    Call SetCompTransform(oComp, oOrigXf)
    On Error Resume Next
    Call oWrap.ForceRebuild3(False)
    Set oStudy2 = oMgr.CreateMotionStudy()
    On Error GoTo 0
    If oStudy2 Is Nothing Then
        MsgBox "Motion keys did not record and the fallback study could not be created." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Universal Coupling"
        Exit Function
    End If
    bRotOK = False
    On Error Resume Next
    oStudy2.Activate
    oStudy2.StudyType = 1
    Err.Clear
    Call oStudy2.CreateByRotateModel(True, 2, totalTurns, 0, durationSec, 0)
    bRotOK = (Err.Number = 0)
    oStudy2.SetDuration durationSec
    oStudy2.Calculate
    oStudy2.SetTime 0
    On Error GoTo 0
    If Not bRotOK Then
        MsgBox "Sorry, the motion study could not be created automatically." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Universal Coupling"
        Exit Function
    End If
    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    gMotionMsg = "Motion Study READY in UniversalCoupling_Motion.SLDASM (open now, use the LAST Motion Study tab): " & _
                 "Rotate Model at " & rpm & " RPM for " & durationSec & " seconds."
    MakeMotionStudy = True
End Function

'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    Dim webStartZ As Double
    ValidateDims = False
    webStartZ = hubToPin - hubLen - webT
    If shaftD < 10 Then MsgBox "Shaft diameter must be at least 10 mm.", vbCritical: Exit Function
    If hubOD <= shaftD + 8 Then MsgBox "Hub outside diameter must be at least shaft diameter + 8 mm.", vbCritical: Exit Function
    If hubLen < 10 Then MsgBox "Hub length is too small (minimum 10 mm).", vbCritical: Exit Function
    If webT < 6 Then MsgBox "Fork web thickness is too small (minimum 6 mm).", vbCritical: Exit Function
    If webStartZ <= cbOD / 2 + 2 Then
        MsgBox "Hub-to-pin distance (" & hubToPin & " mm) is too small: the fork web would hit the centre block." & vbCrLf & _
               "Increase hub-to-pin distance or reduce hub length / web thickness.", vbCritical
        Exit Function
    End If
    If pinD < 6 Or pinD >= cbOD - 4 Then
        MsgBox "Main pin diameter must be at least 6 mm and at least 4 mm smaller than the centre block OD.", vbCritical
        Exit Function
    End If
    If pinOffset <= pinD + 2 Then
        MsgBox "Pin axis offset (" & pinOffset & " mm) must be larger than the pin diameter (" & pinD & " mm) + 2 mm so the two perpendicular pins do not collide.", vbCritical
        Exit Function
    End If
    If cbOD <= pinOffset + 2 Then
        MsgBox "Centre block sleeve OD (" & cbOD & " mm) must be larger than the pin axis offset (" & pinOffset & " mm) + 2 mm so the two sleeves merge into one solid block.", vbCritical
        Exit Function
    End If
    If forkW <= pinD + 8 Then
        MsgBox "Fork width / ear OD (" & forkW & " mm) must be at least pin diameter + 8 mm.", vbCritical
        Exit Function
    End If
    If forkGap <= forkW + 4 Then
        MsgBox "Fork inside gap (" & forkGap & " mm) must be at least fork width (" & forkW & " mm) + 4 mm so the two perpendicular forks clear each other.", vbCritical
        Exit Function
    End If
    If (shaftD / 2 + hKey / 2 + CLR) >= (forkGap / 2 - 2) Then
        MsgBox "Fork inside gap is too small for the shaft bore and keyway.", vbCritical
        Exit Function
    End If
    If (shaftD / 2 + hKey / 2 + CLR) >= (hubOD / 2 - 2) Then
        MsgBox "Keyway would break out of the hub wall. Reduce key height or increase hub outside diameter.", vbCritical
        Exit Function
    End If
    If armT < 5 Then MsgBox "Fork arm (cheek) thickness must be at least 5 mm.", vbCritical: Exit Function
    If collarOD <= pinD + 4 Then MsgBox "Collar / pin-head diameter must be at least pin diameter + 4 mm.", vbCritical: Exit Function
    If collarT < 4 Then MsgBox "Collar / pin-head thickness must be at least 4 mm.", vbCritical: Exit Function
    If lockPinD < 2 Or lockPinD >= collarT - 1 Or lockPinD >= pinD - 3 Then
        MsgBox "Locking pin diameter is too large for the collar thickness or main pin diameter.", vbCritical
        Exit Function
    End If
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    Dim keyWDef As Double, lockPinDef As Double
    Dim motionRPM As Double, motionSecs As Double
    Dim sMotionLine As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "UNIVERSAL COUPLING (HOOKE'S JOINT) MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Standard textbook values are already filled - press OK to accept," & vbCrLf & _
           "or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old UniversalCoupling files that are open.", _
           vbInformation, "Universal Coupling"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\UniversalCoupling"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\UniversalCoupling"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = standard textbook proportions from shaft dia D) ----
    gCancelled = False
    shaftD = AskNum("1) Shaft diameter  D  (mm)" & vbCrLf & "All standard proportions are based on D.", 30)
    If gCancelled Then Exit Sub
    hubOD = AskNum("2) Fork hub outside diameter (mm)" & vbCrLf & "Standard = 1.8 x D", Round(1.8 * shaftD, 1))
    If gCancelled Then Exit Sub
    hubLen = AskNum("3) Fork hub length (mm)" & vbCrLf & "Standard = 1.1 x D", Round(1.1 * shaftD, 1))
    If gCancelled Then Exit Sub
    webT = AskNum("4) Fork web (back wall) thickness (mm)" & vbCrLf & "Standard = 0.6 x D  (total bore length = 1.7 x D)", Round(0.6 * shaftD, 1))
    If gCancelled Then Exit Sub
    hubToPin = AskNum("5) Hub back face to pin axis distance (mm)" & vbCrLf & "Standard = 2.6 x D", Round(2.6 * shaftD, 1))
    If gCancelled Then Exit Sub
    forkW = AskNum("6) Fork arm width & rounded ear OD (mm)" & vbCrLf & "Standard = 1.6 x D  (ear radius = 0.8 x D)", Round(1.6 * shaftD, 1))
    If gCancelled Then Exit Sub
    forkGap = AskNum("7) Inside gap between fork arms / centre block length (mm)" & vbCrLf & "Standard = 2.2 x D", Round(2.2 * shaftD, 1))
    If gCancelled Then Exit Sub
    armT = AskNum("8) Each fork arm (cheek) thickness (mm)" & vbCrLf & "Standard = 0.5 x D", Round(0.5 * shaftD, 1))
    If gCancelled Then Exit Sub
    pinD = AskNum("9) Main pin diameter & centre block bore (mm)" & vbCrLf & "Standard = 0.6 x D", Round(0.6 * shaftD, 1))
    If gCancelled Then Exit Sub
    cbOD = AskNum("10) Centre block sleeve outside diameter (mm)" & vbCrLf & "Standard = 1.1 x D", Round(1.1 * shaftD, 1))
    If gCancelled Then Exit Sub
    pinOffset = AskNum("11) Offset between perpendicular pin axes in centre block (mm)" & vbCrLf & "Standard = 0.8 x D", Round(0.8 * shaftD, 1))
    If gCancelled Then Exit Sub
    collarOD = AskNum("12) Pin head & collar outside diameter (mm)" & vbCrLf & "Standard = 1.0 x D", Round(1# * shaftD, 1))
    If gCancelled Then Exit Sub
    collarT = AskNum("13) Pin head & collar thickness (mm)" & vbCrLf & "Standard = 0.25 x D", Round(0.25 * shaftD, 1))
    If gCancelled Then Exit Sub
    If collarT <= 6.5 Then
        lockPinDef = Round(collarT * 0.55, 1)
        If lockPinDef < 2.5 Then lockPinDef = 2.5
    Else
        lockPinDef = 5
    End If
    lockPinD = AskNum("14) Taper / split locking pin diameter (mm)" & vbCrLf & "Standard drawing value = 5 mm", lockPinDef)
    If gCancelled Then Exit Sub
    shaftLen = AskNum("15) Visible shaft length outside hub, each side (mm)" & vbCrLf & "Standard = 2.5 x D", Round(2.5 * shaftD, 1))
    If gCancelled Then Exit Sub
    keyWDef = StdKeyWidth(shaftD)
    wKey = AskNum("16) Key width (mm)" & vbCrLf & "Standard key width for this shaft is filled.", keyWDef)
    If gCancelled Then Exit Sub
    hKey = AskNum("17) Key height / thickness (mm)", Round(wKey * 0.7, 1))
    If gCancelled Then Exit Sub

    If Not ValidateDims() Then Exit Sub

    ' ---- Calculated values ----
    forkOuterH = forkGap + 2 * armT
    forkMidY = forkOuterH / 2
    pinTipExtra = Round(0.15 * shaftD, 1)
    If pinTipExtra < 3 Then pinTipExtra = 3
    pinShaftLen = forkOuterH + collarT + pinTipExtra
    lockPinLen = collarOD + 6
    shaftFitLen = hubLen + webT - 2
    shaftPartLen = shaftLen + shaftFitLen
    keyLen = shaftFitLen

    ' ---- Summary + confirmation ----
    sSummary = "Universal Coupling will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Shaft diameter (D)       = " & shaftD & vbCrLf & _
        "Hub OD / length          = " & hubOD & " / " & hubLen & " (+" & webT & " web)" & vbCrLf & _
        "Hub back to pin axis     = " & hubToPin & vbCrLf & _
        "Fork width / inside gap  = " & forkW & " / " & forkGap & " (arm thk " & armT & ")" & vbCrLf & _
        "Centre block OD / length = " & cbOD & " / " & forkGap & " (pin offset " & pinOffset & ")" & vbCrLf & _
        "Main pin dia / length    = " & pinD & " / " & pinShaftLen & vbCrLf & _
        "Head & collar OD / thk   = " & collarOD & " / " & collarT & " (lock pin dia " & lockPinD & ")" & vbCrLf & _
        "Key (L x W x H)          = " & keyLen & " x " & wKey & " x " & hKey & vbCrLf & _
        "Shaft total length       = " & shaftPartLen & " each" & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Universal Coupling - Confirm") = vbCancel Then Exit Sub

    ' ---- Choose mouse-drag movement mode ----
    gKeepAligned = True
    If MsgBox("How should the coupling move when you drag one side with the mouse?" & vbCrLf & vbCrLf & _
              "YES = ROTATE TOGETHER (dragging either shaft or fork rotates" & vbCrLf & _
              "      the centre block and the other shaft/fork together)." & vbCrLf & _
              "      [You can still bend it anytime by suppressing the last" & vbCrLf & _
              "       mate 'Keep_Shafts_Aligned_(Suppress_To_Bend)' in Mates.]" & vbCrLf & vbCrLf & _
              "NO  = FREE HINGE / BEND + ROTATE (dragging the driven side" & vbCrLf & _
              "      tilts/bends it around both perpendicular pins, and" & vbCrLf & _
              "      dragging the driving side rotates the coupling).", _
              vbYesNo + vbQuestion, "Universal Coupling - Movement Mode") = vbNo Then
        gKeepAligned = False
    End If

    ' ---- Default reference axis names (updated with actual names during creation) ----
    gCB_PlaneVertName = "Plane_Vert"
    gCB_AxisHorizName = "Axis_Horiz"
    gCB_AxisVertName = "Axis_Vert"
    gFU_AxisPinName = "Axis_Pin"
    gFU_AxisShaftName = "Axis_Shaft"
    gAssy_AxisZName = "Axis_Assy_Z"

    ' ---- Build all 7 unique parts ----
    gStep = "Making Centre Block"
    If Not MakeCentreBlock(sFolder & "\Centre_Block.SLDPRT") Then Exit Sub
    gStep = "Making Fork (Yoke)"
    If Not MakeFork(sFolder & "\Fork.SLDPRT") Then Exit Sub
    gStep = "Making Main Pin"
    If Not MakePin(sFolder & "\Pin.SLDPRT") Then Exit Sub
    gStep = "Making Collar"
    If Not MakeCollar(sFolder & "\Collar.SLDPRT") Then Exit Sub
    gStep = "Making Taper Locking Pin"
    If Not MakeTaperPin(sFolder & "\Taper_Pin.SLDPRT") Then Exit Sub
    gStep = "Making Shaft"
    If Not MakeShaft(sFolder & "\Shaft.SLDPRT") Then Exit Sub
    gStep = "Making Key"
    If Not MakeKey(sFolder & "\Key.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 7 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Universal Coupling"
        Exit Sub
    End If

    ' ---- Optional Motion Study ----
    gMotionOK = False
    gMotionMsg = ""
    If MsgBox("Model is ready." & vbCrLf & vbCrLf & _
              "Create the MOTION STUDY also? (rotating coupling)" & vbCrLf & vbCrLf & _
              "YES = create motion study now" & vbCrLf & _
              "NO  = finish with model only", _
              vbYesNo + vbQuestion, "Universal Coupling - Motion Study") = vbYes Then
        gCancelled = False
        motionRPM = AskNum("18) MOTION: Speed in RPM" & vbCrLf & "60 RPM = 1 full rotation per second", 60)
        If Not gCancelled Then
            motionSecs = AskNum("19) MOTION: Duration in SECONDS", 5)
            If Not gCancelled Then
                MsgBox "Motion Study is being created. Please WAIT..." & vbCrLf & _
                       "Do not click anywhere till the DONE message comes.", vbInformation, "Universal Coupling"
                gStep = "Creating motion study"
                gMotionOK = MakeMotionStudy(sFolder, motionRPM, motionSecs)
            End If
        End If
    End If

    If gMotionOK Then
        sMotionLine = gMotionMsg & vbCrLf & vbCrLf & _
            "TO PLAY: click the 'Motion Study' tab at the BOTTOM of the window," & vbCrLf & _
            "then click 'Play from Start' (play button at top-left of the timeline)." & vbCrLf & vbCrLf
    Else
        sMotionLine = ""
    End If

        MsgBox "DONE!  Universal Coupling (Hooke's Joint) V2 is ready with MOVING MATES." & vbCrLf & vbCrLf & _
           "Model assembly file:  UniversalCoupling.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           sMotionLine & _
           "HOW TO MOVE IT WITH THE MOUSE:" & vbCrLf & _
           "  - Click and drag EITHER fork or shaft to rotate the coupling:" & vbCrLf & _
           "    both sides and the centre block move together!" & vbCrLf & _
           "  - Want to tilt/bend one side at an angle? Expand 'Mates' in the" & vbCrLf & _
           "    left tree, right-click 'Keep_Shafts_Aligned_(Suppress_To_Bend)'," & vbCrLf & _
           "    and click Suppress.", _
           vbInformation, "Universal Coupling" 
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Universal Coupling V2)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Universal Coupling - Error"
End Sub
