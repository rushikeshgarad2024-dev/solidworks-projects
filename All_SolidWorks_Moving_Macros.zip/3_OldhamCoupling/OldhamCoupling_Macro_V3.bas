'=====================================================================================
'  OLDHAM COUPLING MACRO  -  VERSION 3 (MOVING KINEMATIC MATES)
'  Standard 3-disc Oldham Coupling - Full Assembly (exam model)
'  For SOLIDWORKS 2016 to 2025  (VBA macro)
'  V2: full error re-check. Key length now always fits inside the hub
'  engagement (for big shafts it could stick out in V1). Extra validations.
'-------------------------------------------------------------------------------------
'  EXAM POINT: Oldham coupling joins two shafts which are parallel but
'  slightly out of line (LATERAL / PARALLEL MISALIGNMENT). The centre
'  floating disc has two tongues at 90 degrees. The tongues slide in the
'  slots of the two end hubs, so power is transmitted even when the shaft
'  axes are offset. (This model is made in the normal aligned position.)
'
'  Torque path: Driving shaft -> Key 1 -> Driving hub (slot)
'               -> Centre disc tongue 1 -> Centre disc
'               -> Centre disc tongue 2 (90 deg) -> Driven hub (slot)
'               -> Key 2 -> Driven shaft
'-------------------------------------------------------------------------------------
'  HOW TO RUN (short):
'     1) Open SOLIDWORKS. Close any old OldhamCoupling files if open.
'     2) Tools > Macro > New  -> save as  OldhamCoupling.swp  (anywhere)
'     3) The macro editor opens. Select ALL old code (Ctrl+A), Delete,
'        then paste THIS FULL CODE.
'     4) Press F5  (or click the green Run / Play button).
'     5) Small pop-up boxes will ask your dimensions one by one (in mm).
'        A standard value is already filled - just press OK/Enter to accept it,
'        or type your own value from your drawing / design calculation.
'     6) Wait. The macro will automatically create:
'            Hub_A_Driving.SLDPRT   (end hub with HORIZONTAL slot)
'            Hub_B_Driven.SLDPRT    (end hub with VERTICAL slot)
'            Centre_Disc.SLDPRT     (floating disc, tongues at 90 degrees)
'            Shaft.SLDPRT           (used 2 times)
'            Key.SLDPRT             (used 2 times)
'            OldhamCoupling.SLDASM  (all parts placed in correct position)
'            OldhamCoupling_Motion.SLDASM (only if you say YES to motion study)
'        All files are saved in the folder you choose in the first pop-up
'        (default: Documents\OldhamCoupling).
'
'  DEFAULT DIMENSIONS = simple standard proportions from shaft diameter d:
'        Disc diameter = 3d      Hub diameter = 2d
'        Disc thickness = 0.4d   Tongue width = 0.5d, height = 0.15d
'
'  NOTES (simplifications, normal for student models):
'    - Slot is made 1 mm wider and 1 mm deeper than the tongue (sliding fit).
'    - Centre disc is made slightly smaller than the end discs (floating).
'    - Shaft has no separate keyseat groove - the key sits half in the shaft,
'      half in the hub keyway (looks correct in assembly).
'    - Parts in the assembly are placed exactly by position (Transform),
'      no mates are added. Do not drag parts after opening.
'    - All API sizes are in METRES internally, you only type MM.
'=====================================================================================
Option Explicit

'------------------------- Globals -------------------------
Private swApp As Object            ' SOLIDWORKS application (late binding = works on all versions)
Private gCancelled As Boolean
Private gStep As String            ' name of current step - shown in error message (for easy fixing)
Private gAsmDoc As Object          ' V6: the finished assembly document (for the motion study)
Private gMotionOK As Boolean       ' V6: True when the motion study was created
Private gMotionMsg As String
Private gCD_RightPlaneName As String
Private gDrvAxisName As String
Private gAssyAxisName As String       ' V6: short motion-study result text for the final message

' User dimensions (mm)
Private dShaft As Double           ' Shaft / hub bore diameter  d
Private dDisc As Double            ' Outside diameter of the two end discs
Private dHub As Double             ' Hub outside diameter
Private tDisc As Double            ' Thickness of each end disc (slot is cut in it)
Private lHubOut As Double          ' Hub length OUTSIDE the disc (towards shaft side)
Private dCenter As Double          ' Centre floating disc diameter
Private tCenter As Double          ' Centre disc thickness (without tongues)
Private wTongue As Double          ' Tongue width (= slot width minus clearance)
Private hTongue As Double          ' Tongue height (projection from centre disc face)
Private lShaftExp As Double        ' Visible shaft length outside hub (each side)
Private wKey As Double             ' Key width
Private hKey As Double             ' Key height (thickness)

' Calculated dimensions (mm)
Private slotW As Double            ' Slot width in end hubs (tongue + clearance)
Private slotDepth As Double        ' Slot depth (tongue height + clearance)
Private endLenTotal As Double      ' Total length of one end hub (disc + hub)
Private shaftPartLen As Double     ' Total length of one Shaft part
Private keyLen As Double           ' Key length

Private Const PI_VAL As Double = 3.14159265358979
Private Const CLR As Double = 0.5          ' clearance (mm) for recess & bolt holes (+1 on dia = 2x0.5)

'------------------------- Small helpers -------------------------
Private Function Mm(ByVal v As Double) As Double
    Mm = v / 1000#                          ' SOLIDWORKS API works in metres
End Function

Private Function AskNum(ByVal sPrompt As String, ByVal dblDefault As Double) As Double
    Dim s As String
    AskNum = dblDefault
    Do
        s = InputBox(sPrompt, "Oldham Coupling - Enter Dimension (mm)", CStr(dblDefault))
        If StrPtr(s) = 0 Then               ' Cancel pressed
            gCancelled = True
            Exit Function
        End If
        If IsNumeric(s) Then
            If CDbl(s) > 0 Then
                AskNum = CDbl(s)
                Exit Function
            End If
        End If
        MsgBox "Please enter a number greater than 0 (mm).", vbExclamation, "Oldham Coupling"
    Loop
End Function

Private Function AskText(ByVal sPrompt As String, ByVal sDefault As String) As String
    Dim s As String
    s = InputBox(sPrompt, "Oldham Coupling", sDefault)
    If StrPtr(s) = 0 Then
        gCancelled = True
        AskText = ""
    Else
        AskText = Trim(s)
    End If
End Function

Private Function StdKeyWidth(ByVal d As Double) As Double
    ' Approximate standard parallel key width for shaft diameter d
    Select Case d
        Case Is <= 22: StdKeyWidth = 6
        Case Is <= 30: StdKeyWidth = 8
        Case Is <= 38: StdKeyWidth = 10
        Case Is <= 44: StdKeyWidth = 12
        Case Is <= 50: StdKeyWidth = 14
        Case Is <= 58: StdKeyWidth = 16
        Case Is <= 65: StdKeyWidth = 18
        Case Else:     StdKeyWidth = 20
    End Select
End Function


'------------------------- Sketch / feature helpers -------------------------
Private Function OpenFrontSketch(ByVal oDoc As Object) As Boolean
    Dim bOk As Boolean
    oDoc.ClearSelection2 True
    bOk = oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
    If Not bOk Then
        MsgBox "Could not select FRONT PLANE." & vbCrLf & _
               "Your part template may use different plane names." & vbCrLf & _
               "Set a normal English Part template and run again.", vbCritical, "Oldham Coupling"
        OpenFrontSketch = False
        Exit Function
    End If
    oDoc.SketchManager.InsertSketch True
    oDoc.SketchManager.AddToDB = True       ' exact coordinates, no auto-snapping
    OpenFrontSketch = True
End Function

Private Sub DrawCircle(ByVal oDoc As Object, ByVal cxMm As Double, ByVal cyMm As Double, ByVal diaMm As Double)
    Call oDoc.SketchManager.CreateCircleByRadius(Mm(cxMm), Mm(cyMm), 0, Mm(diaMm) / 2)
End Sub

Private Sub DrawHex(ByVal oDoc As Object, ByVal acrossFlatsMm As Double)
    ' Regular hexagon, centre at origin. Vertex radius R = AF / sqrt(3).
    ' CreatePolygon(Xc,Yc,Zc, Xvertex,Yvertex,Zvertex, Sides, Inscribed)
    Dim R As Double
    Dim vPoly As Variant
    R = acrossFlatsMm / 1.73205080756888
    vPoly = oDoc.SketchManager.CreatePolygon(0, 0, 0, Mm(R), 0, 0, 6, True)
End Sub

' Boss-Extrude the currently OPEN sketch. reverseDir=True extrudes in -Z.
' startOffsetMm>0 starts the extrusion away from the Front Plane (swStartOffset = 3).
Private Function BossFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                    ByVal reverseDir As Boolean, ByVal startOffsetMm As Double, _
                                    ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim t0 As Long
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Boss-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    If startOffsetMm > 0.001 Then t0 = 3 Else t0 = 0
    ' FeatureExtrusion2: Sd,Flip,Dir,T1,T2,D1,D2,Dchk1,Dchk2,Ddir1,Ddir2,Dang1,Dang2,
    '   OffsetRev1,OffsetRev2,Translate1,Translate2,Merge,UseFeatScope,UseAutoSelect,
    '   T0,StartOffset,FlipStartOffset        (T1=0 means Blind)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - extrude directly.
    Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and extrude again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureExtrusion2(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, True, True, True, t0, Mm(startOffsetMm), False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Boss-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Oldham Coupling"
        BossFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    BossFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, THROUGH ALL in BOTH directions.
' (Both directions = cut works no matter which side the material is on.)
Private Function CutThroughAllFromOpenSketch(ByVal oDoc As Object, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude: " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=False (double-ended), T1=1 and T2=1 (Through All both ends)
    ' TRY 1: just after closing, SOLIDWORKS keeps this sketch selected - cut directly.
    Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                    False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    ' TRY 2: select the sketch BY NAME (recorded macro style) and cut again.
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(False, False, False, 1, 1, 0.01, 0.01, _
                            False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Cut-Extrude FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Oldham Coupling"
        CutThroughAllFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutThroughAllFromOpenSketch = True
End Function

' Cut-Extrude the currently OPEN sketch, BLIND (limited depth), one direction.
' Used for the Oldham slots. If the direction convention differs on a version,
' the opposite direction is also tried (material exists on only one side,
' so only the correct direction can succeed).
Private Function CutBlindFromOpenSketch(ByVal oDoc As Object, ByVal depthMm As Double, _
                                        ByVal reverseDir As Boolean, ByVal featName As String) As Boolean
    Dim oSketch As Object, oFeat As Object
    Dim sSketchName As String
    Dim bSel As Boolean
    gStep = "Cut-Extrude (blind): " & featName
    Set oSketch = oDoc.SketchManager.ActiveSketch
    On Error Resume Next
    If Not oSketch Is Nothing Then sSketchName = oSketch.Name
    On Error GoTo 0
    oDoc.SketchManager.AddToDB = False
    oDoc.SketchManager.InsertSketch True    ' close sketch
    ' FeatureCut4: Sd=True (single direction), T1=0 (Blind), D1 = depth
    Set oFeat = oDoc.FeatureManager.FeatureCut4(True, False, reverseDir, 0, 0, _
                    Mm(depthMm), Mm(depthMm), False, False, False, False, _
                    0.0174532925199433, 0.0174532925199433, _
                    False, False, False, False, False, _
                    True, True, True, True, False, 0, 0, False, False)
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(True, False, reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    If oFeat Is Nothing And Len(sSketchName) > 0 Then
        oDoc.ClearSelection2 True
        bSel = oDoc.Extension.SelectByID2(sSketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
        If bSel Then
            Set oFeat = oDoc.FeatureManager.FeatureCut4(True, False, Not reverseDir, 0, 0, _
                            Mm(depthMm), Mm(depthMm), False, False, False, False, _
                            0.0174532925199433, 0.0174532925199433, _
                            False, False, False, False, False, _
                            True, True, True, True, False, 0, 0, False, False)
        End If
    End If
    oDoc.ClearSelection2 True
    If oFeat Is Nothing Then
        MsgBox "Blind Cut FAILED at feature: " & featName & vbCrLf & _
               "Take a screenshot of this message and send it for fixing.", vbCritical, "Oldham Coupling"
        CutBlindFromOpenSketch = False
        Exit Function
    End If
    On Error Resume Next
    oFeat.Name = featName
    On Error GoTo 0
    CutBlindFromOpenSketch = True
End Function

Private Function SaveAndClose(ByVal oDoc As Object, ByVal sPath As String) As Boolean
    Dim sTitle As String
    gStep = "Saving file: " & sPath
    oDoc.SaveAs3 sPath, 0, 0
    If Len(Dir(sPath)) = 0 Then
        MsgBox "Could not save file:" & vbCrLf & sPath & vbCrLf & _
               "Check the folder exists and no old file of same name is open in SOLIDWORKS.", _
               vbCritical, "Oldham Coupling"
        SaveAndClose = False
        Exit Function
    End If
    sTitle = oDoc.GetTitle
    On Error Resume Next
    swApp.CloseDoc sTitle
    On Error GoTo 0
    SaveAndClose = True
End Function

'------------------------- New document helpers -------------------------
' GetUserPreferenceStringValue: 8 = swDefaultTemplatePart, 9 = swDefaultTemplateAssembly
Private Function NewPartDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(8)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewPart()          ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewPartDoc = oDoc
End Function

Private Function NewAssemblyDoc() As Object
    Dim sTpl As String
    Dim oDoc As Object
    sTpl = swApp.GetUserPreferenceStringValue(9)
    If Len(sTpl) > 0 Then Set oDoc = swApp.NewDocument(sTpl, 0, 0, 0)
    If oDoc Is Nothing Then
        On Error Resume Next
        Set oDoc = swApp.NewAssembly()      ' old method, kept only as fallback
        On Error GoTo 0
    End If
    Set NewAssemblyDoc = oDoc
End Function

'------------------------- Hub keyway -------------------------
Private Function AddHubKeyway(ByVal oDoc As Object) As Boolean
    Dim y1 As Double, y2 As Double
    ' Keyway in hub bore (rectangular slot on top of bore)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    y1 = dShaft / 2 - 2                               ' start slightly inside the bore
    y2 = dShaft / 2 + hKey / 2 + CLR                  ' hub keyway depth ~ half key height
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(y1), 0, Mm(wKey / 2), Mm(y2), 0)
    If Not CutThroughAllFromOpenSketch(oDoc, "Keyway") Then Exit Function
    AddHubKeyway = True
End Function

'------------------------- PART 1 & 2: End hubs (with slot) -------------------------
' Local origin = INNER (mating) face of the disc.
'   Driving hub A: body goes in -Z, slot is HORIZONTAL (runs along X).
'   Driven  hub B: body goes in +Z, slot is VERTICAL   (runs along Y).
Private Function MakeEndHub(ByVal sPath As String, ByVal bForward As Boolean, _
                            ByVal bSlotHorizontal As Boolean) As Boolean
    Dim oDoc As Object
    Dim bRev As Boolean
    Dim halfLen As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part (check default Part template).", vbCritical: Exit Function
    bRev = Not bForward
    halfLen = dDisc / 2 + 5
    ' 1) End disc (annulus: disc OD + bore)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dDisc
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, tDisc, bRev, 0, "Disc") Then Exit Function
    ' 2) Hub (annulus: hub OD + bore) for the full end length (overlaps the disc)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dHub
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, endLenTotal, bRev, 0, "Hub") Then Exit Function
    ' 3) Keyway in the bore
    If Not AddHubKeyway(oDoc) Then Exit Function
    ' 4) Diametral slot in the inner face (blind cut)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    If bSlotHorizontal Then
        Call oDoc.SketchManager.CreateCornerRectangle(Mm(-halfLen), Mm(-slotW / 2), 0, Mm(halfLen), Mm(slotW / 2), 0)
    Else
        Call oDoc.SketchManager.CreateCornerRectangle(Mm(-slotW / 2), Mm(-halfLen), 0, Mm(slotW / 2), Mm(halfLen), 0)
    End If
    If Not CutBlindFromOpenSketch(oDoc, slotDepth, bRev, "Slot") Then Exit Function
    MakeEndHub = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 3: Centre floating disc -------------------------
' Local origin = LEFT face of the centre disc plate.
' Left tongue (along X) sticks out in -Z, right tongue (along Y) in +Z.
Private Function MakeCentreDisc(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Dim tongueLen As Double, chordHalf As Double
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    ' Tongue length: chord of the centre disc at the tongue width (ends inside the disc)
    chordHalf = Sqr((dCenter / 2) * (dCenter / 2) - (wTongue / 2) * (wTongue / 2))
    tongueLen = 2 * chordHalf - 1
    ' 1) Centre plate (solid disc, no bore)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dCenter
    If Not BossFromOpenSketch(oDoc, tCenter, False, 0, "Centre_Plate") Then Exit Function
    ' 2) Left tongue - along X, sticking out backwards (-Z)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-tongueLen / 2), Mm(-wTongue / 2), 0, Mm(tongueLen / 2), Mm(wTongue / 2), 0)
    If Not BossFromOpenSketch(oDoc, hTongue, True, 0, "Tongue_Left") Then Exit Function
    ' 3) Right tongue - along Y (90 degrees), sticking out forwards (+Z)
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wTongue / 2), Mm(-tongueLen / 2), 0, Mm(wTongue / 2), Mm(tongueLen / 2), 0)
    If Not BossFromOpenSketch(oDoc, hTongue, False, tCenter, "Tongue_Right") Then Exit Function
    ' Reference plane on the right face (Z = +tCenter) for sliding mate with Driven_Unit
    Dim oRefP As Object, oFeat As Object
    gCD_RightPlaneName = "Plane1"
    oDoc.ClearSelection2 True
    If oDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        Set oRefP = oDoc.FeatureManager.InsertRefPlane(8, Mm(tCenter), 0, 0, 0, 0)
        oDoc.ClearSelection2 True
        On Error Resume Next
        Set oFeat = oDoc.FeatureByPositionReverse(0)
        If Not oFeat Is Nothing Then
            gCD_RightPlaneName = oFeat.Name
            oFeat.Name = "Plane_RightFace"
            gCD_RightPlaneName = oFeat.Name
        End If
        On Error GoTo 0
    End If
    MakeCentreDisc = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 4: Shaft -------------------------
' Local: from Z=0 to Z=shaftPartLen along +Z.
Private Function MakeShaft(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    DrawCircle oDoc, 0, 0, dShaft
    If Not BossFromOpenSketch(oDoc, shaftPartLen, False, 0, "Shaft") Then Exit Function
    MakeShaft = SaveAndClose(oDoc, sPath)
End Function

'------------------------- PART 5: Key -------------------------
' Local: rectangle (width x height) centred on origin, extruded +Z by key length.
Private Function MakeKey(ByVal sPath As String) As Boolean
    Dim oDoc As Object
    Set oDoc = NewPartDoc()
    If oDoc Is Nothing Then MsgBox "Could not create new Part.", vbCritical: Exit Function
    If Not OpenFrontSketch(oDoc) Then Exit Function
    Call oDoc.SketchManager.CreateCornerRectangle(Mm(-wKey / 2), Mm(-hKey / 2), 0, Mm(wKey / 2), Mm(hKey / 2), 0)
    If Not BossFromOpenSketch(oDoc, keyLen, False, 0, "Key") Then Exit Function
    MakeKey = SaveAndClose(oDoc, sPath)
End Function

'------------------------- Assembly -------------------------
' V4 FIX: AddComponent5 inserts a PRE-LOADED part, so first load the part
' file into memory (silent). 1 = swDocPART, 1 = swOpenDocOptions_Silent.
Private Function LoadDocForAssembly(ByVal sPath As String, ByVal docType As Long) As Boolean
    Dim oTmp As Object
    Dim lErr As Long, lWarn As Long
    gStep = "Loading document for assembly: " & sPath
    Set oTmp = swApp.OpenDoc6(sPath, docType, 1, "", lErr, lWarn)
    If oTmp Is Nothing Then
        MsgBox "Could not LOAD this file for the assembly:" & vbCrLf & sPath & vbCrLf & _
               "OpenDoc error code: " & lErr & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Oldham Coupling"
        LoadDocForAssembly = False
        Exit Function
    End If
    LoadDocForAssembly = True
End Function

Private Function CompAtPosition(ByVal oComp As Object, ByVal xMm As Double, _
                                ByVal yMm As Double, ByVal zMm As Double) As Boolean
    Dim vNow As Variant
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Abs(vNow(9) - Mm(xMm)) > 0.0015 Then Exit Function
    If Abs(vNow(10) - Mm(yMm)) > 0.0015 Then Exit Function
    If Abs(vNow(11) - Mm(zMm)) > 0.0015 Then Exit Function
    CompAtPosition = True
End Function

Private Function PlaceComponentRef(ByVal oAsm As Object, ByVal sPath As String, _
                                   ByVal xMm As Double, ByVal yMm As Double, ByVal zMm As Double, _
                                   ByRef oOutComp As Object) As Boolean
    Dim oComp As Object, oMU As Object, oXf As Object
    Dim aData(0 To 15) As Double
    Dim vData As Variant
    Dim bOk As Boolean
    gStep = "Inserting into assembly: " & sPath
    Set oComp = oAsm.AddComponent5(sPath, 0, "", False, "", Mm(xMm), Mm(yMm), Mm(zMm))
    If oComp Is Nothing Then
        MsgBox "Could not insert component into assembly:" & vbCrLf & sPath, vbCritical, "Oldham Coupling"
        PlaceComponentRef = False
        Exit Function
    End If
    Set oOutComp = oComp
    aData(0) = 1: aData(1) = 0: aData(2) = 0: aData(3) = 0
    aData(4) = 1: aData(5) = 0: aData(6) = 0: aData(7) = 0
    aData(8) = 1: aData(9) = Mm(xMm): aData(10) = Mm(yMm): aData(11) = Mm(zMm)
    aData(12) = 1: aData(13) = 0: aData(14) = 0: aData(15) = 0
    vData = aData
    Set oMU = swApp.GetMathUtility()
    Set oXf = oMU.CreateTransform((vData))
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    On Error GoTo 0
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        On Error Resume Next
        oComp.Transform2 = oXf
        On Error GoTo 0
    End If
    If Not CompAtPosition(oComp, xMm, yMm, zMm) Then
        MsgBox "Component was inserted but could NOT be moved to its correct position:" & vbCrLf & _
               sPath & vbCrLf & _
               "Required position (mm)  X=" & xMm & "  Y=" & yMm & "  Z=" & zMm & vbCrLf & vbCrLf & _
               "Please send a screenshot of this message.", vbCritical, "Oldham Coupling"
        PlaceComponentRef = False
        Exit Function
    End If
    PlaceComponentRef = True
End Function

Private Sub FixAllComponents(ByVal oAsm As Object)
    Dim vComps As Variant
    Dim j As Long
    Dim oComp As Object
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If Not IsArray(vComps) Then Exit Sub
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        If Not oComp Is Nothing Then
            On Error Resume Next
            oAsm.ClearSelection2 True
            If oComp.Select4(False, Nothing, False) Then oAsm.FixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

' Build a rigid end-unit subassembly (Hub + Shaft + Key) with origin at the hub's inner face.
Private Function MakeEndUnitSub(ByVal sHubPath As String, ByVal sShaftPath As String, _
                                ByVal sKeyPath As String, ByVal bDrivingLeft As Boolean, _
                                ByVal sSubPath As String) As Boolean
    Dim oSub As Object, oDummy As Object, oFeat As Object
    Dim sSubTitle As String
    Dim lErr As Long
    Dim zShaft As Double, zKey As Double

    Set oSub = NewAssemblyDoc()
    If oSub Is Nothing Then MsgBox "Could not create end subassembly.", vbCritical: Exit Function
    sSubTitle = oSub.GetTitle

    If bDrivingLeft Then
        gDrvAxisName = "Axis1"
        oSub.ClearSelection2 True
        If oSub.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
            If oSub.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
                If oSub.InsertAxis2(True) Then
                    oSub.ClearSelection2 True
                    On Error Resume Next
                    Set oFeat = oSub.FeatureByPositionReverse(0)
                    If Not oFeat Is Nothing Then
                        gDrvAxisName = oFeat.Name
                        oFeat.Name = "Axis_Driving"
                        gDrvAxisName = oFeat.Name
                    End If
                    On Error GoTo 0
                End If
            End If
        End If
        oSub.ClearSelection2 True
        zShaft = -(slotDepth + 1 + shaftPartLen)
        zKey = -(slotDepth + 1 + keyLen)
    Else
        zShaft = slotDepth + 1
        zKey = slotDepth + 1
    End If

    If Not LoadDocForAssembly(sHubPath, 1) Then Exit Function
    If Not LoadDocForAssembly(sShaftPath, 1) Then Exit Function
    If Not LoadDocForAssembly(sKeyPath, 1) Then Exit Function
    swApp.ActivateDoc2 sSubTitle, False, lErr

    If Not PlaceComponentRef(oSub, sHubPath, 0, 0, 0, oDummy) Then Exit Function
    If Not PlaceComponentRef(oSub, sShaftPath, 0, 0, zShaft, oDummy) Then Exit Function
    If Not PlaceComponentRef(oSub, sKeyPath, 0, dShaft / 2, zKey, oDummy) Then Exit Function

    Call FixAllComponents(oSub)
    Call oSub.ForceRebuild3(False)
    oSub.SaveAs3 sSubPath, 0, 0
    If Len(Dir(sSubPath)) = 0 Then
        MsgBox "Could not save subassembly: " & sSubPath, vbCritical, "Oldham Coupling"
        MakeEndUnitSub = False
        Exit Function
    End If
    MakeEndUnitSub = True
End Function

Private Function SelectForOldhamMate(ByVal oAsm As Object, ByVal oComp As Object, _
                                     ByVal sFeatName As String, ByVal sAltName As String, _
                                     ByVal sType As String, ByVal bAppend As Boolean) As Boolean
    Dim oFeat As Object
    Dim sAssyName As String
    Dim bOk As Boolean
    bOk = False
    If Not oComp Is Nothing Then
        On Error Resume Next
        Set oFeat = oComp.FeatureByName(sFeatName)
        If oFeat Is Nothing And Len(sAltName) > 0 Then Set oFeat = oComp.FeatureByName(sAltName)
        If Not oFeat Is Nothing Then bOk = oFeat.Select2(bAppend, 1)
        On Error GoTo 0
    End If
    If Not bOk Then
        sAssyName = oAsm.GetTitle
        If InStr(sAssyName, ".") > 0 Then sAssyName = Split(sAssyName, ".")(0)
        On Error Resume Next
        If Not oComp Is Nothing Then
            bOk = oAsm.Extension.SelectByID2(sFeatName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName & "@" & oComp.Name2 & "@" & sAssyName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        Else
            bOk = oAsm.Extension.SelectByID2(sFeatName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            If Not bOk And Len(sAltName) > 0 Then
                bOk = oAsm.Extension.SelectByID2(sAltName, sType, 0, 0, 0, bAppend, 1, Nothing, 0)
            End If
        End If
        On Error GoTo 0
    End If
    SelectForOldhamMate = bOk
End Function

Private Sub AddSimpleCoincidentMate(ByVal oAsm As Object, _
                                    ByVal oComp1 As Object, ByVal sFeat1 As String, ByVal sAlt1 As String, ByVal sType1 As String, _
                                    ByVal oComp2 As Object, ByVal sFeat2 As String, ByVal sAlt2 As String, ByVal sType2 As String, _
                                    ByVal alignCode As Long, ByVal sMateName As String)
    Dim oMate As Object
    Dim lMateErr As Long
    oAsm.ClearSelection2 True
    If SelectForOldhamMate(oAsm, oComp1, sFeat1, sAlt1, sType1, False) Then
        If SelectForOldhamMate(oAsm, oComp2, sFeat2, sAlt2, sType2, True) Then
            On Error Resume Next
            Set oMate = oAsm.AddMate5(0, alignCode, False, 0, 0, 0, 0, 0, 0, 0, 0, False, False, 0, lMateErr)
            If oMate Is Nothing Then
                Set oMate = oAsm.AddMate3(0, alignCode, False, 0, 0, 0, 0, 0, 0, 0, 0, False, lMateErr)
            End If
            If Not oMate Is Nothing Then oMate.Name = sMateName
            On Error GoTo 0
        End If
    End If
    oAsm.ClearSelection2 True
End Sub

Private Function MakeAssembly(ByVal sFolder As String) As Boolean
    Dim oAsm As Object, oFeat As Object
    Dim oCompDrv As Object, oCompCD As Object, oCompDvn As Object
    Dim vComps As Variant
    Dim pA As String, pB As String, pC As String, pShaft As String, pKey As String
    Dim pSubDrv As String, pSubDvn As String
    Dim sAsmTitle As String
    Dim lErr As Long
    pA = sFolder & "\Hub_A_Driving.SLDPRT"
    pB = sFolder & "\Hub_B_Driven.SLDPRT"
    pC = sFolder & "\Centre_Disc.SLDPRT"
    pShaft = sFolder & "\Shaft.SLDPRT"
    pKey = sFolder & "\Key.SLDPRT"
    pSubDrv = sFolder & "\Driving_Unit.SLDASM"
    pSubDvn = sFolder & "\Driven_Unit.SLDASM"

    ' Build the two rigid end-unit subassemblies (Hub + Shaft + Key)
    If Not MakeEndUnitSub(pA, pShaft, pKey, True, pSubDrv) Then Exit Function
    If Not MakeEndUnitSub(pB, pShaft, pKey, False, pSubDvn) Then Exit Function

    gStep = "Creating new Assembly document"
    Set oAsm = NewAssemblyDoc()
    If oAsm Is Nothing Then MsgBox "Could not create new Assembly (check default Assembly template).", vbCritical: Exit Function
    sAsmTitle = oAsm.GetTitle
    Set gAsmDoc = oAsm

    ' Create Assembly Z axis (shaft rotation axis)
    gAssyAxisName = "Axis1"
    oAsm.ClearSelection2 True
    If oAsm.Extension.SelectByID2("Top Plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0) Then
        If oAsm.Extension.SelectByID2("Right Plane", "PLANE", 0, 0, 0, True, 0, Nothing, 0) Then
            If oAsm.InsertAxis2(True) Then
                oAsm.ClearSelection2 True
                On Error Resume Next
                Set oFeat = oAsm.FeatureByPositionReverse(0)
                If Not oFeat Is Nothing Then
                    gAssyAxisName = oFeat.Name
                    oFeat.Name = "Axis_Assy_Z"
                    gAssyAxisName = oFeat.Name
                End If
                On Error GoTo 0
            End If
        End If
    End If
    oAsm.ClearSelection2 True

    If Not LoadDocForAssembly(pC, 1) Then Exit Function
    If Not LoadDocForAssembly(pSubDrv, 2) Then Exit Function
    If Not LoadDocForAssembly(pSubDvn, 2) Then Exit Function
    gStep = "Activating assembly window"
    swApp.ActivateDoc2 sAsmTitle, False, lErr

    ' Place Driving_Unit at Z = 0, Centre_Disc at Z = 0, Driven_Unit at Z = +tCenter
    If Not PlaceComponentRef(oAsm, pSubDrv, 0, 0, 0, oCompDrv) Then Exit Function
    If Not PlaceComponentRef(oAsm, pC, 0, 0, 0, oCompCD) Then Exit Function
    If Not PlaceComponentRef(oAsm, pSubDvn, 0, 0, tCenter, oCompDvn) Then Exit Function

    ' Unfix all 3 components so the whole coupling rotates and slides
    On Error Resume Next
    vComps = oAsm.GetComponents(True)
    On Error GoTo 0
    If IsArray(vComps) Then Call FloatFixedComponents(oAsm, vComps)

    ' 1) Driving_Unit revolute bearing on Assembly Z axis:
    Call AddSimpleCoincidentMate(oAsm, oCompDrv, gDrvAxisName, "Axis1", "AXIS", _
                                 Nothing, gAssyAxisName, "Axis1", "AXIS", 2, "Driving_Shaft_Axis_Mate")
    Call AddSimpleCoincidentMate(oAsm, oCompDrv, "Front Plane", "", "PLANE", _
                                 Nothing, "Front Plane", "", "PLANE", 0, "Driving_Axial_Lock_Mate")

    ' 2) Centre_Disc horizontal tongue sliding fit in Driving_Unit horizontal slot:
    Call AddSimpleCoincidentMate(oAsm, oCompCD, "Front Plane", "", "PLANE", _
                                 oCompDrv, "Front Plane", "", "PLANE", 0, "Centre_Left_Face_Mate")
    Call AddSimpleCoincidentMate(oAsm, oCompCD, "Top Plane", "", "PLANE", _
                                 oCompDrv, "Top Plane", "", "PLANE", 0, "Horiz_Tongue_Slot_Mate")

    ' 3) Driven_Unit vertical slot sliding fit on Centre_Disc vertical tongue:
    Call AddSimpleCoincidentMate(oAsm, oCompDvn, "Front Plane", "", "PLANE", _
                                 oCompCD, gCD_RightPlaneName, "Plane1", "PLANE", 0, "Centre_Right_Face_Mate")
    Call AddSimpleCoincidentMate(oAsm, oCompDvn, "Right Plane", "", "PLANE", _
                                 oCompCD, "Right Plane", "", "PLANE", 0, "Vert_Tongue_Slot_Mate")

    ' 4) Coaxial alignment mate (suppress in Mates folder to slide tongues laterally!):
    Call AddSimpleCoincidentMate(oAsm, oCompCD, "Right Plane", "", "PLANE", _
                                 oCompDrv, "Right Plane", "", "PLANE", 0, "Keep_Horiz_Centered_(Suppress_To_Slide)")
    Call AddSimpleCoincidentMate(oAsm, oCompDvn, "Top Plane", "", "PLANE", _
                                 oCompCD, "Top Plane", "", "PLANE", 0, "Keep_Vert_Centered_(Suppress_To_Slide)")

    On Error Resume Next
    oAsm.SetUserPreferenceToggle 4, False
    oAsm.SetUserPreferenceToggle 5, False
    On Error GoTo 0

    gStep = "Rebuilding and saving assembly"
    Call oAsm.ForceRebuild3(False)
    oAsm.SaveAs3 sFolder & "\OldhamCoupling.SLDASM", 0, 0
    On Error Resume Next
    oAsm.ShowNamedView2 "*Isometric", 7
    oAsm.ViewZoomtofit2
    swApp.CloseDoc "Driving_Unit.SLDASM"
    swApp.CloseDoc "Driven_Unit.SLDASM"
    swApp.CloseDoc "Hub_A_Driving.SLDPRT"
    swApp.CloseDoc "Hub_B_Driven.SLDPRT"
    swApp.CloseDoc "Centre_Disc.SLDPRT"
    swApp.CloseDoc "Shaft.SLDPRT"
    swApp.CloseDoc "Key.SLDPRT"
    On Error GoTo 0
    MakeAssembly = True
End Function


'=====================================================================================
'  MOTION STUDY (one rigid body method)
'  Type created = Animation (works in every SolidWorks, no Motion add-in needed).
'  Method: the finished coupling assembly is inserted as ONE rigid component
'  into a new file OldhamCoupling_Motion.SLDASM, and only that one component
'  is rotated about the Z (shaft) axis using animation keys. Because it is a
'  single rigid body, all parts stay perfectly together during rotation.
'  The result is VERIFIED by jumping to a quarter-turn time and reading the
'  rotation back. If keys did not record, a "Rotate Model" study is made.
'=====================================================================================

' Move one component to the given transform (same two methods as PlaceComponent).
Private Sub SetCompTransform(ByVal oComp As Object, ByVal oXf As Object)
    Dim bOk As Boolean
    bOk = False
    On Error Resume Next
    bOk = oComp.SetTransformAndSolve2(oXf)
    If Err.Number <> 0 Or Not bOk Then
        Err.Clear
        oComp.Transform2 = oXf
    End If
    On Error GoTo 0
End Sub

' True if the component origin is at the translation stored inside oXf.
Private Function CompAtTransform(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vE As Variant
    On Error Resume Next
    vE = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vE) Then Exit Function
    CompAtTransform = CompAtPosition(oComp, vE(9) * 1000#, vE(10) * 1000#, vE(11) * 1000#)
End Function

' Fixed components cannot move in a motion study - float them.
Private Sub FloatFixedComponents(ByVal oAsm As Object, ByVal vComps As Variant)
    Dim j As Long
    Dim oComp As Object
    Dim bSel As Boolean, bFixed As Boolean
    For j = LBound(vComps) To UBound(vComps)
        Set oComp = vComps(j)
        bFixed = False
        On Error Resume Next
        bFixed = oComp.IsFixed
        On Error GoTo 0
        If bFixed Then
            bSel = False
            On Error Resume Next
            oAsm.ClearSelection2 True
            bSel = oComp.Select4(False, Nothing, False)
            If bSel Then oAsm.UnfixComponent
            oAsm.ClearSelection2 True
            On Error GoTo 0
        End If
    Next j
End Sub

' True if the component rotation (first 9 transform values) matches oXf.
Private Function CompRotationAt(ByVal oComp As Object, ByVal oXf As Object) As Boolean
    Dim vNow As Variant, vExp As Variant
    Dim i As Long
    On Error Resume Next
    vNow = oComp.Transform2.ArrayData
    vExp = oXf.ArrayData
    On Error GoTo 0
    If Not IsArray(vNow) Then Exit Function
    If Not IsArray(vExp) Then Exit Function
    For i = 0 To 8
        If Abs(vNow(i) - vExp(i)) > 0.02 Then Exit Function
    Next i
    CompRotationAt = True
End Function

' V7: make OldhamCoupling_Motion.SLDASM with the finished coupling assembly
' inside it as ONE rigid component, then rotate that one component.
Private Function MakeMotionStudy(ByVal sFolder As String, _
                                 ByVal rpm As Double, ByVal durationSec As Double) As Boolean
    Dim oWrap As Object, oComp As Object
    Dim oMgr As Object, oStudy As Object, oStudy2 As Object
    Dim oMU As Object, oPt As Object, oVec As Object
    Dim oRot As Object, oNew As Object, oOrigXf As Object, oIdXf As Object
    Dim vComps As Variant
    Dim aId(0 To 15) As Double
    Dim vId As Variant
    Dim aPt(0 To 2) As Double, aVec(0 To 2) As Double
    Dim vPt As Variant, vVec As Variant
    Dim sMainAsm As String, sMotionAsm As String
    Dim k As Long, nSteps As Long, kTest As Long
    Dim totalTurns As Double, ang As Double, tNow As Double
    Dim bKeysOK As Boolean, bRotOK As Boolean
    MakeMotionStudy = False
    gMotionMsg = ""
    sMainAsm = sFolder & "\OldhamCoupling.SLDASM"
    sMotionAsm = sFolder & "\OldhamCoupling_Motion.SLDASM"

    ' Make sure the main assembly is saved (the motion file will use it)
    gStep = "Motion study: saving main assembly"
    On Error Resume Next
    If Not gAsmDoc Is Nothing Then gAsmDoc.SaveAs3 sMainAsm, 0, 0
    On Error GoTo 0

    gStep = "Motion study: creating motion assembly"
    Set oWrap = NewAssemblyDoc()
    If oWrap Is Nothing Then
        MsgBox "Could not create the motion assembly. Model is safe.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If

    gStep = "Motion study: inserting coupling assembly as one rigid body"
    On Error Resume Next
    Set oComp = oWrap.AddComponent5(sMainAsm, 0, "", False, "", 0, 0, 0)
    On Error GoTo 0
    If oComp Is Nothing Then
        MsgBox "Could not insert the coupling assembly into the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If

    ' Float it (first component is usually fixed), then place exactly at origin
    On Error Resume Next
    vComps = oWrap.GetComponents(True)
    On Error GoTo 0
    If IsArray(vComps) Then Call FloatFixedComponents(oWrap, vComps)
    Set oMU = swApp.GetMathUtility()
    aId(0) = 1: aId(1) = 0: aId(2) = 0: aId(3) = 0
    aId(4) = 1: aId(5) = 0: aId(6) = 0: aId(7) = 0
    aId(8) = 1: aId(9) = 0: aId(10) = 0: aId(11) = 0
    aId(12) = 1: aId(13) = 0: aId(14) = 0: aId(15) = 0
    vId = aId
    Set oIdXf = oMU.CreateTransform((vId))
    Call SetCompTransform(oComp, oIdXf)
    If Not CompAtPosition(oComp, 0, 0, 0) Then
        MsgBox "Coupling could not be placed at the origin in the motion file." & vbCrLf & _
               "Model is safe. Create the motion study manually.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If
    Set oOrigXf = oComp.Transform2

    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    On Error Resume Next
    oWrap.ShowNamedView2 "*Isometric", 7
    oWrap.ViewZoomtofit2
    On Error GoTo 0

    gStep = "Motion study: opening Motion Study manager"
    On Error Resume Next
    Set oMgr = oWrap.Extension.GetMotionStudyManager()
    On Error GoTo 0
    If oMgr Is Nothing Then
        MsgBox "Motion Study is not available in this SolidWorks window." & vbCrLf & _
               "Model is safe. Create the motion study manually (Motion Study tab at bottom).", _
               vbExclamation, "Oldham Coupling"
        Exit Function
    End If

    gStep = "Motion study: creating the study"
    On Error Resume Next
    Set oStudy = oMgr.GetMotionStudy("Motion Study 1")
    On Error GoTo 0
    If oStudy Is Nothing Then
        On Error Resume Next
        Set oStudy = oMgr.CreateMotionStudy()
        On Error GoTo 0
    End If
    If oStudy Is Nothing Then
        MsgBox "Could not create a Motion Study. Model is safe.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If
    On Error Resume Next
    oStudy.Activate
    oStudy.StudyType = 1              ' 1 = Animation
    oStudy.SetDuration durationSec
    On Error GoTo 0

    ' Rotation axis = Z axis (the shaft axis), through the origin
    gStep = "Motion study: preparing rotation"
    aPt(0) = 0: aPt(1) = 0: aPt(2) = 0
    aVec(0) = 0: aVec(1) = 0: aVec(2) = 1
    vPt = aPt
    vVec = aVec
    On Error Resume Next
    Set oPt = oMU.CreatePoint((vPt))
    Set oVec = oMU.CreateVector((vVec))
    On Error GoTo 0
    If oPt Is Nothing Or oVec Is Nothing Then
        MsgBox "Could not prepare the rotation axis - motion study skipped.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If

    totalTurns = rpm / 60# * durationSec
    nSteps = CLng(totalTurns * 24# + 0.5)        ' one key every 15 degrees of rotation
    If nSteps < 8 Then nSteps = 8
    If nSteps > 120 Then nSteps = 120

    ' Write keys for the ONE rigid component only
    gStep = "Motion study: writing rotation keys"
    For k = 0 To nSteps
        ang = 2# * PI_VAL * totalTurns * k / nSteps
        tNow = durationSec * k / nSteps
        On Error Resume Next
        oStudy.SetTime tNow
        On Error GoTo 0
        Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
        If oRot Is Nothing Then
            MsgBox "Could not create rotation transform - motion study stopped.", vbExclamation, "Oldham Coupling"
            Exit Function
        End If
        Set oNew = oOrigXf.Multiply(oRot)
        Call SetCompTransform(oComp, oNew)
    Next k

    gStep = "Motion study: calculating and checking"
    On Error Resume Next
    oStudy.Calculate
    On Error GoTo 0

    ' VERIFY: jump to a quarter-turn key time and read the rotation back
    If totalTurns >= 0.25 Then
        kTest = CLng(nSteps / (4# * totalTurns) + 0.5)
    Else
        kTest = nSteps
    End If
    If kTest < 1 Then kTest = 1
    If kTest > nSteps Then kTest = nSteps
    ang = 2# * PI_VAL * totalTurns * kTest / nSteps
    Set oRot = oMU.CreateTransformRotateAxis(oPt, oVec, ang)
    Set oNew = oOrigXf.Multiply(oRot)
    On Error Resume Next
    oStudy.SetTime durationSec * kTest / nSteps
    On Error GoTo 0
    bKeysOK = CompRotationAt(oComp, oNew)

    If bKeysOK Then
        On Error Resume Next
        oStudy.SetTime 0
        On Error GoTo 0
        gStep = "Motion study: saving motion assembly"
        oWrap.SaveAs3 sMotionAsm, 0, 0
        gMotionMsg = "Motion Study READY in OldhamCoupling_Motion.SLDASM (open now): " & _
                     "whole coupling rotates as ONE body at " & rpm & " RPM for " & durationSec & " seconds."
        MakeMotionStudy = True
        Exit Function
    End If

    ' FALLBACK: keys did not record on this PC - use "Rotate Model" instead
    gStep = "Motion study: fallback (Rotate Model)"
    On Error Resume Next
    oStudy.SetTime 0
    On Error GoTo 0
    Call SetCompTransform(oComp, oOrigXf)
    On Error Resume Next
    Call oWrap.ForceRebuild3(False)
    Set oStudy2 = oMgr.CreateMotionStudy()
    On Error GoTo 0
    If oStudy2 Is Nothing Then
        MsgBox "Motion keys did not record and the fallback study could not be created." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If
    bRotOK = False
    On Error Resume Next
    oStudy2.Activate
    oStudy2.StudyType = 1
    Err.Clear
    Call oStudy2.CreateByRotateModel(True, 2, totalTurns, 0, durationSec, 0)
    bRotOK = (Err.Number = 0)
    oStudy2.SetDuration durationSec
    oStudy2.Calculate
    oStudy2.SetTime 0
    On Error GoTo 0
    If Not bRotOK Then
        MsgBox "Sorry, the motion study could not be created automatically." & vbCrLf & _
               "Model is safe. Please create the motion study manually.", vbExclamation, "Oldham Coupling"
        Exit Function
    End If
    gStep = "Motion study: saving motion assembly"
    oWrap.SaveAs3 sMotionAsm, 0, 0
    gMotionMsg = "Motion Study READY in OldhamCoupling_Motion.SLDASM (open now, use the LAST Motion Study tab): " & _
                 "Rotate Model at " & rpm & " RPM for " & durationSec & " seconds."
    MakeMotionStudy = True
End Function

'------------------------- Validation -------------------------
Private Function ValidateDims() As Boolean
    ValidateDims = False
    If dHub <= dShaft + 8 Then MsgBox "Hub diameter must be at least shaft diameter + 8 mm.", vbCritical: Exit Function
    If dDisc <= dHub + 10 Then MsgBox "Disc diameter must be at least hub diameter + 10 mm.", vbCritical: Exit Function
    If tDisc < 10 Then MsgBox "Disc thickness is too small (minimum 10 mm for the slot).", vbCritical: Exit Function
    If hTongue < 2 Then MsgBox "Tongue height is too small (minimum 2 mm).", vbCritical: Exit Function
    If hTongue >= tDisc - 5 Then MsgBox "Tongue height is too big: the slot would break through the disc. Reduce tongue height or increase disc thickness.", vbCritical: Exit Function
    If lHubOut < 10 Then MsgBox "Hub length outside the disc is too small (minimum 10 mm).", vbCritical: Exit Function
    If dCenter > dDisc - 2 Then MsgBox "Centre disc must be at least 2 mm smaller than the end discs (it floats).", vbCritical: Exit Function
    If dCenter <= dShaft + 20 Then MsgBox "Centre disc diameter is too small for this shaft.", vbCritical: Exit Function
    If tCenter < 5 Then MsgBox "Centre disc thickness is too small (minimum 5 mm).", vbCritical: Exit Function
    If wTongue < 4 Or wTongue >= dCenter * 0.6 Then MsgBox "Tongue width should be between 4 mm and 60 percent of the centre disc diameter.", vbCritical: Exit Function
    If wKey >= dShaft Then MsgBox "Key width is too large for this shaft.", vbCritical: Exit Function
    If (tDisc + lHubOut) - (hTongue + 1) - 1 < 12 Then MsgBox "Hub is too short: the shaft gets less than 12 mm grip inside the hub. Increase hub length or disc thickness.", vbCritical: Exit Function
    If (dShaft / 2 + hKey / 2 + CLR) >= (dHub / 2 - 2) Then MsgBox "Keyway would break out of the hub. Reduce key height or increase hub diameter.", vbCritical: Exit Function
    ValidateDims = True
End Function

'=====================================================================================
'  MAIN
'=====================================================================================
Sub main()
    Dim sFolder As String, sSummary As String
    Dim sDefFolder As String
    Dim keyWDef As Double
    Dim motionRPM As Double, motionSecs As Double
    Dim sMotionLine As String
    On Error GoTo ErrHandler
    gStep = "Starting macro"
    Set swApp = Application.SldWorks
    If swApp Is Nothing Then MsgBox "SOLIDWORKS is not running.", vbCritical: Exit Sub

    MsgBox "OLDHAM COUPLING MACRO" & vbCrLf & vbCrLf & _
           "Pop-up boxes will ask your dimensions (mm)." & vbCrLf & _
           "Standard values are already filled - press OK to accept," & vbCrLf & _
           "or type your own value." & vbCrLf & vbCrLf & _
           "TIP: First close any old OldhamCoupling files that are open.", _
           vbInformation, "Oldham Coupling"

    ' ---- Folder to save files ----
    gCancelled = False
    sDefFolder = Environ$("USERPROFILE") & "\Documents\OldhamCoupling"
    If Len(Environ$("USERPROFILE")) = 0 Then sDefFolder = "C:\OldhamCoupling"
    sFolder = AskText("Folder where all part files + assembly will be SAVED." & vbCrLf & _
                      "Folder will be created if it does not exist.", sDefFolder)
    If gCancelled Or Len(sFolder) = 0 Then Exit Sub
    If Right(sFolder, 1) = "\" Then sFolder = Left(sFolder, Len(sFolder) - 1)
    If Len(Dir(sFolder, vbDirectory)) = 0 Then
        On Error Resume Next
        MkDir sFolder
        If Err.Number <> 0 Then
            MsgBox "Could not create folder:" & vbCrLf & sFolder & vbCrLf & _
                   "Create the folder manually in Windows, then run the macro again.", vbCritical
            Exit Sub
        End If
        On Error GoTo ErrHandler
    End If

    ' ---- Dimensions (defaults = standard proportions from shaft dia d) ----
    gCancelled = False
    dShaft = AskNum("1) Shaft diameter  d  (mm)" & vbCrLf & "This is also the bore diameter of both end hubs.", 40)
    If gCancelled Then Exit Sub
    dDisc = AskNum("2) End disc outside diameter (mm)" & vbCrLf & "Standard = 3 x d", 3 * dShaft)
    If gCancelled Then Exit Sub
    dHub = AskNum("3) Hub outside diameter (mm)" & vbCrLf & "Standard = 2 x d", 2 * dShaft)
    If gCancelled Then Exit Sub
    tDisc = AskNum("4) End disc thickness (mm)" & vbCrLf & "The slot is cut in this disc. Standard = 0.4 x d", 0.4 * dShaft)
    If gCancelled Then Exit Sub
    lHubOut = AskNum("5) Hub length OUTSIDE the disc, towards the shaft (mm)" & vbCrLf & "Standard = 1.1 x d", 1.1 * dShaft)
    If gCancelled Then Exit Sub
    dCenter = AskNum("6) Centre floating disc diameter (mm)" & vbCrLf & "Slightly smaller than the end discs (it floats).", dDisc - 4)
    If gCancelled Then Exit Sub
    tCenter = AskNum("7) Centre disc thickness, without tongues (mm)" & vbCrLf & "Standard = 0.35 x d", 0.35 * dShaft)
    If gCancelled Then Exit Sub
    wTongue = AskNum("8) Tongue width (mm)" & vbCrLf & "Slot in the end hubs will be made 1 mm wider (sliding fit)." & vbCrLf & "Standard = 0.5 x d", 0.5 * dShaft)
    If gCancelled Then Exit Sub
    hTongue = AskNum("9) Tongue height - how much it sticks out (mm)" & vbCrLf & "Slot will be made 1 mm deeper. Standard = 0.15 x d", 0.15 * dShaft)
    If gCancelled Then Exit Sub
    lShaftExp = AskNum("10) Visible shaft length OUTSIDE the hub, each side (mm)", 2 * dShaft)
    If gCancelled Then Exit Sub
    keyWDef = StdKeyWidth(dShaft)
    wKey = AskNum("11) Key width (mm)" & vbCrLf & "Standard key width for this shaft is filled.", keyWDef)
    If gCancelled Then Exit Sub
    hKey = AskNum("12) Key height / thickness (mm)", Round(wKey * 0.7))
    If gCancelled Then Exit Sub

    If Not ValidateDims() Then Exit Sub

    ' ---- Calculated values ----
    slotW = wTongue + 2 * CLR
    slotDepth = hTongue + 1
    endLenTotal = tDisc + lHubOut
    shaftPartLen = endLenTotal - slotDepth - 1 + lShaftExp   ' shaft end stops before the slot bottom (tongue clearance)
    keyLen = endLenTotal - slotDepth - 3          ' V2: key ends at shaft end and starts 2 mm inside the hub face
    If keyLen < 10 Then keyLen = (endLenTotal - slotDepth - 1) * 0.8

    ' ---- Summary + confirmation ----
    sSummary = "Model will be created with these dimensions (mm):" & vbCrLf & vbCrLf & _
        "Shaft dia (d)        = " & dShaft & vbCrLf & _
        "End disc dia / thk   = " & dDisc & " / " & tDisc & vbCrLf & _
        "Hub dia / length     = " & dHub & " / " & lHubOut & " (+" & tDisc & " disc)" & vbCrLf & _
        "Centre disc dia/thk  = " & dCenter & " / " & tCenter & vbCrLf & _
        "Tongue (W x H)       = " & wTongue & " x " & hTongue & vbCrLf & _
        "Slot (W x depth)     = " & slotW & " x " & slotDepth & vbCrLf & _
        "Key (L x W x H)      = " & keyLen & " x " & wKey & " x " & hKey & vbCrLf & _
        "Shaft length (each)  = " & shaftPartLen & vbCrLf & vbCrLf & _
        "Files will be saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
        "Click OK to start modelling. Please wait, do not click during modelling."
    If MsgBox(sSummary, vbOKCancel + vbInformation, "Oldham Coupling - Confirm") = vbCancel Then Exit Sub

    ' ---- Build all parts ----
    gStep = "Making Driving Hub A (horizontal slot)"
    If Not MakeEndHub(sFolder & "\Hub_A_Driving.SLDPRT", False, True) Then Exit Sub
    gStep = "Making Driven Hub B (vertical slot)"
    If Not MakeEndHub(sFolder & "\Hub_B_Driven.SLDPRT", True, False) Then Exit Sub
    gStep = "Making Centre Disc"
    If Not MakeCentreDisc(sFolder & "\Centre_Disc.SLDPRT") Then Exit Sub
    gStep = "Making Shaft"
    If Not MakeShaft(sFolder & "\Shaft.SLDPRT") Then Exit Sub
    gStep = "Making Key"
    If Not MakeKey(sFolder & "\Key.SLDPRT") Then Exit Sub

    ' ---- Build assembly ----
    gStep = "Making Assembly"
    If Not MakeAssembly(sFolder) Then
        MsgBox "All 5 PART files are created and saved in:" & vbCrLf & sFolder & vbCrLf & vbCrLf & _
               "Only the assembly step failed." & vbCrLf & _
               "Stopped at: " & gStep & vbCrLf & vbCrLf & _
               "You can insert parts manually" & vbCrLf & _
               "(New Assembly > Insert Components) - or send a screenshot for fixing.", _
               vbExclamation, "Oldham Coupling"
        Exit Sub
    End If

    ' ---- Optional Motion Study ----
    gMotionOK = False
    gMotionMsg = ""
    If MsgBox("Model is ready." & vbCrLf & vbCrLf & _
              "Create the MOTION STUDY also? (rotating coupling)" & vbCrLf & vbCrLf & _
              "YES = create motion study now" & vbCrLf & _
              "NO  = finish with model only", _
              vbYesNo + vbQuestion, "Oldham Coupling - Motion Study") = vbYes Then
        gCancelled = False
        motionRPM = AskNum("13) MOTION: Speed in RPM" & vbCrLf & "60 RPM = 1 full rotation per second", 60)
        If Not gCancelled Then
            motionSecs = AskNum("14) MOTION: Duration in SECONDS", 5)
            If Not gCancelled Then
                MsgBox "Motion Study is being created. Please WAIT..." & vbCrLf & _
                       "Do not click anywhere till the DONE message comes.", vbInformation, "Oldham Coupling"
                gStep = "Creating motion study"
                gMotionOK = MakeMotionStudy(sFolder, motionRPM, motionSecs)
            End If
        End If
    End If

    If gMotionOK Then
        sMotionLine = gMotionMsg & vbCrLf & vbCrLf & _
            "TO PLAY: click the 'Motion Study' tab at the BOTTOM of the window," & vbCrLf & _
            "then click 'Play from Start' (play button at top-left of the timeline)." & vbCrLf & vbCrLf
    Else
        sMotionLine = ""
    End If

    MsgBox "DONE!  Oldham Coupling model is ready." & vbCrLf & vbCrLf & _
           "Model assembly file:  OldhamCoupling.SLDASM" & vbCrLf & _
           "All files saved in:  " & sFolder & vbCrLf & vbCrLf & _
           sMotionLine & _
           "EXAM POINT: this coupling is used for parallel (lateral)" & vbCrLf & _
           "misalignment - the centre disc tongues slide in the hub slots." & vbCrLf & vbCrLf & _
           "Use mouse to rotate. Press Ctrl+7 for isometric view if needed." & vbCrLf & _
           "HOW TO MOVE IT: Drag either shaft/hub to rotate the coupling! Suppress 'Keep_..._Centered' in Mates to slide the tongues laterally.", _
           vbInformation, "Oldham Coupling"
    Exit Sub

ErrHandler:
    MsgBox "MACRO ERROR (Oldham Version 3)" & vbCrLf & vbCrLf & _
           "Step where it stopped : " & gStep & vbCrLf & _
           "Error number          : " & Err.Number & vbCrLf & _
           "Error message         : " & Err.Description & vbCrLf & vbCrLf & _
           "Please send a SCREENSHOT of this full message for fixing.", _
           vbCritical, "Oldham Coupling - Error"
End Sub
